import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "cloudtrail_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folder for 100% raw JSON details
DIR_CT = "details_cloudtrail"

if not os.path.exists(DIR_CT):
    os.makedirs(DIR_CT)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def check_s3_bucket_public(bucket_name, s3_client):
    """
    Tries to check if the destination S3 bucket is public.
    NOTE: This may fail if the audit role lacks s3:GetBucketAcl permissions.
    """
    try:
        acl = s3_client.get_bucket_acl(Bucket=bucket_name)
        for grant in acl.get('Grants', []):
            uri = grant.get('Grantee', {}).get('URI', '')
            if 'AllUsers' in uri or 'AuthenticatedUsers' in uri:
                return f"PUBLIC ({grant['Permission']})"
        
        pab = s3_client.get_public_access_block(Bucket=bucket_name)
        if pab.get('PublicAccessBlockConfiguration', {}).get('BlockPublicAcls', False):
            return "Not Public (PAB)"
            
        return "Not Public"
    except ClientError as e:
        if "AccessDenied" in str(e):
            return "AccessDenied (Cannot check)"
        if "NoSuchBucket" in str(e):
            return "Bucket Not Found"
    except Exception:
        return "Check Error"

# --- WORKER ---
def audit_region_cloudtrail(region):
    """
    Audits all CloudTrail trails homed in a single region.
    """
    ct = boto3.client('cloudtrail', region_name=region)
    s3 = boto3.client('s3', region_name=region) # For bucket checks
    
    res_trails = []
    
    try:
        # describe_trails() in a region lists all trails *homed* in that region
        for trail in ct.describe_trails()['trailList']:
            trail_name = trail['Name']
            trail_arn = trail['TrailARN']
            
            full_data = {'Description': trail}
            
            # --- 1. Get Status ---
            try:
                status = ct.get_trail_status(Name=trail_arn)
                full_data['Status'] = status
                is_logging = status['IsLogging']
                latest_delivery = status.get('LatestDeliveryTime')
                if latest_delivery:
                    latest_delivery = latest_delivery.replace(tzinfo=None)
            except ClientError as e:
                is_logging = f"Error: {e.response['Error']['Code']}"
                latest_delivery = None
            
            # --- 2. Get Event Selectors (Data Events) ---
            try:
                selectors = ct.get_event_selectors(TrailName=trail_arn)
                full_data['EventSelectors'] = selectors
                
                data_events = []
                for es in selectors.get('EventSelectors', []):
                    if es.get('DataResources'):
                        data_events.append(f"{es['ReadWriteType']}: {len(es['DataResources'])} resources")
                
                data_events_summary = ", ".join(data_events) or "None"
            except ClientError:
                data_events_summary = "Error"
                
            # --- 3. Get Insight Selectors ---
            try:
                insights = ct.get_insight_selectors(TrailName=trail_arn)
                full_data['InsightSelectors'] = insights
                insights_summary = "Enabled" if insights.get('InsightSelectors') else "Disabled"
            except ClientError:
                insights_summary = "Error"

            # --- 4. Check S3 Bucket Security ---
            s3_bucket = trail.get('S3BucketName', 'N/A')
            bucket_public_status = "N/A"
            if s3_bucket != 'N/A':
                bucket_public_status = check_s3_bucket_public(s3_bucket, s3)
                
            # --- 5. Save JSON ---
            file_ref = save_raw_json(DIR_CT, f"{region}_{trail_name}.json", full_data)

            # --- 6. Build Excel Row ---
            res_trails.append({
                'Trail Name': trail_name,
                'Home Region': region,
                'Is Multi-Region': trail['IsMultiRegionTrail'],
                'Is Logging': is_logging,
                'Log File Validation': trail['LogFileValidationEnabled'],
                'KMS Encrypted': "Yes" if trail.get('KmsKeyId') else "No",
                'Logs to S3': s3_bucket,
                'S3 Bucket Public?': bucket_public_status,
                'Logs to CloudWatch': "Yes" if trail.get('CloudWatchLogsLogGroupArn') else "No",
                'Data Events': data_events_summary,
                'Insights Enabled': insights_summary,
                'Latest Delivery': latest_delivery,
                'ARN': trail_arn,
                'Full Detail File': file_ref
            })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")
        
    return res_trails

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS CloudTrail Ultimate Audit ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_trails = []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_cloudtrail, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                all_trails.extend(future.result())
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    if not all_trails:
        print("No CloudTrails found.")
        return

    df_trails = pd.DataFrame(all_trails)
    
    # Sort by Multi-Region (most important) and Name
    df_trails = df_trails.sort_values(by=['Is Multi-Region', 'Trail Name'], ascending=[False, True])
    
    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_trails.to_excel(writer, sheet_name='CloudTrail Trails', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
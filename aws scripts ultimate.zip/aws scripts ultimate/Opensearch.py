import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "opensearch_ultimate_audit.xlsx"
MAX_WORKERS = 15 # OpenSearch API limits can be strict

# Folder for 100% raw JSON details
DIR_DOMAIN = "details_opensearch_domains"

if not os.path.exists(DIR_DOMAIN):
    os.makedirs(DIR_DOMAIN)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def format_principal(principal):
    if principal == '*': return "Public (*)"
    if 'AWS' in principal: return str(principal['AWS'])
    if 'Service' in principal: return str(principal['Service'])
    return str(principal)

# --- WORKER ---
def audit_region_opensearch(region):
    """
    Audits all OpenSearch domains in a single region.
    """
    # Note: Use 'opensearch' service client. 'es' is for older versions.
    os_client = boto3.client('opensearch', region_name=region)
    
    res_domains = []
    res_policies = []
    
    domain_names = []
    try:
        # 1. List all domain names
        paginator = os_client.get_paginator('list_domain_names')
        for page in paginator.paginate():
            domain_names.extend([d['DomainName'] for d in page['DomainNames']])
        
        if not domain_names:
            return res_domains, res_policies # No domains in this region

        # 2. Describe domains in a batch
        domains_desc = os_client.describe_domains(DomainNames=domain_names)['DomainStatusList']

    except ClientError as e:
        if "AccessDenied" in str(e):
             res_domains.append({'Region': region, 'Domain Name': 'AccessDenied', 'Status': 'AccessDenied'})
        # This region might not support OpenSearch
        elif "UnrecognizedClientException" in str(e):
            pass 
        else:
            print(f"[{region}] Error listing domains: {e}")
        return res_domains, res_policies

    # 3. Process each domain
    for domain in domains_desc:
        domain_name = domain['DomainName']
        
        # Save raw JSON
        file_ref = save_raw_json(DIR_DOMAIN, f"{region}_{domain_name}", domain)
        
        # --- Security ---
        deployment = "VPC" if domain.get('VPCOptions') else "Public"
        policy_str = domain.get('AccessPolicies', '{}')
        policy_attached = "Yes" if policy_str and policy_str != '{}' else "No"
        fgac_enabled = domain.get('AdvancedSecurityOptions', {}).get('Enabled', False)
        encryption_rest = domain.get('EncryptionAtRestOptions', {}).get('Enabled', False)
        encryption_node = domain.get('NodeToNodeEncryptionOptions', {}).get('Enabled', False)
        
        # --- Cost/Ops ---
        cluster_config = domain.get('ClusterConfig', {})
        instance_type = cluster_config.get('InstanceType', 'N/A')
        instance_count = cluster_config.get('InstanceCount', 0)
        ebs_options = domain.get('EBSOptions', {})
        ebs_size = ebs_options.get('VolumeSize', 'N/A')
        
        # Build Excel Row
        res_domains.append({
            'Region': region,
            'Domain Name': domain_name,
            'Status': domain.get('Processing', False),
            'Deployment Type': deployment,
            'FGAC Enabled?': fgac_enabled,
            'Encryption (Rest)': encryption_rest,
            'Encryption (Node)': encryption_node,
            'Policy Attached?': policy_attached,
            'Engine Version': domain.get('EngineVersion', 'N/A'),
            'Instance Type': instance_type,
            'Instance Count': instance_count,
            'EBS Volume Size (GB)': ebs_size,
            'VPC ID': domain.get('VPCOptions', {}).get('VPCId', 'N/A'),
            'Subnet IDs': ", ".join(domain.get('VPCOptions', {}).get('SubnetIds', [])),
            'Security Groups': ", ".join(domain.get('VPCOptions', {}).get('SecurityGroupIds', [])),
            'Full Detail File': file_ref
        })

        # --- 4. Explode Policy ---
        try:
            policy_json = json.loads(policy_str)
            for stmt in policy_json.get('Statement', []):
                res_policies.append({
                    'Region': region,
                    'Domain Name': domain_name,
                    'SID': stmt.get('Sid', 'No_SID'),
                    'Effect': stmt.get('Effect'),
                    'Principal': format_principal(stmt.get('Principal', {})),
                    'Action': str(stmt.get('Action')),
                    'Condition': str(stmt.get('Condition', {}))
                })
        except json.JSONDecodeError:
            print(f"[{region}] Could not parse policy for {domain_name}")

    return res_domains, res_policies

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS OpenSearch Ultimate Audit (Domains, Policy, Security) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_domains, all_policies = [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_opensearch, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                d, p = future.result()
                all_domains.extend(d)
                all_policies.extend(p)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_domains = pd.DataFrame(all_domains)
    df_policies = pd.DataFrame(all_policies)
    
    # Sort
    if not df_domains.empty:
        # Sort to bring "Public" (highest risk) to the top
        df_domains = df_domains.sort_values(by=['Deployment Type', 'Region', 'Domain Name'], ascending=[False, True, True])
    if not df_policies.empty:
        df_policies = df_policies.sort_values(by=['Region', 'Domain Name', 'SID'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_domains.to_excel(writer, sheet_name='OpenSearch Domains', index=False)
            df_policies.to_excel(writer, sheet_name='Domain Policies (Exploded)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
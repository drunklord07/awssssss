import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "cloudfront_ultimate_audit.xlsx"

# Folders for 100% raw JSON details
DIR_DISTRO = "details_cloudfront_distributions"
DIR_POLICY_C = "details_cloudfront_cachepolicies"
DIR_POLICY_O = "details_cloudfront_originreq"
DIR_FUNC = "details_cloudfront_functions"
DIR_KEY = "details_cloudfront_keys"

for d in [DIR_DISTRO, DIR_POLICY_C, DIR_POLICY_O, DIR_FUNC, DIR_KEY]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS CloudFront Ultimate Audit (Global Service) ---")
    
    try:
        cf = boto3.client('cloudfront')
    except Exception as e:
        print(f"CRITICAL: Could not create CloudFront client. Check credentials. {e}")
        return

    res_distros, res_behaviors, res_origins = [], [], []
    res_policies_c, res_policies_o, res_funcs = [], [], []
    res_key_groups, res_public_keys = [], []

    try:
        # --- 1. Audit Distributions, Behaviors, & Origins ---
        print("Auditing Distributions (this may take a moment)...")
        paginator = cf.get_paginator('list_distributions')
        for page in paginator.paginate():
            if 'Items' not in page.get('DistributionList', {}):
                continue
            
            for dist_summary in page['DistributionList']['Items']:
                dist_id = dist_summary['Id']
                dist_arn = dist_summary['ARN']
                
                try:
                    # Get the full distribution config
                    dist = cf.get_distribution(Id=dist_id)['Distribution']
                    config = dist['DistributionConfig']
                    
                    # Save raw JSON
                    file_ref = save_raw_json(DIR_DISTRO, f"{dist_id}_{dist_summary.get('Comment', 'no-comment')}", dist)

                    # --- Sheet 1: Distributions (Master List) ---
                    res_distros.append({
                        'ID': dist_id,
                        'Domain Name': dist_summary['DomainName'],
                        'ARN': dist_arn,
                        'Status': dist_summary['Status'],
                        'Enabled': dist_summary['Enabled'],
                        'Comment': dist_summary.get('Comment', ''),
                        'WAF ACL': config.get('WebACLId', 'NONE'),
                        'Certificate ARN': config.get('ViewerCertificate', {}).get('ACMCertificateArn', 'Default'),
                        'Price Class': config['PriceClass'],
                        'HTTP Version': config['HttpVersion'],
                        'Logging': config.get('Logging', {}).get('Bucket', 'DISABLED'),
                        'Default Origin ID': config['DefaultCacheBehavior']['TargetOriginId'],
                        'Full Detail File': file_ref
                    })
                    
                    # --- Sheet 3: Origins (Exploded) ---
                    for origin in config['Origins']['Items']:
                        res_origins.append({
                            'Distribution ID': dist_id,
                            'Origin ID': origin['Id'],
                            'Domain Name': origin['DomainName'],
                            'OAC ID': origin.get('OriginAccessControlId', 'N/A'),
                            'OAI': origin.get('S3OriginConfig', {}).get('OriginAccessIdentity', 'N/A'),
                            'Connection Attempts': origin.get('ConnectionAttempts', 3)
                        })

                    # --- Sheet 2: Behaviors (Exploded) - Default First ---
                    bh = config['DefaultCacheBehavior']
                    res_behaviors.append({
                        'Distribution ID': dist_id,
                        'Path Pattern': 'Default (*)',
                        'Origin': bh['TargetOriginId'],
                        'Viewer Protocol Policy': bh['ViewerProtocolPolicy'],
                        'Allowed Methods': ", ".join(bh.get('AllowedMethods', {}).get('Items', [])),
                        'Cache Policy': bh.get('CachePolicyId', 'Managed-CachingOptimized'),
                        'Origin Request Policy': bh.get('OriginRequestPolicyId', 'N/A'),
                        'Function Associations': bh.get('FunctionAssociations', {}).get('Quantity', 0)
                    })
                    
                    # ... then custom behaviors
                    for bh in config.get('CacheBehaviors', {}).get('Items', []):
                         res_behaviors.append({
                            'Distribution ID': dist_id,
                            'Path Pattern': bh['PathPattern'],
                            'Origin': bh['TargetOriginId'],
                            'Viewer Protocol Policy': bh['ViewerProtocolPolicy'],
                            'Allowed Methods': ", ".join(bh.get('AllowedMethods', {}).get('Items', [])),
                            'Cache Policy': bh.get('CachePolicyId', 'Managed-CachingOptimized'),
                            'Origin Request Policy': bh.get('OriginRequestPolicyId', 'N/A'),
                            'Function Associations': bh.get('FunctionAssociations', {}).get('Quantity', 0)
                        })
                except ClientError as e:
                    print(f"\nError describing distro {dist_id}: {e}")

        # --- 2. Audit Cache Policies ---
        print("Auditing Cache Policies...")
        paginator = cf.get_paginator('list_cache_policies')
        for page in paginator.paginate(Type='custom'):
            for item in page.get('CachePolicyList', {}).get('Items', []):
                pol = item['CachePolicy']
                file_ref = save_raw_json(DIR_POLICY_C, f"cache_{pol['Id']}", pol)
                res_policies_c.append({'ID': pol['Id'], 'Name': pol['Name'], 'Comment': pol['CachePolicyConfig']['Comment'], 'Full Detail File': file_ref})

        # --- 3. Audit Origin Request Policies ---
        print("Auditing Origin Request Policies...")
        paginator = cf.get_paginator('list_origin_request_policies')
        for page in paginator.paginate(Type='custom'):
            for item in page.get('OriginRequestPolicyList', {}).get('Items', []):
                pol = item['OriginRequestPolicy']
                file_ref = save_raw_json(DIR_POLICY_O, f"origin_{pol['Id']}", pol)
                res_policies_o.append({'ID': pol['Id'], 'Name': pol['Name'], 'Comment': pol['OriginRequestPolicyConfig']['Comment'], 'Full Detail File': file_ref})

        # --- 4. Audit Functions ---
        print("Auditing CloudFront Functions...")
        paginator = cf.get_paginator('list_functions')
        for page in paginator.paginate():
            for item in page.get('FunctionList', {}).get('Items', []):
                func = item['FunctionMetadata']
                file_ref = save_raw_json(DIR_FUNC, f"{func['Name']}", item)
                res_funcs.append({'Name': func['Name'], 'Runtime': func['Runtime'], 'Stage': func['Stage'], 'Last Modified': func['LastModifiedTime']})

        # --- 5. Audit Key Groups & Public Keys (Signed URLs) ---
        print("Auditing Key Groups...")
        paginator = cf.get_paginator('list_key_groups')
        for page in paginator.paginate():
            for item in page.get('KeyGroupList', {}).get('Items', []):
                kg = item['KeyGroup']
                res_key_groups.append({'ID': kg['Id'], 'Name': kg['Name'], 'Key Count': kg['KeyGroupConfig']['Quantity']})

        print("Auditing Public Keys...")
        paginator = cf.get_paginator('list_public_keys')
        for page in paginator.paginate():
            for item in page.get('PublicKeyList', {}).get('Items', []):
                key = item['PublicKey']
                res_public_keys.append({'ID': key['Id'], 'Name': key['Name'], 'Created': key['CreatedTime']})

    except Exception as e:
        print(f"\nCRITICAL ERROR during audit: {e}")
        return

    # --- Compile Excel ---
    print("\nCompiling Excel Report...")
    df_dist = pd.DataFrame(res_distros)
    df_beh = pd.DataFrame(res_behaviors)
    df_org = pd.DataFrame(res_origins)
    df_pol_c = pd.DataFrame(res_policies_c)
    df_pol_o = pd.DataFrame(res_policies_o)
    df_func = pd.DataFrame(res_funcs)
    df_kg = pd.DataFrame(res_key_groups)
    df_pk = pd.DataFrame(res_public_keys)

    # Sort
    if not df_dist.empty: df_dist = df_dist.sort_values(by=['Domain Name'])
    if not df_beh.empty: df_beh = df_beh.sort_values(by=['Distribution ID', 'Path Pattern'])
    if not df_org.empty: df_org = df_org.sort_values(by=['Distribution ID', 'Origin ID'])
    
    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_dist.to_excel(writer, sheet_name='Distributions (Master List)', index=False)
            df_beh.to_excel(writer, sheet_name='Behaviors (Exploded)', index=False)
            df_org.to_excel(writer, sheet_name='Origins (Exploded)', index=False)
            df_pol_c.to_excel(writer, sheet_name='Cache Policies (Custom)', index=False)
            df_pol_o.to_excel(writer, sheet_name='Origin Request Policies (Custom)', index=False)
            df_func.to_excel(writer, sheet_name='CloudFront Functions', index=False)
            df_kg.to_excel(writer, sheet_name='Key Groups (Signed URLs)', index=False)
            df_pk.to_excel(writer, sheet_name='Public Keys (Signed URLs)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "codebuild_ultimate_audit.xlsx"
MAX_WORKERS = 15
RECENT_BUILDS_COUNT = 10 # Get last 10 builds per project

# Folders for 100% raw JSON details
DIR_PROJECT = "details_codebuild_projects"
DIR_BUILD = "details_codebuild_builds"
DIR_REPORT = "details_codebuild_reports"

for d in [DIR_PROJECT, DIR_BUILD, DIR_REPORT]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['key']}={t['value']}" for t in tags_list])

# --- WORKER ---
def audit_region_codebuild(region):
    """
    Audits all CodeBuild projects, builds, and reports in a single region.
    """
    codebuild = boto3.client('codebuild', region_name=region)
    
    res_projects, res_builds, res_reports = [], [], []
    
    try:
        # --- 1. Audit Projects ---
        paginator = codebuild.get_paginator('list_projects')
        for page in paginator.paginate():
            project_names = page['projects']
            if not project_names:
                continue
            
            projects_desc = codebuild.batch_get_projects(names=project_names).get('projects', [])
            
            for project in projects_desc:
                proj_name = project['name']
                
                # Save raw JSON
                file_ref = save_raw_json(DIR_PROJECT, f"{region}_{proj_name}", project)
                
                # VPC Config
                vpc_config = project.get('vpcConfig', {})
                
                # Build Excel Row
                res_projects.append({
                    'Region': region,
                    'Project Name': proj_name,
                    'Service Role ARN': project.get('serviceRole', 'N/A'),
                    'Image': project.get('environment', {}).get('image', 'N/A'),
                    'Compute Type': project.get('environment', {}).get('computeType', 'N/A'),
                    'Privileged Mode?': project.get('environment', {}).get('privilegedMode', False),
                    'Source Type': project.get('source', {}).get('type', 'N/A'),
                    'VPC ID': vpc_config.get('vpcId', 'No VPC'),
                    'Subnets': ", ".join(vpc_config.get('subnets', [])),
                    'Security Groups': ", ".join(vpc_config.get('securityGroupIds', [])),
                    'Artifacts': project.get('artifacts', {}).get('location', 'N/A'),
                    'Build Timeout (min)': project.get('timeoutInMinutes', 'N/A'),
                    'Tags': get_tag_value(project.get('tags')),
                    'Full Detail File': file_ref
                })
                
                # --- 2. Get Recent Builds for this project ---
                try:
                    build_ids = codebuild.list_builds_for_project(projectName=proj_name, sortOrder='DESCENDING').get('ids', [])[:RECENT_BUILDS_COUNT]
                    if build_ids:
                        build_details = codebuild.batch_get_builds(ids=build_ids).get('builds', [])
                        for build in build_details:
                            build_id = build['id']
                            build_file = save_raw_json(DIR_BUILD, f"{region}_{build_id}", build)
                            res_builds.append({
                                'Region': region,
                                'Project Name': proj_name,
                                'Build ID': build_id,
                                'Build Status': build.get('buildStatus'),
                                'Initiator': build.get('initiator'),
                                'Source Version': build.get('sourceVersion', 'N/A'),
                                'Start Time': build.get('startTime'),
                                'Duration (sec)': (build.get('endTime', build.get('startTime')) - build.get('startTime')).total_seconds(),
                                'Full Detail File': build_file
                            })
                except ClientError as e:
                    print(f"\n[{region}] Error listing builds for {proj_name}: {e}")
                    
                # --- 3. Get Report Groups for this project ---
                try:
                    report_groups = codebuild.list_report_groups_for_project(projectArn=project['arn']).get('reportGroups', [])
                    if report_groups:
                        reports = codebuild.batch_get_reports(reportGroupArns=report_groups).get('reports', [])
                        for report in reports:
                            report_id = report['arn'].split('/')[-1]
                            report_file = save_raw_json(DIR_REPORT, f"{region}_{report_id}", report)
                            res_reports.append({
                                'Region': region,
                                'Project Name': proj_name,
                                'Report Name': report['name'],
                                'Report Type': report['type'],
                                'Status': report['status'],
                                'Line Coverage %': report.get('lineCoverageSummary', {}).get('linesCovered', 0) / (report.get('lineCoverageSummary', {}).get('linesMissed', 0) + report.get('lineCoverageSummary', {}).get('linesCovered', 1)) * 100,
                                'Test Cases Passed': report.get('testSummary', {}).get('total', 0) - len(report.get('testSummary', {}).get('statusCounts', {})),
                                'Full Detail File': report_file
                            })
                except ClientError as e:
                    print(f"\n[{region}] Error listing reports for {proj_name}: {e}")

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_projects, res_builds, res_reports

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS CodeBuild Ultimate Audit (Projects, Builds, Reports) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_projects, all_builds, all_reports = [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_codebuild, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                p, b, r = future.result()
                all_projects.extend(p); all_builds.extend(b); all_reports.extend(r)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_projects = pd.DataFrame(all_projects)
    df_builds = pd.DataFrame(all_builds)
    df_reports = pd.DataFrame(all_reports)
    
    # Sort
    if not df_projects.empty: df_projects = df_projects.sort_values(by=['Region', 'Project Name'])
    if not df_builds.empty:
        # Pre-sort to bring FAILED/STOPPED builds to the top
        status_priority = {'FAILED': 0, 'STOPPED': 1, 'FAULT': 2, 'TIMED_OUT': 3, 'IN_PROGRESS': 4, 'SUCCEEDED': 5}
        df_builds['StatusSort'] = df_builds['Build Status'].map(status_priority)
        df_builds = df_builds.sort_values(by=['StatusSort', 'Start Time'], ascending=[True, False])
        df_builds = df_builds.drop(columns=['StatusSort'])
    if not df_reports.empty: df_reports = df_reports.sort_values(by=['Region', 'Project Name', 'Report Name'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_projects.to_excel(writer, sheet_name='CodeBuild Projects', index=False)
            df_builds.to_excel(writer, sheet_name='Recent Builds (Last 10)', index=False)
            df_reports.to_excel(writer, sheet_name='Test & Coverage Reports', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
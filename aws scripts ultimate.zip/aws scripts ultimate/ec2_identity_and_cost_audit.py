import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from urllib.parse import unquote

# --- CONFIGURATION ---
OUTPUT_FILE = "ec2_identity_cost_audit.xlsx"
MAX_WORKERS = 20  # For regional resources

# --- HELPERS ---
def get_account_id():
    return boto3.client('sts').get_caller_identity()['Account']

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def get_tag_value(tags, key):
    if not tags: return ""
    for t in tags:
        if t['Key'] == key:
            return t['Value']
    return ""

# --- IAM (GLOBAL) ---
def audit_iam_roles_for_ec2():
    """
    Audits all IAM roles, filtering for those assumable by EC2.
    """
    print("Auditing IAM Roles (Global)...")
    iam = boto3.client('iam')
    iam_roles = []
    
    try:
        paginator = iam.get_paginator('list_roles')
        for page in paginator.paginate():
            for role in page['Roles']:
                role_name = role['RoleName']
                
                # Decode the AssumeRolePolicyDocument
                trust_policy = json.dumps(role.get('AssumeRolePolicyDocument', {}))
                
                # --- THIS IS THE KEY: Filter for EC2 roles ---
                if '"ec2.amazonaws.com"' in trust_policy:
                    
                    # 1. Get Attached Managed Policies
                    attached_policies = []
                    try:
                        pol_paginator = iam.get_paginator('list_attached_role_policies')
                        for pol_page in pol_paginator.paginate(RoleName=role_name):
                            for pol in pol_page['AttachedPolicies']:
                                attached_policies.append(pol['PolicyArn'])
                    except ClientError:
                        attached_policies.append("Error")

                    # 2. Get Inline Policies
                    inline_policies = []
                    try:
                        pol_paginator = iam.get_paginator('list_role_policies')
                        for pol_page in pol_paginator.paginate(RoleName=role_name):
                            inline_policies.extend(pol_page['PolicyNames'])
                    except ClientError:
                        inline_policies.append("Error")

                    iam_roles.append({
                        'Role Name': role_name,
                        'ARN': role['Arn'],
                        'Created': role['CreateDate'].replace(tzinfo=None),
                        'Attached Managed Policies': "\n".join(attached_policies),
                        'Inline Policies': "\n".join(inline_policies)
                    })
        return iam_roles
    except Exception as e:
        print(f"Error auditing IAM: {e}")
        return []

# --- REGIONAL WORKER ---
def audit_region_assets(region):
    """
    Audits AMIs, Launch Templates, and EIPs for a single region.
    """
    ec2 = boto3.client('ec2', region_name=region)
    
    res_ami = []
    res_lt = []
    res_eip = []

    try:
        # --- 1. AMIs (Blueprints) ---
        # We MUST filter by Owner='self' to only get custom images
        for ami in ec2.describe_images(Owners=['self'])['Images']:
            res_ami.append({
                'Name': ami.get('Name', ''),
                'AMI ID': ami['ImageId'],
                'Region': region,
                'State': ami['State'],
                'Public': ami['Public'],
                'Creation Date': ami['CreationDate'],
                'Root Device': ami.get('RootDeviceName', '')
            })

        # --- 2. Launch Templates (Configured Blueprints) ---
        paginator = ec2.get_paginator('describe_launch_templates')
        for page in paginator.paginate():
            for lt in page['LaunchTemplates']:
                lt_id = lt['LaunchTemplateId']
                lt_name = lt['LaunchTemplateName']
                
                # Get the content of the default version
                try:
                    ver_resp = ec2.describe_launch_template_versions(
                        LaunchTemplateId=lt_id, 
                        Versions=['$Default']
                    )
                    data = ver_resp['LaunchTemplateVersions'][0]['LaunchTemplateData']
                    
                    res_lt.append({
                        'Name': lt_name,
                        'Launch Template ID': lt_id,
                        'Region': region,
                        'AMI ID': data.get('ImageId', 'N/A'),
                        'Instance Type': data.get('InstanceType', 'N/A'),
                        'Key Pair': data.get('KeyName', 'N/A'),
                        'IAM Profile': data.get('IamInstanceProfile', {}).get('Name', 'N/A')
                    })
                except ClientError:
                    pass # Handle errors if template is broken

        # --- 3. Elastic IPs (Orphaned Cost) ---
        for eip in ec2.describe_addresses()['Addresses']:
            res_eip.append({
                'Public IP': eip['PublicIp'],
                'Region': region,
                'Allocation ID': eip['AllocationId'],
                'Status': 'Orphaned (Wasted Cost)' if 'AssociationId' not in eip else 'Attached',
                'Instance ID': eip.get('InstanceId', 'N/A'),
                'Network Interface ID': eip.get('NetworkInterfaceId', 'N/A'),
                'Domain': eip.get('Domain', 'vpc')
            })
            
    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_ami, res_lt, res_eip

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS EC2 Identity, Blueprint & Cost Audit ---")
    
    # --- 1. Run GLOBAL IAM Audit ---
    all_iam = audit_iam_roles_for_ec2()
    
    # --- 2. Run REGIONAL Audits ---
    regions = get_regions()
    print(f"\nScanning {len(regions)} regions for AMIs, LTs, and EIPs...")

    all_ami, all_lt, all_eip = [], [], []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_assets, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            print(f"\rProgress: {done}/{len(regions)}", end="")
            
            a, l, e = future.result()
            all_ami.extend(a)
            all_lt.extend(l)
            all_eip.extend(e)

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_iam = pd.DataFrame(all_iam)
    df_ami = pd.DataFrame(all_ami)
    df_lt = pd.DataFrame(all_lt)
    df_eip = pd.DataFrame(all_eip)
    
    # Sort
    if not df_iam.empty: df_iam = df_iam.sort_values(by=['Role Name'])
    if not df_ami.empty: df_ami = df_ami.sort_values(by=['Region', 'Name'])
    if not df_lt.empty: df_lt = df_lt.sort_values(by=['Region', 'Name'])
    if not df_eip.empty: df_eip = df_eip.sort_values(by=['Region', 'Status'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_iam.to_excel(writer, sheet_name='IAM Roles for EC2', index=False)
            df_ami.to_excel(writer, sheet_name='Custom AMIs', index=False)
            df_lt.to_excel(writer, sheet_name='Launch Templates', index=False)
            df_eip.to_excel(writer, sheet_name='Elastic IPs', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "macie_ultimate_audit.xlsx"
MAX_WORKERS = 10  # Macie has strict API limits, keep this low

# Folders for 100% raw JSON details (CONFIGURATIONS ONLY)
DIR_ADMIN = "details_macie_admin"
DIR_SESSION = "details_macie_session"
DIR_CUSTOM_ID = "details_macie_custom_identifiers"
DIR_ALLOW = "details_macie_allow_lists"

for d in [DIR_ADMIN, DIR_SESSION, DIR_CUSTOM_ID, DIR_ALLOW]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def flatten_finding(finding, region):
    """Flattens the complex finding JSON into a single dict for Excel."""
    resources = finding.get('resourcesAffected', {})
    s3_bucket = resources.get('s3Bucket', {})
    s3_object = s3_bucket.get('objects', [{}])[0]
    
    return {
        'Region': region,
        'Severity': finding.get('severity', {}).get('description', 'N/A'),
        'Type': finding.get('type', 'N/A'),
        'Category': finding.get('category', 'N/A'),
        'Title': finding.get('title', 'N/A'),
        'Count': finding.get('count', 0),
        'Bucket Name': s3_bucket.get('name', 'N/A'),
        'Object Key': s3_object.get('key', 'N/A'),
        'Finding ID': finding.get('id'),
        'First Seen': finding.get('createdAt'),
        'Last Seen': finding.get('updatedAt'),
    }

# --- WORKER ---
def audit_region_macie(region):
    """
    Audits all Macie v2 components in a single region.
    """
    macie = boto3.client('macie2', region_name=region)
    
    res_status = {}
    res_findings = []
    res_custom_ids = []
    res_allow_lists = []
    
    try:
        # --- 1. Audit Macie Status (Is it on?) ---
        session = macie.get_macie_session()
        session.pop('ResponseMetadata', None)
        save_raw_json(DIR_SESSION, f"{region}_session.json", session)

        if session.get('status', 'ERROR') != 'ENABLED':
            res_status = {'Region': region, 'Status': session.get('status', 'DISABLED'), 'Auto-Discovery': 'N/A', 'S3 Export': 'N/A'}
            return res_status, res_findings, res_custom_ids, res_allow_lists
            
        # --- 2. Get Auto-Discovery Status ---
        try:
            auto_disc = macie.get_automated_discovery_configuration()['status']
        except ClientError:
            auto_disc = "Error"
            
        # --- 3. Get S3 Export Status ---
        try:
            export_config = macie.get_findings_publication_configuration()
            s3_dest = export_config.get('securityHubConfiguration', {}).get('publishFindingsToSecurityHub', 'N/A')
            s3_export = "ENABLED" if s3_dest else "DISABLED"
        except ClientError:
            s3_export = "Error"

        res_status = {
            'Region': region,
            'Status': 'ENABLED',
            'Auto-Discovery': auto_disc,
            'S3 Export': s3_export
        }

        # --- 4. Audit Active Findings (The "To-Do List") ---
        paginator = macie.get_paginator('list_findings')
        filter_criteria = {'criterion': {'findingType': {'eq': ['Policy/S3BucketPublic', 'SensitiveData/S3Object/Multiple', 'SensitiveData/S3Object/Financial', 'SensitiveData/S3Object/Credentials', 'SensitiveData/S3Object/Personal']}}} # Example filter
        
        for page in paginator.paginate(findingCriteria={'criterion': {'archived': {'eq': ['false']}}}):
            finding_ids = page.get('findingIds', [])
            if finding_ids:
                findings_details = macie.get_findings(findingIds=finding_ids).get('findings', [])
                for finding in findings_details:
                    res_findings.append(flatten_finding(finding, region))
        
        # --- 5. List Custom Data Identifiers ---
        paginator = macie.get_paginator('list_custom_data_identifiers')
        for page in paginator.paginate():
            for item in page.get('items', []):
                item_details = macie.get_custom_data_identifier(id=item['id'])
                item_details.pop('ResponseMetadata', None)
                save_raw_json(DIR_CUSTOM_ID, f"{region}_{item['id']}.json", item_details)
                res_custom_ids.append({
                    'Region': region,
                    'Name': item_details.get('name'),
                    'ID': item_details.get('id'),
                    'Regex': item_details.get('regex'),
                    'Keywords': ", ".join(item_details.get('keywords', [])),
                    'ARN': item_details.get('arn')
                })
                
        # --- 6. List Allow Lists ---
        paginator = macie.get_paginator('list_allow_lists')
        for page in paginator.paginate():
            for item in page.get('items', []):
                item_details = macie.get_allow_list(id=item['id'])
                item_details.pop('ResponseMetadata', None)
                save_raw_json(DIR_ALLOW, f"{region}_{item['id']}.json", item_details)
                res_allow_lists.append({
                    'Region': region,
                    'Name': item_details.get('name'),
                    'ID': item_details.get('id'),
                    'Status': item_details.get('status', {}).get('code', 'N/A'),
                    'Criteria Type': item_details.get('criteria', {}).get('regex', 'S3_BUCKET_NAME'),
                    'ARN': item_details.get('arn')
                })

    except ClientError as e:
        if "AccessDeniedException" in str(e):
             res_status = {'Region': region, 'Status': 'DISABLED (AccessDenied)', 'Auto-Discovery': 'N/A', 'S3 Export': 'N/A'}
        else:
            print(f"[{region}] Error: {e}")
            res_status = {'Region': region, 'Status': f'Error: {e}', 'Auto-Discovery': 'N/A', 'S3 Export': 'N/A'}

    return res_status, res_findings, res_custom_ids, res_allow_lists

def audit_delegated_admin():
    """Checks for a Macie Delegated Administrator."""
    res_admins = []
    try:
        client = boto3.client('macie2', region_name='us-east-1') # Use us-east-1 for global
        paginator = client.get_paginator('list_organization_admin_accounts')
        for page in paginator.paginate():
            for admin in page['adminAccounts']:
                res_admins.append(admin)
        
        save_raw_json(DIR_ADMIN, "delegated_admins.json", res_admins)
                
    except ClientError as e:
        if "AccessDenied" in str(e):
            return [{'accountId': 'AccessDenied', 'status': 'N/A'}]
    except Exception as e:
        print(f"Note: Could not check for Delegated Admin (Not an Org?): {e}")
        return [{'accountId': 'Not an Org or Error', 'status': 'N/Failure'}]
        
    if not res_admins:
        return [{'accountId': 'None', 'status': 'None'}]
    
    return res_admins

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Macie Ultimate Audit (Status, Findings, Config) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_status, all_findings, all_custom_ids, all_allow_lists = [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_macie, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                stat, find, cids, allows = future.result()
                all_status.append(stat)
                all_findings.extend(find)
                all_custom_ids.extend(cids)
                all_allow_lists.extend(allows)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\nChecking for Delegated Administrator...")
    all_admins = audit_delegated_admin()

    print("Compiling Excel Report...")

    # Create DataFrames
    df_admins = pd.DataFrame(all_admins)
    df_status = pd.DataFrame(all_status)
    df_findings = pd.DataFrame(all_findings)
    df_custom_ids = pd.DataFrame(all_custom_ids)
    df_allow_lists = pd.DataFrame(all_allow_lists)
    
    # Sort
    if not df_status.empty: df_status = df_status.sort_values(by=['Region'])
    if not df_findings.empty:
        severity_map = {'High': 0, 'Medium': 1, 'Low': 2, 'N/A': 3}
        df_findings['SeveritySort'] = df_findings['Severity'].map(severity_map)
        df_findings = df_findings.sort_values(by=['SeveritySort', 'Last Seen'], ascending=[True, False])
        df_findings = df_findings.drop(columns=['SeveritySort'])
    if not df_custom_ids.empty: df_custom_ids = df_custom_ids.sort_values(by=['Region', 'Name'])
    if not df_allow_lists.empty: df_allow_lists = df_allow_lists.sort_values(by=['Region', 'Name'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_admins.to_excel(writer, sheet_name='Delegated Admin (Org)', index=False)
            df_status.to_excel(writer, sheet_name='Macie Status (by Region)', index=False)
            df_findings.to_excel(writer, sheet_name='Active Findings (Exploded)', index=False)
            df_custom_ids.to_excel(writer, sheet_name='Custom Identifiers', index=False)
            df_allow_lists.to_excel(writer, sheet_name='Allow Lists', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
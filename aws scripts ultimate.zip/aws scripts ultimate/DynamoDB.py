import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "dynamodb_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_TABLE = "details_dynamodb_tables"
DIR_BACKUP = "details_dynamodb_backups"
DIR_GLOBAL = "details_dynamodb_globaltables"
DIR_EXPORT = "details_dynamodb_exports"

for d in [DIR_TABLE, DIR_BACKUP, DIR_GLOBAL, DIR_EXPORT]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def get_tag_value(tags_list):
    """Expects the format [{'Key': 'k', 'Value': 'v'}]"""
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

# --- WORKER ---
def audit_region_dynamodb(region):
    """
    Audits all DynamoDB components in a single region.
    """
    dynamodb = boto3.client('dynamodb', region_name=region)
    
    res_tables, res_backups, res_exports = [], [], []
    
    try:
        # --- 1. Audit DynamoDB Tables ---
        paginator = dynamodb.get_paginator('list_tables')
        for page in paginator.paginate():
            for table_name in page['TableNames']:
                try:
                    # Get full table details
                    desc = dynamodb.describe_table(TableName=table_name)['Table']
                    table_arn = desc['TableArn']
                    
                    # Get PITR (Point-in-Time-Recovery) status
                    pitr = dynamodb.describe_continuous_backups(TableName=table_name)['ContinuousBackupsDescription']
                    
                    # Get TTL (Time-to-Live) status
                    ttl = dynamodb.describe_time_to_live(TableName=table_name)['TimeToLiveDescription']
                    
                    # --- *** FIX: Get Tags (separate call) *** ---
                    try:
                        tags = dynamodb.list_tags_of_resource(ResourceArn=table_arn).get('Tags', [])
                    except ClientError:
                        tags = [] # Handle throttling or permissions issues

                    full_data = {'Description': desc, 'PITR': pitr, 'TTL': ttl, 'Tags': tags}
                    file_ref = save_raw_json(DIR_TABLE, f"{region}_{table_name}", full_data)

                    res_tables.append({
                        'Region': region,
                        'Table Name': table_name,
                        'ARN': table_arn,
                        'Status': desc['TableStatus'],
                        'Item Count': desc.get('ItemCount', 0),
                        'Table Size (Bytes)': desc.get('TableSizeBytes', 0),
                        'Billing Mode': desc.get('BillingModeSummary', {}).get('BillingMode', 'PROVISIONED'),
                        'Table Class': desc.get('TableClassSummary', {}).get('TableClass', 'STANDARD'),
                        'PITR Enabled': pitr['PointInTimeRecoveryDescription']['PointInTimeRecoveryStatus'] == 'ENABLED',
                        'TTL Status': ttl['TimeToLiveStatus'],
                        'Encryption Type': desc.get('SSESpecification', {}).get('SSEType', 'DEFAULT'),
                        'KMS Key ID': desc.get('SSESpecification', {}).get('KMSMasterKeyId', 'N/A'),
                        'Stream Enabled': desc.get('StreamSpecification', {}).get('StreamEnabled', False),
                        'Tags': get_tag_value(tags), # <-- FIXED
                        'Full Detail File': file_ref
                    })
                except ClientError as e:
                    print(f"\n[{region}] Error describing table {table_name}: {e}")
        
        # --- 2. Audit Backups ---
        paginator = dynamodb.get_paginator('list_backups')
        for page in paginator.paginate():
            for backup in page['BackupSummaries']:
                backup_arn = backup['BackupArn']
                file_ref = save_raw_json(DIR_BACKUP, f"{region}_{backup_arn.split('/')[-1]}", backup)
                res_backups.append({
                    'Region': region,
                    'Table ARN': backup['TableArn'],
                    'Backup ARN': backup_arn,
                    'Backup Type': backup['BackupType'],
                    'Status': backup['BackupStatus'],
                    'Creation Date': backup['BackupCreationDateTime'].replace(tzinfo=None),
                    'Full Detail File': file_ref
                })

        # --- 3. Audit S3 Exports ---
        paginator = dynamodb.get_paginator('list_exports')
        for page in paginator.paginate():
            for export in page.get('ExportSummaries', []):
                export_arn = export['ExportArn']
                file_ref = save_raw_json(DIR_EXPORT, f"{region}_{export_arn.split('/')[-1]}", export)
                res_exports.append({
                    'Region': region,
                    'Export ARN': export_arn,
                    'Table ARN': export['TableArn'],
                    'Status': export['ExportStatus'],
                    'S3 Bucket': export.get('S3Bucket', 'N/A'),
                    'Export Format': export.get('ExportFormat', 'N/A'),
                    'Start Time': export.get('ExportTime', 'N/A'),
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_tables, res_backups, res_exports

def audit_global_tables():
    """
    Audits Global Tables. This is a single global call, best made from us-east-1.
    """
    print("\nAuditing Global Tables (Global Service)...")
    dynamodb = boto3.client('dynamodb', region_name='us-east-1')
    res_global = []
    
    try:
        paginator = dynamodb.get_paginator('list_global_tables')
        for page in paginator.paginate():
            for gt in page['GlobalTables']:
                gt_name = gt['GlobalTableName']
                gt_details = dynamodb.describe_global_table(GlobalTableName=gt_name)['GlobalTableDescription']
                file_ref = save_raw_json(DIR_GLOBAL, f"global_{gt_name}", gt_details)
                
                res_global.append({
                    'Global Table Name': gt_name,
                    'Status': gt_details['GlobalTableStatus'],
                    'Regions': ", ".join([r['RegionName'] for r in gt_details.get('ReplicationGroup', [])]),
                    'ARN': gt_details['GlobalTableArn'],
                    'Full Detail File': file_ref
                })
    except ClientError as e:
        print(f"Could not audit Global Tables (is this an Org?): {e}")
    
    return res_global

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS DynamoDB Ultimate Audit (Tables, Backups, Global) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_tables, all_backups, all_exports = [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_dynamodb, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                t, b, e = future.result()
                all_tables.extend(t); all_backups.extend(b); all_exports.extend(e)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    # Run the global audit once
    all_global_tables = audit_global_tables()

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_tables = pd.DataFrame(all_tables)
    df_global = pd.DataFrame(all_global_tables)
    df_backups = pd.DataFrame(all_backups)
    df_exports = pd.DataFrame(all_exports)
    
    # Sort
    if not df_tables.empty:
        df_tables = df_tables.sort_values(by=['Region', 'Billing Mode', 'Table Name'], ascending=[True, False, True])
    if not df_backups.empty:
        df_backups = df_backups.sort_values(by=['Creation Date'], ascending=False) # Newest first

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_tables.to_excel(writer, sheet_name='DynamoDB Tables', index=False)
            df_global.to_excel(writer, sheet_name='Global Tables', index=False)
            df_backups.to_excel(writer, sheet_name='Backups', index=False)
            df_exports.to_excel(writer, sheet_name='S3 Exports (Last 90 Days)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "cloudwatch_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_LOG_G = "details_cw_log_groups"
DIR_ALARM = "details_cw_alarms"
DIR_DASH = "details_cw_dashboards"
DIR_EVENT = "details_eventbridge_rules"

for d in [DIR_LOG_G, DIR_ALARM, DIR_DASH, DIR_EVENT]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

# --- WORKER ---
def audit_region_cw_events(region):
    """
    Audits CloudWatch Logs, Alarms, Dashboards, and EventBridge Rules
    """
    # We need 3 clients
    logs = boto3.client('logs', region_name=region)
    cw = boto3.client('cloudwatch', region_name=region)
    events = boto3.client('events', region_name=region)
    
    res_logs, res_filters, res_alarms, res_dash, res_rules, res_targets = [], [], [], [], [], []
    
    try:
        # --- 1. CloudWatch Log Groups & Metric Filters ---
        paginator = logs.get_paginator('describe_log_groups')
        for page in paginator.paginate():
            for lg in page['logGroups']:
                lg_name = lg['logGroupName']
                file_ref = save_raw_json(DIR_LOG_G, f"{region}_{lg_name.replace('/', '_')}.json", lg)
                
                res_logs.append({
                    'Region': region,
                    'Log Group Name': lg_name,
                    'Retention (Days)': lg.get('retentionInDays', 'Never Expire'),
                    'KMS Key ID': lg.get('kmsKeyId', 'Default'),
                    'Stored Bytes': lg.get('storedBytes', 0),
                    'Full Detail File': file_ref
                })
                
                # Get Metric Filters for this group
                mf_paginator = logs.get_paginator('describe_metric_filters')
                for mf_page in mf_paginator.paginate(logGroupName=lg_name):
                    for mf in mf_page['metricFilters']:
                        for trans in mf.get('metricTransformations', [{}]):
                            res_filters.append({
                                'Region': region,
                                'Log Group Name': lg_name,
                                'Filter Name': mf.get('filterName'),
                                'Filter Pattern': mf.get('filterPattern', ''),
                                'Metric Name': trans.get('metricName'),
                                'Metric Namespace': trans.get('metricNamespace')
                            })

        # --- 2. CloudWatch Alarms ---
        paginator = cw.get_paginator('describe_alarms')
        for page in paginator.paginate():
            for alarm in page['MetricAlarms']:
                alarm_name = alarm['AlarmName']
                file_ref = save_raw_json(DIR_ALARM, f"{region}_{alarm_name.replace('/', '_')}.json", alarm)
                
                res_alarms.append({
                    'Region': region,
                    'Alarm Name': alarm_name,
                    'State': alarm['StateValue'],
                    'Description': alarm.get('AlarmDescription', ''),
                    'Namespace': alarm.get('Namespace', 'N/A'),
                    'Metric Name': alarm.get('MetricName', 'N/A'),
                    'Actions': "\n".join(alarm.get('AlarmActions', [])),
                    'Full Detail File': file_ref
                })
                
        # --- 3. CloudWatch Dashboards ---
        paginator = cw.get_paginator('list_dashboards')
        for page in paginator.paginate():
            for dash in page['DashboardEntries']:
                dash_name = dash['DashboardName']
                # Get full dashboard body
                try:
                    body = cw.get_dashboard(DashboardName=dash_name)
                    file_ref = save_raw_json(DIR_DASH, f"{region}_{dash_name}.json", body)
                except ClientError:
                    file_ref = "Error"
                    
                res_dash.append({
                    'Region': region,
                    'Dashboard Name': dash_name,
                    'Last Modified': dash.get('LastModified'),
                    'Full Detail File': file_ref
                })
                
        # --- 4. EventBridge Rules & Targets ---
        paginator = events.get_paginator('list_rules')
        for page in paginator.paginate():
            for rule in page['Rules']:
                rule_name = rule['Name']
                
                # Get targets for this rule
                targets = events.list_targets_by_rule(Rule=rule_name).get('Targets', [])
                full_data = {'Rule': rule, 'Targets': targets}
                file_ref = save_raw_json(DIR_EVENT, f"{region}_{rule_name}.json", full_data)
                
                res_rules.append({
                    'Region': region,
                    'Rule Name': rule_name,
                    'Event Bus Name': rule.get('EventBusName', 'default'),
                    'State': rule['State'],
                    'Schedule': rule.get('ScheduleExpression', 'Event Pattern'),
                    'Event Pattern': rule.get('EventPattern', 'Schedule'),
                    'Target Count': len(targets),
                    'Full Detail File': file_ref
                })
                
                # Explode targets
                for target in targets:
                    res_targets.append({
                        'Region': region,
                        'Rule Name': rule_name,
                        'Target ID': target['Id'],
                        'Target ARN': target['Arn']
                    })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_logs, res_filters, res_alarms, res_dash, res_rules, res_targets

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS CloudWatch & EventBridge Ultimate Audit ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_logs, all_filters, all_alarms, all_dash, all_rules, all_targets = [], [], [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_cw_events, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                l, f, a, d, r, t = future.result()
                all_logs.extend(l); all_filters.extend(f); all_alarms.extend(a)
                all_dash.extend(d); all_rules.extend(r); all_targets.extend(t)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_logs = pd.DataFrame(all_logs)
    df_filters = pd.DataFrame(all_filters)
    df_alarms = pd.DataFrame(all_alarms)
    df_dash = pd.DataFrame(all_dash)
    df_rules = pd.DataFrame(all_rules)
    df_targets = pd.DataFrame(all_targets)
    
    # Sort for auditing
    if not df_logs.empty:
        # Put "Never Expire" (None) at the top
        df_logs['Retention (Days)'] = pd.to_numeric(df_logs['Retention (Days)'], errors='coerce')
        df_logs = df_logs.sort_values(by=['Retention (Days)'], na_position='first')
    if not df_alarms.empty:
        # Put "ALARM" and "INSUFFICIENT_DATA" at the top
        alarm_priority = {'ALARM': 0, 'INSUFFICIENT_DATA': 1, 'OK': 2}
        df_alarms['StateSort'] = df_alarms['State'].map(alarm_priority)
        df_alarms = df_alarms.sort_values(by=['StateSort', 'Alarm Name'])
        df_alarms = df_alarms.drop(columns=['StateSort'])
        
    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_logs.to_excel(writer, sheet_name='CW Log Groups', index=False)
            df_alarms.to_excel(writer, sheet_name='CW Alarms (Exploded)', index=False)
            df_rules.to_excel(writer, sheet_name='EventBridge Rules', index=False)
            df_targets.to_excel(writer, sheet_name='EventBridge Targets (Exploded)', index=False)
            df_filters.to_excel(writer, sheet_name='CW Metric Filters', index=False)
            df_dash.to_excel(writer, sheet_name='CW Dashboards', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
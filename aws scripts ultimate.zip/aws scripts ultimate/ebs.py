import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "ebs_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_VOL = "details_ebs_volumes"
DIR_SNAP = "details_ebs_snapshots"

for d in [DIR_VOL, DIR_SNAP]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

def get_account_id():
    return boto3.client('sts').get_caller_identity()['Account']

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

# --- WORKER ---
def audit_region_ebs(region):
    """
    Audits all EBS Volumes and Snapshots in a single region.
    """
    ec2 = boto3.client('ec2', region_name=region)
    
    res_volumes = []
    res_snapshots = []
    
    try:
        # --- 1. Audit EBS Volumes ---
        paginator = ec2.get_paginator('describe_volumes')
        for page in paginator.paginate():
            for vol in page['Volumes']:
                vol_id = vol['VolumeId']
                
                # Save raw JSON
                file_ref = save_raw_json(DIR_VOL, f"{region}_{vol_id}.json", vol)
                
                # Check Attachment State
                status = "Attached"
                attached_instance = "N/A"
                if not vol['Attachments']:
                    status = "Unattached (Wasted Cost)"
                else:
                    attached_instance = vol['Attachments'][0]['InstanceId']
                
                # Build Excel Row
                res_volumes.append({
                    'Region': region,
                    'Status': status,
                    'Volume ID': vol_id,
                    'Encrypted': vol['Encrypted'],
                    'Size (GB)': vol['Size'],
                    'Volume Type': vol['VolumeType'],
                    'IOPS': vol.get('Iops', 'N/A'),
                    'Throughput (MiBps)': vol.get('Throughput', 'N/A'),
                    'Attached Instance': attached_instance,
                    'KMS Key ID': vol.get('KmsKeyId', 'Default'),
                    'Created': vol['CreateTime'].replace(tzinfo=None),
                    'Tags': get_tag_value(vol.get('Tags')),
                    'Full Detail File': file_ref
                })

        # --- 2. Audit EBS Snapshots ---
        # Filter for 'OwnerIds=['self']' to get ONLY your snapshots
        paginator = ec2.get_paginator('describe_snapshots')
        for page in paginator.paginate(OwnerIds=['self']):
            for snap in page['Snapshots']:
                snap_id = snap['SnapshotId']
                
                # Save raw JSON
                file_ref = save_raw_json(DIR_SNAP, f"{region}_{snap_id}.json", snap)
                
                # Build Excel Row
                res_snapshots.append({
                    'Region': region,
                    'Snapshot ID': snap_id,
                    'Status': snap['State'],
                    'Creation Date': snap['StartTime'].replace(tzinfo=None),
                    'Snapshot Type': 'Manual' if not snap.get('Description', '').startswith('Created by') else 'Automated',
                    'Source Volume': snap['VolumeId'],
                    'Volume Size (GB)': snap['VolumeSize'],
                    'Encrypted': snap['Encrypted'],
                    'KMS Key ID': snap.get('KmsKeyId', 'Default'),
                    'Tags': get_tag_value(snap.get('Tags')),
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_volumes, res_snapshots

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS EBS Ultimate Audit (Volumes & Snapshots) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_volumes, all_snapshots = [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_ebs, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                v, s = future.result()
                all_volumes.extend(v)
                all_snapshots.extend(s)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_volumes = pd.DataFrame(all_volumes)
    df_snapshots = pd.DataFrame(all_snapshots)
    
    # Sort
    if not df_volumes.empty:
        # Pre-sort to put "Unattached" (cost risk) at the top
        df_volumes = df_volumes.sort_values(by=['Status', 'Region', 'Volume ID'], ascending=[False, True, True])
    if not df_snapshots.empty:
        # Pre-sort to put oldest snapshots at the top
        df_snapshots = df_snapshots.sort_values(by=['Creation Date'], ascending=True)

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_volumes.to_excel(writer, sheet_name='EBS Volumes', index=False)
            df_snapshots.to_excel(writer, sheet_name='EBS Snapshots', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
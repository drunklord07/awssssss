import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "accessanalyzer_ultimate_audit.xlsx"
MAX_WORKERS = 10  # Access Analyzer has lower API limits

# Folders for 100% raw JSON details
DIR_ANALYZER = "details_accessanalyzer_analyzers"
DIR_FINDING = "details_accessanalyzer_findings"
DIR_RULE = "details_accessanalyzer_rules"

for d in [DIR_ANALYZER, DIR_FINDING, DIR_RULE]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def flatten_finding_principal(principal):
    """Simplifies the finding's Principal dict."""
    if 'AWS' in principal:
        return f"Account: {principal['AWS']}"
    if 'CanonicalUser' in principal:
        return f"CanonicalUser: {principal['CanonicalUser']}"
    if 'Federated' in principal:
        return f"Federated: {principal['Federated']}"
    if 'Service' in principal:
        return f"Service: {principal['Service']}"
    return str(principal)

def flatten_archive_rule_filter(filters):
    """Turns the filter dict into a readable string."""
    parts = []
    for key, crit in filters.items():
        parts.append(f"{key} {crit['op']} {crit.get('value', crit.get('contains', ''))}")
    return " AND ".join(parts)

# --- WORKER ---
def audit_region_analyzer(region):
    """
    Audits all Access Analyzer components in a single region.
    """
    analyzer_client = boto3.client('accessanalyzer', region_name=region)
    
    res_analyzers = []
    res_findings = []
    res_rules = []
    
    try:
        # --- 1. List Analyzers ---
        analyzers = analyzer_client.list_analyzers(type='ACCOUNT').get('analyzers', [])
        # Check for Org analyzers too, if this is the delegated admin
        try:
            analyzers.extend(analyzer_client.list_analyzers(type='ORGANIZATION').get('analyzers', []))
        except ClientError:
            pass # Fails if not an org account, which is fine

        if not analyzers:
            res_analyzers.append({'Region': region, 'Analyzer Name': 'N/A', 'Status': 'DISABLED', 'Type': 'N/A'})
            return res_analyzers, res_findings, res_rules

        for a_summary in analyzers:
            analyzer_name = a_summary['name']
            analyzer_arn = a_summary['arn']
            
            try:
                # Get full analyzer details
                analyzer = analyzer_client.get_analyzer(analyzerName=analyzer_name)['analyzer']
                file_ref = save_raw_json(DIR_ANALYZER, f"{region}_{analyzer_name}.json", analyzer)
                
                res_analyzers.append({
                    'Region': region,
                    'Analyzer Name': analyzer_name,
                    'Status': analyzer['status'],
                    'Type': analyzer['type'],
                    'Last Scanned': analyzer.get('lastResourceAnalyzedAt'),
                    'ARN': analyzer_arn,
                    'Full Detail File': file_ref
                })
                
                # --- 2. List Active Findings for this Analyzer ---
                paginator = analyzer_client.get_paginator('list_findings')
                for page in paginator.paginate(analyzerArn=analyzer_arn, filter={'status': {'eq': ['ACTIVE']}}):
                    for finding in page['findings']:
                        # Get full finding details
                        full_finding = analyzer_client.get_finding(analyzerArn=analyzer_arn, id=finding['id'])['finding']
                        finding_file = save_raw_json(DIR_FINDING, f"{region}_{finding['id']}.json", full_finding)
                        
                        res_findings.append({
                            'Region': region,
                            'Severity': full_finding['severity'],
                            'Status': full_finding['status'],
                            'Resource': full_finding['resource'],
                            'Resource Type': full_finding['resourceType'],
                            'Principal': flatten_finding_principal(full_finding.get('principal', {})),
                            'Action': ", ".join(full_finding.get('action', [])),
                            'Is Public': full_finding.get('isPublic', False),
                            'First Seen': full_finding['createdAt'],
                            'Last Seen': full_finding['updatedAt'],
                            'Finding ID': full_finding['id'],
                            'Full Detail File': finding_file
                        })
                
                # --- 3. List Archive Rules for this Analyzer ---
                paginator = analyzer_client.get_paginator('list_archive_rules')
                for page in paginator.paginate(analyzerName=analyzer_name):
                    for rule in page['archiveRules']:
                        rule_name = rule['ruleName']
                        full_rule = analyzer_client.get_archive_rule(analyzerName=analyzer_name, ruleName=rule_name)
                        rule_file = save_raw_json(DIR_RULE, f"{region}_{analyzer_name}_{rule_name}.json", full_rule)
                        
                        res_rules.append({
                            'Region': region,
                            'Analyzer Name': analyzer_name,
                            'Rule Name': rule_name,
                            'Filter Criteria': flatten_archive_rule_filter(rule['filter']),
                            'Created': rule['createdAt'],
                            'Full Detail File': rule_file
                        })

            except ClientError as e:
                print(f"[{region}] Error processing analyzer {analyzer_name}: {e}")

    except ClientError as e:
        if "AccessDeniedException" in str(e) or "UnrecognizedClientException" in str(e):
             res_analyzers.append({'Region': region, 'Analyzer Name': 'N/A', 'Status': 'DISABLED (AccessDenied)', 'Type': 'N/A'})
        else:
            print(f"[{region}] Error: {e}")
            res_analyzers = [{'Region': region, 'Analyzer Name': 'N/A', 'Status': f'Error: {e}', 'Type': 'N/A'}]

    return res_analyzers, res_findings, res_rules

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS IAM Access Analyzer Ultimate Audit ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_analyzers, all_findings, all_rules = [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_analyzer, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                a, f, r = future.result()
                all_analyzers.extend(a)
                all_findings.extend(f)
                all_rules.extend(r)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_analyzers = pd.DataFrame(all_analyzers)
    df_findings = pd.DataFrame(all_findings)
    df_rules = pd.DataFrame(all_rules)
    
    # Sort
    if not df_analyzers.empty: df_analyzers = df_analyzers.sort_values(by=['Region', 'Analyzer Name'])
    if not df_findings.empty:
        # Sort by Severity, then Last Seen. This is your "to-do list"
        severity_map = {'HIGH': 0, 'MEDIUM': 1, 'LOW': 2, 'INFORMATIONAL': 3, 'N/A': 4}
        df_findings['SeveritySort'] = df_findings['Severity'].map(severity_map)
        df_findings = df_findings.sort_values(by=['SeveritySort', 'Last Seen'], ascending=[True, False])
        df_findings = df_findings.drop(columns=['SeveritySort'])
    if not df_rules.empty:
        df_rules = df_rules.sort_values(by=['Region', 'Analyzer Name', 'Rule Name'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_analyzers.to_excel(writer, sheet_name='Analyzers (by Region)', index=False)
            df_findings.to_excel(writer, sheet_name='Active Findings (Exploded)', index=False)
            df_rules.to_excel(writer, sheet_name='Archive Rules (Exploded)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_EXCEL = "s3_comprehensive_audit.xlsx"
POLICY_DIR = "s3_bucket_policies"
DETAILS_DIR = "s3_bucket_details"  # All other JSON files go here
MAX_WORKERS = 50

for d in [POLICY_DIR, DETAILS_DIR]:
    if not os.path.exists(d):
        os.makedirs(d)

def format_err(api_name, e):
    """Returns strict Error Code to avoid leaking Account IDs."""
    error_code = e.response.get('Error', {}).get('Code', 'UnknownError')
    return f"[{api_name}] {error_code}"

def save_json_to_file(directory, filename_prefix, data, bucket_name):
    """Saves a data object to a formatted JSON file."""
    filename = f"{filename_prefix}_{bucket_name}.json"
    filepath = os.path.join(directory, filename)
    
    try:
        if isinstance(data, str): data = json.loads(data)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)
        return filename
    except Exception as e:
        return f"ErrorSavingFile: {str(e)}"

def parse_acl_summary(acl_data):
    """Parses ACL grants to find public access."""
    if 'Grants' not in acl_data: return "ErrorParsingACL"
    public_grants = []
    uris = {
        "http://acs.amazonaws.com/groups/global/AllUsers": "PUBLIC",
        "http://acs.amazonaws.com/groups/global/AuthenticatedUsers": "AUTH_USERS"
    }
    for grant in acl_data['Grants']:
        grantee = grant.get('Grantee', {})
        if grantee.get('Type') == 'Group' and grantee.get('URI') in uris:
            public_grants.append(f"{uris[grantee['URI']]}_{grant['Permission']}")
    return ", ".join(sorted(list(set(public_grants)))) or "Private"


def get_bucket_data(bucket_name, creation_date):
    """
    Worker function: queries ONE bucket for ~26 attributes.
    """
    s3_generic = boto3.client('s3')
    arn = f"arn:aws:s3:::{bucket_name}"
    data = {'Bucket Name': bucket_name, 'ARN': arn, 'Creation Date': creation_date.replace(tzinfo=None)}

    # 1. Region
    try:
        loc_resp = s3_generic.get_bucket_location(Bucket=bucket_name)
        region = loc_resp['LocationConstraint'] or 'us-east-1'
        data['Region'] = region
    except ClientError as e:
        data['Region'] = 'us-east-1'
        data['Meta Error'] = format_err('GetBucketLocation', e)
        region = 'us-east-1'

    s3 = boto3.client('s3', region_name=region)

    # --- ACCESS & SECURITY (10 checks) ---
    try: # 2. Policy
        pol_resp = s3.get_bucket_policy(Bucket=bucket_name)
        data['Policy File'] = save_json_to_file(POLICY_DIR, "policy", pol_resp['Policy'], bucket_name)
    except ClientError as e:
        data['Policy File'] = "No Policy" if 'NoSuchBucketPolicy' in str(e) else format_err('GetBucketPolicy', e)

    try: # 3. Public Access Block
        pab = s3.get_public_access_block(Bucket=bucket_name)
        conf = pab['PublicAccessBlockConfiguration']
        data['PAB'] = f"BlockACLs:{conf['BlockPublicAcls']},BlockPolicy:{conf['BlockPublicPolicy']}"
    except ClientError as e:
        data['PAB'] = "Not Configured" if 'NoSuchPublicAccessBlock' in str(e) else format_err('GetPublicAccessBlock', e)

    try: # 4. ACLs
        acl = s3.get_bucket_acl(Bucket=bucket_name)
        data['ACL Summary'] = parse_acl_summary(acl)
        data['ACL File'] = save_json_to_file(DETAILS_DIR, "acl", acl, bucket_name)
    except ClientError as e:
        data['ACL Summary'] = format_err('GetBucketAcl', e)

    try: # 5. Ownership Controls (NEW)
        own = s3.get_bucket_ownership_controls(Bucket=bucket_name)
        data['Ownership Controls'] = own['OwnershipControls']['Rules'][0]['ObjectOwnership']
    except ClientError as e:
        data['Ownership Controls'] = "Not Set" if 'OwnershipControlsNotFoundError' in str(e) else format_err('GetOwnershipControls', e)
        
    try: # 6. Encryption
        enc = s3.get_bucket_encryption(Bucket=bucket_name)
        rule = enc['ServerSideEncryptionConfiguration']['Rules'][0]
        data['Encryption'] = rule['ApplyServerSideEncryptionByDefault']['SSEAlgorithm']
        # 7. Bucket Key (NEW)
        data['Bucket Key'] = rule.get('BucketKeyEnabled', False)
    except ClientError as e:
        if 'ServerSideEncryptionConfigurationNotFoundError' in str(e):
            data['Encryption'] = "Not Encrypted"
            data['Bucket Key'] = "N/A"
        else:
            data['Encryption'] = format_err('GetBucketEncryption', e)
            
    try: # 8. Object Lock
        lock = s3.get_object_lock_configuration(Bucket=bucket_name)
        data['Object Lock'] = lock['ObjectLockConfiguration']['ObjectLockEnabled']
    except ClientError as e:
        data['Object Lock'] = "Disabled" if 'ObjectLockConfigurationNotFoundError' in str(e) else format_err('GetObjectLock', e)

    try: # 9. Versioning
        ver = s3.get_bucket_versioning(Bucket=bucket_name)
        data['Versioning'] = ver.get('Status', 'Disabled')
        # 10. MFA Delete (NEW)
        data['MFA Delete'] = ver.get('MFADelete', 'Disabled')
    except ClientError as e:
        data['Versioning'] = format_err('GetBucketVersioning', e)

    # --- FEATURES (10 checks) ---
    try: # 11. Logging
        log = s3.get_bucket_logging(Bucket=bucket_name)
        data['Logging'] = f"Target:{log['LoggingEnabled']['TargetBucket']}" if 'LoggingEnabled' in log else "Disabled"
    except ClientError as e: data['Logging'] = format_err('GetBucketLogging', e)

    try: # 12. Website Hosting
        s3.get_bucket_website(Bucket=bucket_name)
        data['Website Hosting'] = "Enabled"
    except ClientError as e: data['Website Hosting'] = "Disabled" if 'NoSuchWebsiteConfiguration' in str(e) else format_err('GetBucketWebsite', e)

    try: # 13. Tags
        tags = s3.get_bucket_tagging(Bucket=bucket_name)
        data['Tags'] = "; ".join([f"{t['Key']}={t['Value']}" for t in tags['TagSet']])
    except ClientError as e: data['Tags'] = "No Tags" if 'NoSuchTagSet' in str(e) else format_err('GetBucketTagging', e)

    try: # 14. CORS
        cors = s3.get_bucket_cors(Bucket=bucket_name)
        data['CORS File'] = save_json_to_file(DETAILS_DIR, "cors", cors, bucket_name)
        data['CORS Rules'] = len(cors.get('CORSRules', [])) # 15. CORS Rule Count
    except ClientError as e: data['CORS File'] = "None" if 'NoSuchCORSConfiguration' in str(e) else format_err('GetBucketCors', e)

    try: # 16. Replication
        rep = s3.get_bucket_replication(Bucket=bucket_name)
        data['Replication File'] = save_json_to_file(DETAILS_DIR, "replication", rep, bucket_name)
        data['Replication Rules'] = len(rep['ReplicationConfiguration']['Rules']) # 17. Replication Rule Count
    except ClientError as e: data['Replication File'] = "Disabled" if 'ReplicationConfigurationNotFoundError' in str(e) else format_err('GetReplication', e)

    try: # 18. Event Notifications
        notify = s3.get_bucket_notification_configuration(Bucket=bucket_name)
        notify.pop('ResponseMetadata', None)
        if not any(notify.values()):
             data['Notifications File'] = "None"
        else:
             data['Notifications File'] = save_json_to_file(DETAILS_DIR, "notifications", notify, bucket_name)
    except ClientError as e: data['Notifications File'] = format_err('GetBucketNotification', e)

    try: # 19. Requester Pays (NEW)
        pay = s3.get_bucket_request_payment(Bucket=bucket_name)
        data['Requester Pays'] = pay['Payer']
    except ClientError as e: data['Requester Pays'] = format_err('GetRequestPayment', e)

    try: # 20. Transfer Acceleration (NEW)
        acc = s3.get_bucket_accelerate_configuration(Bucket=bucket_name)
        data['Acceleration'] = acc.get('Status', 'Suspended')
    except ClientError as e: data['Acceleration'] = format_err('GetAccelerate', e)

    # --- COST & OPS (6 checks) ---
    try: # 21. Lifecycle
        life = s3.get_bucket_lifecycle_configuration(Bucket=bucket_name)
        data['Lifecycle File'] = save_json_to_file(DETAILS_DIR, "lifecycle", life, bucket_name)
        data['Lifecycle Rules'] = len(life['Rules']) # 22. Lifecycle Rule Count
    except ClientError as e: data['Lifecycle File'] = "None" if 'NoSuchLifecycleConfiguration' in str(e) else format_err('GetLifecycle', e)

    try: # 23. Inventory
        inv = s3.list_bucket_inventory_configurations(Bucket=bucket_name)
        data['Inventory Configs'] = len(inv.get('InventoryConfigurationList', []))
    except ClientError as e: data['Inventory Configs'] = format_err('ListInventory', e)

    try: # 24. Analytics
        ana = s3.list_bucket_analytics_configurations(Bucket=bucket_name)
        data['Analytics Configs'] = len(ana.get('AnalyticsConfigurationList', []))
    except ClientError as e: data['Analytics Configs'] = format_err('ListAnalytics', e)

    try: # 25. Metrics
        met = s3.list_bucket_metrics_configurations(Bucket=bucket_name)
        data['Metrics Configs'] = len(met.get('MetricsConfigurationList', []))
    except ClientError as e: data['Metrics Configs'] = format_err('ListMetrics', e)

    try: # 26. Intelligent Tiering
        tier = s3.list_bucket_intelligent_tiering_configurations(Bucket=bucket_name)
        data['Int-Tiering Configs'] = len(tier.get('IntelligentTieringConfigurationList', []))
    except ClientError as e: data['Int-Tiering Configs'] = format_err('ListIntTiering', e)

    return data

def main():
    start_time = time.time()
    print(f"--- AWS S3 Comprehensive Audit (25+ Properties) ---")
    print(f"Policy files: ./{POLICY_DIR}/")
    print(f"Detail files: ./{DETAILS_DIR}/")
    
    s3 = boto3.client('s3')
    
    print("1. Listing Buckets...")
    try:
        buckets_raw = s3.list_buckets()
        buckets = buckets_raw['Buckets']
        total = len(buckets)
        print(f"   Found {total} buckets.")
    except Exception as e:
        print(f"CRITICAL ERROR: Could not list buckets. {e}")
        return

    results = []
    processed = 0

    print(f"2. Starting Parallel Audit ({MAX_WORKERS} threads)...")
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_bucket = {executor.submit(get_bucket_data, b['Name'], b['CreationDate']): b for b in buckets}
        
        for future in as_completed(future_to_bucket):
            processed += 1
            try:
                data = future.result()
                results.append(data)
                print(f"\r   Progress: {processed}/{total} ({data.get('Bucket Name', 'Error')})", end="")
            except Exception as exc:
                print(f"\n   Exception in thread: {exc}")

    print("\n\n3. Compiling Excel file...")
    df = pd.DataFrame(results)
    
    # Organize columns logically
    cols_id = ['Bucket Name', 'ARN', 'Region', 'Creation Date', 'Tags']
    cols_access = ['PAB', 'Policy File', 'ACL Summary', 'Ownership Controls']
    cols_dataprot = ['Encryption', 'Bucket Key', 'Versioning', 'MFA Delete', 'Object Lock', 'Replication File']
    cols_costops = ['Lifecycle Rules', 'Inventory Configs', 'Analytics Configs', 'Metrics Configs', 'Int-Tiering Configs']
    cols_features = ['Logging', 'Website Hosting', 'Requester Pays', 'Acceleration', 'CORS Rules', 'Notifications File']
    
    ordered_cols = cols_id + cols_access + cols_dataprot + cols_costops + cols_features
    remaining_cols = [c for c in df.columns if c not in ordered_cols]
    df = df[ordered_cols + remaining_cols]
    
    try:
        df.to_excel(OUTPUT_EXCEL, index=False)
        duration = time.time() - start_time
        print(f"✅ SUCCESS.")
        print(f"   Excel Report: {OUTPUT_EXCEL}")
        print(f"   Time taken: {round(duration, 2)} seconds")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
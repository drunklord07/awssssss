import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "shield_ultimate_audit.xlsx"
SHIELD_REGION = "us-east-1"  # Shield Advanced API is global, homed in us-east-1

# Folders for 100% raw JSON details
DIR_SUB = "details_shield_subscription"
DIR_PROT = "details_shield_protections"
DIR_GROUP = "details_shield_groups"
DIR_ATTACK = "details_shield_attacks"

for d in [DIR_SUB, DIR_PROT, DIR_GROUP, DIR_ATTACK]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def flatten_attack_vectors(vectors):
    """Converts the attack vector list to a readable string."""
    if not vectors: return "N/A"
    lines = []
    for v in vectors:
        line = f"Type: {v.get('AttackType')}, Volume: {v.get('Volume', {}).get('BitsPerSecond', {}).get('Value', 'N/A')} bps"
        lines.append(line)
    return "\n".join(lines)

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Shield Advanced Ultimate Audit ---")
    print(f"Auditing from required region: {SHIELD_REGION}")
    
    # Shield is a global service, but its API endpoint is in us-east-1
    try:
        shield = boto3.client('shield', region_name=SHIELD_REGION)
    except Exception as e:
        print(f"Error creating client: {e}")
        return

    res_subscription = []
    res_protections = []
    res_groups = []
    res_attacks = []

    # --- 1. Audit Subscription ---
    try:
        sub = shield.describe_subscription()['Subscription']
        print("Subscription Status: ACTIVE")
        save_raw_json(DIR_SUB, "subscription.json", sub)
        
        res_subscription.append({'Setting': 'Subscription Active', 'Value': 'Yes'})
        res_subscription.append({'Setting': 'Start Time', 'Value': sub.get('StartTime')})
        res_subscription.append({'Setting': 'Time Commitment (Months)', 'Value': sub.get('TimeCommitmentInSeconds', 0) / (60*60*24*30)})
        res_subscription.append({'Setting': 'Auto-Renew', 'Value': sub.get('AutoRenew')})

    except ClientError as e:
        if 'ResourceNotFoundException' in str(e):
            print("Subscription Status: NOT SUBSCRIBED")
            res_subscription.append({'Setting': 'Subscription Active', 'Value': 'No'})
            df_sub = pd.DataFrame(res_subscription)
            df_sub.to_excel(OUTPUT_FILE, sheet_name='Subscription & DRT', index=False)
            print("✅ DONE. Report saved. No other data to fetch.")
            return
        else:
            print(f"Error describing subscription: {e}")
            return

    # --- 2. Audit DRT Access & Contacts ---
    try:
        drt = shield.describe_drt_access()
        save_raw_json(DIR_SUB, "drt_access.json", drt)
        res_subscription.append({'Setting': 'DRT Role ARN', 'Value': drt.get('RoleArn', 'Not Configured')})
    except ClientError:
        res_subscription.append({'Setting': 'DRT Role ARN', 'Value': 'Not Configured'})

    try:
        contacts = shield.describe_emergency_contact_settings()
        save_raw_json(DIR_SUB, "emergency_contacts.json", contacts)
        contact_list = [c['EmailAddress'] for c in contacts.get('EmergencyContactList', [])]
        res_subscription.append({'Setting': 'Emergency Contacts', 'Value': ", ".join(contact_list) or "None"})
    except ClientError:
        res_subscription.append({'Setting': 'Emergency Contacts', 'Value': 'Error'})
        
    # --- 3. Audit Protected Resources ---
    print("Fetching protected resources...")
    paginator = shield.get_paginator('list_protections')
    for page in paginator.paginate():
        for prot in page['Protections']:
            prot_id = prot['Id']
            # Get full details
            try:
                details = shield.describe_protection(ProtectionId=prot_id)['Protection']
                file_ref = save_raw_json(DIR_PROT, f"{prot_id}.json", details)
                
                res_protections.append({
                    'Name': details.get('Name'),
                    'Resource ARN': details.get('ResourceArn'),
                    'Protection ID': prot_id,
                    'Full Detail File': file_ref
                })
            except ClientError as e:
                print(f"Error describing protection {prot_id}: {e}")

    # --- 4. Audit Protection Groups ---
    print("Fetching protection groups...")
    paginator = shield.get_paginator('list_protection_groups')
    for page in paginator.paginate():
        for group in page['ProtectionGroups']:
            gid = group['ProtectionGroupId']
            file_ref = save_raw_json(DIR_GROUP, f"{gid.replace('/', '_')}.json", group)
            res_groups.append({
                'Group Name': group['ProtectionGroupId'],
                'Pattern': group['Pattern'],
                'Aggregation': group['Aggregation'],
                'Members Count': len(group['Members']),
                'Full Detail File': file_ref
            })

    # --- 5. Audit Attack History ---
    print("Fetching attack history...")
    paginator = shield.get_paginator('list_attacks')
    for page in paginator.paginate(): # Can add StartTime/EndTime here
        for summary in page['AttackSummaries']:
            attack_id = summary['AttackId']
            try:
                attack = shield.describe_attack(AttackId=attack_id)['Attack']
                file_ref = save_raw_json(DIR_ATTACK, f"{attack_id}.json", attack)
                
                res_attacks.append({
                    'Start Time': attack.get('StartTime'),
                    'End Time': attack.get('EndTime'),
                    'Resource ARN': attack.get('ResourceArn'),
                    'Attack Type': ", ".join(sorted(list(set([v['AttackType'] for v in attack.get('AttackVectors', [])])))),
                    'Attack Vectors (Summary)': flatten_attack_vectors(attack.get('AttackVectors')),
                    'Attack ID': attack_id,
                    'Full Detail File': file_ref
                })
            except ClientError as e:
                print(f"Error describing attack {attack_id}: {e}")

    # --- 6. Compile Excel Report ---
    print("Compiling Excel Report...")
    df_sub = pd.DataFrame(res_subscription)
    df_prot = pd.DataFrame(res_protections)
    df_group = pd.DataFrame(res_groups)
    df_attack = pd.DataFrame(res_attacks)

    if not df_attack.empty:
        df_attack = df_attack.sort_values(by=['Start Time'], ascending=False)

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_sub.to_excel(writer, sheet_name='Subscription & DRT', index=False, header=False)
            df_prot.to_excel(writer, sheet_name='Protected Resources', index=False)
            df_group.to_excel(writer, sheet_name='Protection Groups', index=False)
            df_attack.to_excel(writer, sheet_name='Attack History', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
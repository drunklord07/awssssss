import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "securityhub_ultimate_audit.xlsx"
MAX_WORKERS = 20  # Security Hub has low API limits, don't set this too high

# Folders for 100% raw JSON details (CONFIGURATIONS ONLY)
DIR_HUB = "details_securityhub_hubs"
DIR_STANDARDS = "details_securityhub_standards"
DIR_PRODUCTS = "details_securityhub_products"
DIR_ADMIN = "details_securityhub_admin"

for d in [DIR_HUB, DIR_STANDARDS, DIR_PRODUCTS, DIR_ADMIN]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def flatten_finding(finding, region):
    """Flattens the complex finding JSON into a single dict for Excel."""
    resources = finding.get('Resources', [{}])
    severity = finding.get('Severity', {})
    compliance = finding.get('Compliance', {})
    workflow = finding.get('Workflow', {})
    
    return {
        'Region': region,
        'Severity': severity.get('Label', 'N/A'),
        'Title': finding.get('Title', 'N/A'),
        'Status': workflow.get('Status', 'N/A'),
        'Compliance Status': compliance.get('Status', 'N/A'),
        'Resource Type': resources[0].get('Type', 'N/A'),
        'Resource ID': resources[0].get('Id', 'N/A'),
        'Product Name': finding.get('ProductName', 'N/A'),
        'First Observed': finding.get('FirstObservedAt'),
        'Last Observed': finding.get('LastObservedAt'),
        'Finding ID': finding.get('Id')
    }

# --- WORKER ---
def audit_region_securityhub(region):
    """
    Audits all Security Hub components in a single region.
    """
    sechub = boto3.client('securityhub', region_name=region)
    
    res_hub = {}
    res_findings = []
    res_standards = []
    res_products = []
    
    # --- 1. Audit Hub Configuration ---
    try:
        hub = sechub.describe_hub()['HubArn']
        res_hub = {'Region': region, 'Status': 'ENABLED', 'Hub ARN': hub}
        save_raw_json(DIR_HUB, f"{region}_hub.json", res_hub)
    except ClientError as e:
        # This exception means Security Hub is NOT enabled in this region
        if 'InvalidAccessException' in str(e):
            res_hub = {'Region': region, 'Status': 'DISABLED', 'Hub ARN': 'N/A'}
            return res_hub, res_findings, res_standards, res_products
        else:
            res_hub = {'Region': region, 'Status': f"Error: {e}", 'Hub ARN': 'N/A'}
            return res_hub, res_findings, res_standards, res_products

    # --- 2. Audit Enabled Standards ---
    try:
        paginator = sechub.get_paginator('get_enabled_standards')
        for page in paginator.paginate():
            for std in page['StandardsSubscriptions']:
                res_standards.append({
                    'Region': region,
                    'Standard Name': std['StandardsSubscriptionArn'].split('/')[-1],
                    'Status': std['SubscriptionStatus'],
                    'Standard ARN': std['StandardsSubscriptionArn']
                })
        save_raw_json(DIR_STANDARDS, f"{region}_standards.json", res_standards)
    except ClientError:
        pass # Errors if hub is disabled, which we already caught

    # --- 3. Audit Enabled Products ---
    try:
        paginator = sechub.get_paginator('list_enabled_products_for_admin')
        for page in paginator.paginate():
            for prod in page['ProductSubscriptions']:
                res_products.append({
                    'Region': region,
                    'Product Name': prod['ProductArn'].split('/')[-1],
                    'Status': prod['SubscriptionStatus'],
                    'Product ARN': prod['ProductArn']
                })
        save_raw_json(DIR_PRODUCTS, f"{region}_products.json", res_products)
    except ClientError:
        pass

    # --- 4. Audit Active Findings (The Big One) ---
    try:
        paginator = sechub.get_paginator('get_findings')
        # We ONLY want ACTIVE findings
        filter_criteria = {'RecordState': [{'Value': 'ACTIVE', 'Comparison': 'EQUALS'}]}
        
        for page in paginator.paginate(Filters=filter_criteria):
            for finding in page['Findings']:
                res_findings.append(flatten_finding(finding, region))
    except ClientError:
        pass

    return res_hub, res_findings, res_standards, res_products

def audit_organization_admin():
    """Checks for a Security Hub Delegated Administrator."""
    res_admins = []
    # This API only works in us-east-1, but it's global
    try:
        client = boto3.client('securityhub', region_name='us-east-1')
        paginator = client.get_paginator('list_organization_admin_accounts')
        for page in paginator.paginate():
            for admin in page['AdminAccounts']:
                res_admins.append(admin)
        
        save_raw_json(DIR_ADMIN, "delegated_admins.json", res_admins)
                
    except ClientError as e:
        if "AccessDenied" in str(e):
            return [{'AdminAccountId': 'AccessDenied', 'AdminStatus': 'N/A'}]
    except Exception:
        # Fails if not an org
        return [{'AdminAccountId': 'Not an Org or Error', 'AdminStatus': 'N/A'}]
        
    if not res_admins:
        return [{'AdminAccountId': 'None', 'AdminStatus': 'None'}]
    
    return res_admins

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Security Hub Ultimate Audit (Config & Findings) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_hubs, all_findings, all_standards, all_products = [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_securityhub, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                hub, findings, standards, products = future.result()
                all_hubs.append(hub)
                all_findings.extend(findings)
                all_standards.extend(standards)
                all_products.extend(products)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\nChecking for Delegated Administrator...")
    all_admins = audit_organization_admin()

    print("Compiling Excel Report...")

    # Create DataFrames
    df_hubs = pd.DataFrame(all_hubs)
    df_findings = pd.DataFrame(all_findings)
    df_standards = pd.DataFrame(all_standards)
    df_products = pd.DataFrame(all_products)
    df_admins = pd.DataFrame(all_admins)
    
    # Sort
    if not df_hubs.empty: df_hubs = df_hubs.sort_values(by=['Region'])
    if not df_findings.empty:
        # Sort by Severity, then Last Observed. This is your "to-do list"
        severity_map = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3, 'INFORMATIONAL': 4, 'N/A': 5}
        df_findings['SeveritySort'] = df_findings['Severity'].map(severity_map)
        df_findings = df_findings.sort_values(by=['SeveritySort', 'Last Observed'], ascending=[True, False])
        df_findings = df_findings.drop(columns=['SeveritySort'])
        
    if not df_standards.empty: df_standards = df_standards.sort_values(by=['Region', 'Standard Name'])
    if not df_products.empty: df_products = df_products.sort_values(by=['Region', 'Product Name'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_hubs.to_excel(writer, sheet_name='Security Hub (by Region)', index=False)
            df_findings.to_excel(writer, sheet_name='Active Findings (Exploded)', index=False)
            df_standards.to_excel(writer, sheet_name='Enabled Standards', index=False)
            df_products.to_excel(writer, sheet_name='Enabled Products', index=False)
            df_admins.to_excel(writer, sheet_name='Delegated Admins (Org)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
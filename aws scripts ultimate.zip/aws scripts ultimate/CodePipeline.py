import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import re

# --- CONFIGURATION ---
OUTPUT_FILE = "codepipeline_ultimate_audit.xlsx"
MAX_WORKERS = 15
RECENT_EXECUTIONS_COUNT = 10
# Keywords to search for in action configurations
SECRET_KEYWORDS = re.compile(r'PASSWORD|SECRET|API_KEY|TOKEN|ACCESS_KEY|PRIVATE_KEY', re.IGNORECASE)

# Folders for 100% raw JSON details
DIR_PIPELINE = "details_codepipeline_pipelines"
DIR_EXECUTION = "details_codepipeline_executions"

for d in [DIR_PIPELINE, DIR_EXECUTION]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def check_for_secrets(config_dict, key_name=""):
    """
    Recursively checks a dictionary for keys matching SECRET_KEYWORDS.
    Returns a list of (key, value) tuples for plaintext secrets.
    """
    found_secrets = []
    if isinstance(config_dict, dict):
        for k, v in config_dict.items():
            if isinstance(v, (dict, list)):
                found_secrets.extend(check_for_secrets(v, k))
            elif isinstance(v, str) and SECRET_KEYWORDS.search(k):
                # Found a suspicious key!
                # We check if the value is a secret from Secrets Manager or SSM
                if not (v.startswith('arn:aws:secretsmanager') or v.startswith('arn:aws:ssm') or '{{resolve:secretsmanager' in v or '{{resolve:ssm' in v):
                    found_secrets.append((k, v)) # Found a plaintext secret!
    elif isinstance(config_dict, list):
        for item in config_dict:
             # Specifically for CodeBuild environment variables
            if isinstance(item, dict) and item.get('name') and item.get('type') == 'PLAINTEXT':
                if SECRET_KEYWORDS.search(item['name']):
                     if not (item['value'].startswith('arn:aws:secretsmanager') or item['value'].startswith('arn:aws:ssm') or '{{resolve:secretsmanager' in item['value'] or '{{resolve:ssm' in item['value']):
                        found_secrets.append((item['name'], item['value']))
    return found_secrets

# --- WORKER ---
def audit_region_codepipeline(region):
    """
    Audits all CodePipeline components in a single region.
    """
    codepipeline = boto3.client('codepipeline', region_name=region)
    
    res_pipelines, res_actions, res_secrets, res_executions = [], [], [], []
    
    try:
        # --- 1. Audit Pipelines ---
        paginator = codepipeline.get_paginator('list_pipelines')
        for page in paginator.paginate():
            for pipe_summary in page['pipelines']:
                pipe_name = pipe_summary['name']
                
                try:
                    # Get full pipeline definition
                    pipe = codepipeline.get_pipeline(name=pipe_name)
                    
                    full_data = pipe.copy()
                    pipe_def = pipe.pop('pipeline')
                    full_data.pop('ResponseMetadata', None)
                    
                    # Save raw JSON
                    file_ref = save_raw_json(DIR_PIPELINE, f"{region}_{pipe_name}", full_data)
                    
                    # Get artifact store encryption
                    artifact_store = pipe_def.get('artifactStore', {})
                    if 'encryptionKey' in artifact_store:
                        encryption = f"KMS: {artifact_store['encryptionKey']['id']}"
                    else:
                        encryption = "Default (SSE-S3)"

                    # Check for triggers
                    triggers = [t['provider'] for t in pipe_def.get('triggers', [])]
                    
                    # --- 2. Explode Actions & Check for Secrets ---
                    hardcoded_secret_found = "No"
                    
                    for stage_idx, stage in enumerate(pipe_def.get('stages', [])):
                        for action_idx, action in enumerate(stage.get('actions', [])):
                            config = action.get('configuration', {})
                            
                            # Check for secrets
                            found_secrets = check_for_secrets(config.get('EnvironmentVariables', [])) # For CodeBuild
                            
                            if found_secrets:
                                hardcoded_secret_found = "YES (CRITICAL)"
                                for key, value in found_secrets:
                                    res_secrets.append({
                                        'Region': region,
                                        'Pipeline Name': pipe_name,
                                        'Stage': stage['name'],
                                        'Action': action['name'],
                                        'Secret Key': key,
                                        'Plaintext Value': value # SECURITY: This will be in the Excel
                                    })
                            
                            res_actions.append({
                                'Region': region,
                                'Pipeline Name': pipe_name,
                                'Stage': stage['name'],
                                'Stage Order': stage_idx + 1,
                                'Action': action['name'],
                                'Action Order': action_idx + 1,
                                'Provider': action['actionTypeId']['provider'],
                                'Category': action['actionTypeId']['category'],
                                'IAM Role ARN': action.get('roleArn', 'N/A'),
                                'Run Order': action.get('runOrder', 1),
                                'Configuration (Potential Secrets)': json.dumps(config)
                            })
                    
                    # --- Build Excel Row for Pipeline ---
                    res_pipelines.append({
                        'Region': region,
                        'Pipeline Name': pipe_name,
                        'ARN': pipe_def['artifactStore'].get('location', 'N/A'), # S3 bucket
                        'Service Role ARN': pipe_def['roleArn'],
                        'Artifact Store Encryption': encryption,
                        'Hardcoded Secrets?': hardcoded_secret_found,
                        'Trigger Type': ", ".join(triggers) or "POLL (Default)",
                        'Stage Count': len(pipe_def.get('stages', [])),
                        'Full Detail File': file_ref
                    })

                    # --- 3. Get Execution History ---
                    exec_paginator = codepipeline.get_paginator('list_pipeline_executions')
                    for exec_page in exec_paginator.paginate(pipelineName=pipe_name, maxResults=RECENT_EXECUTIONS_COUNT):
                        for exec_summary in exec_page['pipelineExecutionSummaries']:
                            file_ref = save_raw_json(DIR_EXECUTION, f"{region}_{exec_summary['pipelineExecutionId']}", exec_summary)
                            res_executions.append({
                                'Region': region,
                                'Pipeline Name': pipe_name,
                                'Status': exec_summary['status'],
                                'Start Time': exec_summary['startTime'].replace(tzinfo=None),
                                'Last Update': exec_summary['lastUpdateTime'].replace(tzinfo=None),
                                'Trigger': exec_summary.get('trigger', {}).get('triggerType', 'N/A'),
                                'Execution ID': exec_summary['pipelineExecutionId'],
                                'Full Detail File': file_ref
                            })
                            
                except ClientError as e:
                    print(f"\n[{region}] Error describing pipeline {pipe_name}: {e}")

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_pipelines, res_actions, res_secrets, res_executions

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS CodePipeline Ultimate Audit (Pipelines, Actions, Secrets) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_p, all_a, all_s, all_e = [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_codepipeline, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                p, a, s, e = future.result()
                all_p.extend(p); all_a.extend(a); all_s.extend(s); all_e.extend(e)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_pipes = pd.DataFrame(all_p)
    df_actions = pd.DataFrame(all_a)
    df_secrets = pd.DataFrame(all_s)
    df_execs = pd.DataFrame(all_e)
    
    # Sort
    if not df_pipes.empty: df_pipes = df_pipes.sort_values(by=['Hardcoded Secrets?', 'Region', 'Pipeline Name'], ascending=[False, True, True])
    if not df_actions.empty: df_actions = df_actions.sort_values(by=['Region', 'Pipeline Name', 'Stage Order', 'Action Order'])
    if not df_execs.empty:
        status_priority = {'Failed': 0, 'Stopped': 1, 'Superseded': 2, 'InProgress': 3, 'Succeeded': 4}
        df_execs['StatusSort'] = df_execs['Status'].map(status_priority)
        df_execs = df_execs.sort_values(by=['Pipeline Name', 'StatusSort', 'Start Time'], ascending=[True, True, False])
        df_execs = df_execs.drop(columns=['StatusSort'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_pipes.to_excel(writer, sheet_name='Pipelines (Master List)', index=False)
            df_actions.to_excel(writer, sheet_name='Pipeline Actions (Exploded)', index=False)
            df_secrets.to_excel(writer, sheet_name='Hardcoded Secrets (CRITICAL)', index=False)
            df_execs.to_excel(writer, sheet_name='Execution History (Last 10)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
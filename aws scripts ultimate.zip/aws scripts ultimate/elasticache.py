import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "elasticache_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_REP_GROUP = "details_elasticache_rep_groups"
DIR_CLUSTER = "details_elasticache_clusters"
DIR_SUBNET = "details_elasticache_subnet_groups"
DIR_PARAM = "details_elasticache_param_groups"
DIR_SNAP = "details_elasticache_snapshots"

for d in [DIR_REP_GROUP, DIR_CLUSTER, DIR_SUBNET, DIR_PARAM, DIR_SNAP]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

# --- WORKER ---
def audit_region_elasticache(region):
    """
    Audits all ElastiCache components in a single region.
    """
    ec = boto3.client('elasticache', region_name=region)
    
    res_rep_groups, res_clusters_nodes, res_subnet_groups, res_param_groups, res_snapshots = [], [], [], [], []
    
    try:
        # --- 1. Audit Subnet Groups ---
        paginator = ec.get_paginator('describe_cache_subnet_groups')
        for page in paginator.paginate():
            for sg in page['CacheSubnetGroups']:
                sg_name = sg['CacheSubnetGroupName']
                file_ref = save_raw_json(DIR_SUBNET, f"{region}_{sg_name}", sg)
                res_subnet_groups.append({
                    'Region': region,
                    'Name': sg_name,
                    'VPC ID': sg.get('VpcId', 'N/A'),
                    'Subnets': "\n".join([s['SubnetIdentifier'] for s in sg.get('Subnets', [])]),
                    'Full Detail File': file_ref
                })

        # --- 2. Audit Parameter Groups ---
        paginator = ec.get_paginator('describe_cache_parameter_groups')
        for page in paginator.paginate():
            for pg in page['CacheParameterGroups']:
                pg_name = pg['CacheParameterGroupName']
                file_ref = save_raw_json(DIR_PARAM, f"{region}_{pg_name}", pg)
                res_param_groups.append({
                    'Region': region,
                    'Name': pg_name,
                    'Family': pg['CacheParameterGroupFamily'],
                    'Type': 'Custom' if pg['IsModifiable'] else 'Default',
                    'Full Detail File': file_ref
                })

        # --- 3. Audit Replication Groups (Redis) ---
        paginator = ec.get_paginator('describe_replication_groups')
        for page in paginator.paginate():
            for rg in page['ReplicationGroups']:
                rg_id = rg['ReplicationGroupId']
                file_ref = save_raw_json(DIR_REP_GROUP, f"{region}_{rg_id}", rg)
                res_rep_groups.append({
                    'Region': region,
                    'Replication Group ID': rg_id,
                    'Status': rg['Status'],
                    'Node Type': rg['CacheNodeType'],
                    'Member Count': len(rg.get('MemberClusters', [])),
                    'Multi-AZ': rg.get('MultiAZ', 'N/A'),
                    'Auth Token (Password) Enabled?': rg.get('AuthTokenEnabled', False),
                    'Encryption at Rest': rg.get('AtRestEncryptionEnabled', False),
                    'Encryption in Transit': rg.get('TransitEncryptionEnabled', False),
                    'Tags': get_tag_value(rg.get('Tags')),
                    'Full Detail File': file_ref
                })
        
        # --- 4. Audit Cache Clusters & Nodes (Exploded) (Redis & Memcached) ---
        paginator = ec.get_paginator('describe_cache_clusters')
        for page in paginator.paginate(ShowCacheNodeInfo=True):
            for cluster in page['CacheClusters']:
                cluster_id = cluster['CacheClusterId']
                
                # Save the parent cluster JSON
                file_ref = save_raw_json(DIR_CLUSTER, f"{region}_{cluster_id}", cluster)
                
                sgs = ", ".join([sg['SecurityGroupId'] for sg in cluster.get('SecurityGroups', [])])
                
                # Explode the nodes
                for node in cluster.get('CacheNodes', []):
                    res_clusters_nodes.append({
                        'Region': region,
                        'Parent Cluster ID': cluster_id,
                        'Node ID': node['CacheNodeId'],
                        'Engine': cluster['Engine'],
                        'Engine Version': cluster['EngineVersion'],
                        'Parent Group ID': cluster.get('ReplicationGroupId', 'N/A (Memcached or Standalone)'),
                        'Node Type': cluster['CacheNodeType'],
                        'AZ': node['CustomerAvailabilityZone'],
                        'Status': node['CacheNodeStatus'],
                        'Endpoint Address': node.get('Endpoint', {}).get('Address', 'N/A'),
                        'Security Groups': sgs,
                        'Full Detail File': file_ref
                    })

        # --- 5. Audit Snapshots (Redis) ---
        paginator = ec.get_paginator('describe_snapshots')
        for page in paginator.paginate():
            for snap in page['Snapshots']:
                snap_name = snap['SnapshotName']
                file_ref = save_raw_json(DIR_SNAP, f"{region}_{snap_name}", snap)
                res_snapshots.append({
                    'Region': region,
                    'Snapshot Name': snap_name,
                    'Source Group ID': snap.get('ReplicationGroupId', 'N/A'),
                    'Source Cluster ID': snap.get('CacheClusterId', 'N/A'),
                    'Status': snap['SnapshotStatus'],
                    'Source Type': snap['SnapshotSource'],
                    'Node Type': snap['CacheNodeType'],
                    'Creation Time': snap.get('NodeSnapshots', [{}])[0].get('NodeSnapshotCreateTime'),
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_rep_groups, res_clusters_nodes, res_subnet_groups, res_param_groups, res_snapshots

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS ElastiCache Ultimate Audit (Redis, Memcached, Nodes, Security) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_rg, all_cn, all_sg, all_pg, all_sn = [], [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_elasticache, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                rg, cn, sg, pg, sn = future.result()
                all_rg.extend(rg); all_cn.extend(cn); all_sg.extend(sg); all_pg.extend(pg); all_sn.extend(sn)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_rg = pd.DataFrame(all_rg)
    df_cn = pd.DataFrame(all_cn)
    df_sg = pd.DataFrame(all_sg)
    df_pg = pd.DataFrame(all_pg)
    df_sn = pd.DataFrame(all_sn)
    
    # Sort
    if not df_rg.empty: df_rg = df_rg.sort_values(by=['Region', 'Replication Group ID'])
    if not df_cn.empty: df_cn = df_cn.sort_values(by=['Region', 'Parent Group ID', 'Parent Cluster ID'])
    if not df_sg.empty: df_sg = df_sg.sort_values(by=['Region', 'Name'])
    if not df_pg.empty: df_pg = df_pg.sort_values(by=['Region', 'Name'])
    if not df_sn.empty: df_sn = df_sn.sort_values(by=['Creation Time'], ascending=False)
        
    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_rg.to_excel(writer, sheet_name='Redis Replication Groups', index=False)
            df_cn.to_excel(writer, sheet_name='Cache Clusters & Nodes (Exploded)', index=False)
            df_sg.to_excel(writer, sheet_name='Subnet Groups', index=False)
            df_pg.to_excel(writer, sheet_name='Parameter Groups', index=False)
            df_sn.to_excel(writer, sheet_name='Snapshots (Redis)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "rds_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_INST = "details_rds_instances"
DIR_CLUST = "details_rds_clusters"
DIR_SNAP = "details_rds_snapshots"

for d in [DIR_INST, DIR_CLUST, DIR_SNAP]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

def get_account_id():
    return boto3.client('sts').get_caller_identity()['Account']

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

# --- WORKER ---
def audit_region_rds(region):
    """
    Audits all RDS components in a single region.
    """
    rds = boto3.client('rds', region_name=region)
    
    res_instances = []
    res_clusters = []
    res_snapshots = []
    
    cluster_info_map = {} # To store parent info for instances

    try:
        # --- 1. Audit DB Clusters (Aurora) FIRST ---
        paginator = rds.get_paginator('describe_db_clusters')
        for page in paginator.paginate():
            for cluster in page['DBClusters']:
                cluster_id = cluster['DBClusterIdentifier']
                
                # Save raw JSON
                file_ref = save_raw_json(DIR_CLUST, f"{region}_{cluster_id}.json", cluster)
                
                # Add to Excel list
                res_clusters.append({
                    'Cluster Identifier': cluster_id,
                    'ARN': cluster['DBClusterArn'],
                    'Region': region,
                    'Engine': cluster['Engine'],
                    'Engine Version': cluster['EngineVersion'],
                    'Status': cluster['Status'],
                    'Members Count': len(cluster.get('DBClusterMembers', [])),
                    'Reader Endpoint': cluster.get('ReaderEndpoint', 'N/A'),
                    'Writer Endpoint': cluster.get('Endpoint', 'N/A'),
                    'Multi-AZ': cluster.get('MultiAZ', False),
                    'Storage Encrypted': cluster['StorageEncrypted'],
                    'Deletion Protection': cluster.get('DeletionProtection', False),
                    'Backup Retention (Days)': cluster.get('BackupRetentionPeriod', 1),
                    'Full Detail File': file_ref
                })
                
                # Store info for enriching instances later
                cluster_info_map[cluster_id] = {
                    'ClusterEngine': cluster['Engine'],
                    'ClusterBackupRetention': cluster.get('BackupRetentionPeriod', 1),
                    'ClusterDeletionProtection': cluster.get('DeletionProtection', False)
                }

        # --- 2. Audit DB Instances (Standalone & Aurora) ---
        paginator = rds.get_paginator('describe_db_instances')
        for page in paginator.paginate():
            for inst in page['DBInstances']:
                inst_id = inst['DBInstanceIdentifier']
                
                # Save raw JSON
                file_ref = save_raw_json(DIR_INST, f"{region}_{inst_id}.json", inst)
                
                # Get Security Groups
                sgs = [sg['VpcSecurityGroupId'] for sg in inst.get('VpcSecurityGroups', [])]
                
                # --- Stitch Cluster Data (if part of a cluster) ---
                cluster_id = inst.get('DBClusterIdentifier')
                if cluster_id:
                    parent = cluster_info_map.get(cluster_id, {})
                    # For Aurora, the *cluster* holds these settings
                    engine = parent.get('ClusterEngine', inst['Engine'])
                    backup_retention = parent.get('ClusterBackupRetention', inst.get('BackupRetentionPeriod'))
                    del_protection = parent.get('ClusterDeletionProtection', inst.get('DeletionProtection'))
                else:
                    # For standalone, the *instance* holds these settings
                    engine = inst['Engine']
                    backup_retention = inst.get('BackupRetentionPeriod')
                    del_protection = inst.get('DeletionProtection', False)

                # Build Excel Row
                res_instances.append({
                    'Instance Identifier': inst_id,
                    'ARN': inst['DBInstanceArn'],
                    'Region': region,
                    'Engine': engine,
                    'Engine Version': inst['EngineVersion'],
                    'Instance Class': inst['DBInstanceClass'],
                    'Status': inst['DBInstanceStatus'],
                    'Cluster ID': cluster_id or 'N/A',
                    'Publicly Accessible': inst['PubliclyAccessible'],
                    'Storage Encrypted': inst['StorageEncrypted'],
                    'IAM DB Auth Enabled': inst.get('IAMDatabaseAuthenticationEnabled', False),
                    'Multi-AZ': inst['MultiAZ'],
                    'Storage Type': inst['StorageType'],
                    'Allocated Storage (GB)': inst['AllocatedStorage'],
                    'Deletion Protection': del_protection,
                    'Auto Minor Version Upgrade': inst['AutoMinorVersionUpgrade'],
                    'Backup Retention (Days)': backup_retention,
                    'Security Groups': ", ".join(sgs),
                    'Tags': get_tag_value(inst.get('TagList')),
                    'Full Detail File': file_ref
                })

        # --- 3. Audit DB Snapshots ---
        paginator = rds.get_paginator('describe_db_snapshots')
        for page in paginator.paginate(): # Defaults to 'self' owner
            for snap in page['DBSnapshots']:
                snap_id = snap['DBSnapshotIdentifier']
                
                file_ref = save_raw_json(DIR_SNAP, f"{region}_{snap_id}.json", snap)
                
                res_snapshots.append({
                    'Snapshot Identifier': snap_id,
                    'Region': region,
                    'Source DB/Cluster': snap.get('DBInstanceIdentifier', snap.get('DBClusterIdentifier', 'N/A')),
                    'Snapshot Type': snap['SnapshotType'],
                    'Status': snap['Status'],
                    'Engine': snap['Engine'],
                    'Encrypted': snap['Encrypted'],
                    'KMS Key ID': snap.get('KmsKeyId', 'N/A'),
                    'Created Time': snap.get('SnapshotCreateTime', snap.get('OriginalSnapshotCreateTime')).replace(tzinfo=None),
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_instances, res_clusters, res_snapshots

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS RDS Ultimate Audit (Instances, Clusters, Snapshots) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_inst, all_clust, all_snap = [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_rds, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                i, c, s = future.result()
                all_inst.extend(i)
                all_clust.extend(c)
                all_snap.extend(s)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_inst = pd.DataFrame(all_inst)
    df_clust = pd.DataFrame(all_clust)
    df_snap = pd.DataFrame(all_snap)
    
    # Sort
    if not df_inst.empty: df_inst = df_inst.sort_values(by=['Region', 'Instance Identifier'])
    if not df_clust.empty: df_clust = df_clust.sort_values(by=['Region', 'Cluster Identifier'])
    if not df_snap.empty: df_snap = df_snap.sort_values(by=['Region', 'Created Time'], ascending=False)

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_inst.to_excel(writer, sheet_name='DB Instances', index=False)
            df_clust.to_excel(writer, sheet_name='DB Clusters (Aurora)', index=False)
            df_snap.to_excel(writer, sheet_name='DB Snapshots', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
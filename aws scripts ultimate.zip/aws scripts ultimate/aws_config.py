import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "config_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_RECORDER = "details_config_recorders"
DIR_RULE = "details_config_rules"
DIR_AGG = "details_config_aggregators"

for d in [DIR_RECORDER, DIR_RULE, DIR_AGG]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def check_s3_bucket_public(bucket_name, s3_client):
    """Tries to check if the destination S3 bucket is public."""
    try:
        acl = s3_client.get_bucket_acl(Bucket=bucket_name)
        for grant in acl.get('Grants', []):
            uri = grant.get('Grantee', {}).get('URI', '')
            if 'AllUsers' in uri or 'AuthenticatedUsers' in uri:
                return f"PUBLIC ({grant['Permission']})"
        return "Not Public (ACL)"
    except ClientError as e:
        if "AccessDenied" in str(e): return "AccessDenied (Cannot check)"
        if "NoSuchBucket" in str(e): return "Bucket Not Found"
        return "Check Error"

# --- WORKER ---
def audit_region_config(region):
    """
    Audits all AWS Config components in a single region.
    """
    config = boto3.client('config', region_name=region)
    s3 = boto3.client('s3') # S3 is global, one client is fine
    
    res_recorders = []
    res_rules = []
    res_aggregators = []
    
    try:
        # --- 1. Audit Recorders & Delivery Channels ---
        recorders = config.describe_configuration_recorders()['ConfigurationRecorders']
        
        if not recorders:
            res_recorders.append({'Region': region, 'Recorder Status': 'OFF', 'Records Global': 'N/A', 'S3 Bucket': 'N/A'})
        else:
            for rec in recorders:
                rec_name = rec['name']
                
                # Get Status
                status = config.describe_configuration_recorder_status(ConfigurationRecorderNames=[rec_name])['ConfigurationRecordersStatus'][0]
                is_recording = status['recording']
                
                # Get Delivery Channel
                try:
                    dc = config.describe_delivery_channels()['DeliveryChannels'][0]
                    s3_bucket = dc.get('s3BucketName', 'N/A')
                    s3_public = check_s3_bucket_public(s3_bucket, s3)
                except ClientError:
                    s3_bucket = "Not Configured"
                    s3_public = "N/A"

                # Save raw JSON
                full_data = {'Recorder': rec, 'Status': status, 'DeliveryChannel': dc if 'dc' in locals() else {}}
                file_ref = save_raw_json(DIR_RECORDER, f"{region}_{rec_name}.json", full_data)

                res_recorders.append({
                    'Region': region,
                    'Recorder Name': rec_name,
                    'Recorder Status': "ON" if is_recording else "OFF",
                    'Records Global': "Yes" if rec['recordingGroup'].get('includeGlobalResourceTypes', False) else "No",
                    'Resource Types': "All" if rec['recordingGroup']['allSupported'] else "Custom",
                    'S3 Bucket': s3_bucket,
                    'S3 Bucket Public?': s3_public,
                    'SNS Topic': dc.get('snsTopicARN', 'N/A'),
                    'Full Detail File': file_ref
                })

        # --- 2. Audit Config Rules (Exploded) ---
        paginator = config.get_paginator('describe_config_rules')
        for page in paginator.paginate():
            for rule in page['ConfigRules']:
                rule_name = rule['ConfigRuleName']
                
                # Save raw JSON
                file_ref = save_raw_json(DIR_RULE, f"{region}_{rule_name}.json", rule)
                
                # Get Compliance Status
                try:
                    comp = config.describe_compliance_by_config_rule(ConfigRuleNames=[rule_name])['ComplianceByConfigRules']
                    status = comp[0]['Compliance']['ComplianceType'] if comp else 'N/A'
                except ClientError:
                    status = "Error"
                
                res_rules.append({
                    'Rule Name': rule_name,
                    'Region': region,
                    'Compliance Status': status,
                    'Rule State': rule['ConfigRuleState'],
                    'Source': rule['Source']['Owner'],
                    'ARN': rule['ConfigRuleArn'],
                    'Full Detail File': file_ref
                })

        # --- 3. Audit Aggregators ---
        paginator = config.get_paginator('describe_configuration_aggregators')
        for page in paginator.paginate():
            for agg in page['ConfigurationAggregators']:
                agg_name = agg['ConfigurationAggregatorName']
                file_ref = save_raw_json(DIR_AGG, f"{region}_{agg_name}.json", agg)
                
                res_aggregators.append({
                    'Aggregator Name': agg_name,
                    'Region': region,
                    'ARN': agg['ConfigurationAggregatorArn'],
                    'Accounts': ", ".join(agg.get('AccountAggregationSources', [{}])[0].get('AccountIds', [])),
                    'All Regions': agg.get('OrganizationAggregationSource') is not None,
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_recorders, res_rules, res_aggregators

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Config Ultimate Audit (Recorders, Rules, Aggregators) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_rec, all_rules, all_agg = [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_config, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                rec, rul, agg = future.result()
                all_rec.extend(rec)
                all_rules.extend(rul)
                all_agg.extend(agg)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    df_rec = pd.DataFrame(all_rec)
    df_rules = pd.DataFrame(all_rules)
    df_agg = pd.DataFrame(all_agg)
    
    if not df_rec.empty: df_rec = df_rec.sort_values(by=['Region'])
    if not df_rules.empty: df_rules = df_rules.sort_values(by=['Compliance Status', 'Region', 'Rule Name'])
    if not df_agg.empty: df_agg = df_agg.sort_values(by=['Region'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='open_pyxl') as writer:
            df_rec.to_excel(writer, sheet_name='Config Recorders', index=False)
            df_rules.to_excel(writer, sheet_name='Config Rules (Status)', index=False)
            df_agg.to_excel(writer, sheet_name='Aggregators', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
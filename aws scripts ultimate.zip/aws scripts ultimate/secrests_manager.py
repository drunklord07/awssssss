import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "secretsmanager_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folder for 100% raw JSON details
DIR_SECRETS = "details_secretsmanager"

if not os.path.exists(DIR_SECRETS):
    os.makedirs(DIR_SECRETS)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def days_since(date_val):
    """Calculates days since a datetime. Returns None if date is None."""
    if date_val is None:
        return None
    if date_val.tzinfo is None:
        date_val = date_val.replace(tzinfo=datetime.timezone.utc)
        
    now = datetime.datetime.now(datetime.timezone.utc)
    return (now - date_val).days

def format_principal(principal):
    """Simplifies the complex Principal object into a string."""
    if 'AWS' in principal:
        return str(principal['AWS'])
    if 'Service' in principal:
        return str(principal['Service'])
    return str(principal)

# --- WORKER ---
def audit_region_secrets(region):
    """
    Audits all Secrets Manager secrets in a single region.
    """
    secretsmanager = boto3.client('secretsmanager', region_name=region)
    
    res_secrets = []
    res_policies = []
    
    try:
        paginator = secretsmanager.get_paginator('list_secrets')
        for page in paginator.paginate():
            for secret in page['SecretList']:
                secret_name = secret['Name']
                secret_arn = secret['ARN']
                
                try:
                    # 1. Get Full Secret Details
                    # describe_secret is needed for most useful data
                    details = secretsmanager.describe_secret(SecretId=secret_arn)['ResponseMetadata']['HTTPHeaders']
                    
                    full_data = {'Description': details}
                    
                    # 2. Get Resource Policy & Explode
                    policy_attached = False
                    try:
                        policy_resp = secretsmanager.get_resource_policy(SecretId=secret_arn)
                        policy_str = policy_resp.get('ResourcePolicy', '{}')
                        full_data['ResourcePolicy'] = json.loads(policy_str)
                        policy_attached = True
                        
                        for stmt in json.loads(policy_str).get('Statement', []):
                            res_policies.append({
                                'Secret Name': secret_name,
                                'Region': region,
                                'SID': stmt.get('Sid', 'No_SID'),
                                'Effect': stmt.get('Effect'),
                                'Principal': format_principal(stmt.get('Principal', {})),
                                'Action': str(stmt.get('Action')),
                                'Condition': str(stmt.get('Condition', {}))
                            })
                    except ClientError as e:
                        if 'ResourceNotFoundException' in str(e):
                            policy_attached = False # No policy is fine
                        else:
                            res_policies.append({'Secret Name': secret_name, 'SID': 'ERROR', 'Effect': str(e)})

                    # 3. Save JSON
                    file_ref = save_raw_json(DIR_SECRETS, f"{region}_{secret_name.replace('/', '_')}.json", full_data)

                    # 4. Build Excel Row
                    res_secrets.append({
                        'Secret Name': secret_name,
                        'ARN': secret_arn,
                        'Region': region,
                        'Rotation Enabled': details.get('RotationEnabled', False),
                        'Rotation Lambda ARN': details.get('RotationLambdaARN', 'N/A'),
                        'Last Rotated Date': details.get('LastRotatedDate'),
                        'Days Since Last Rotation': days_since(details.get('LastRotatedDate')),
                        'Last Accessed Date': details.get('LastAccessedDate'),
                        'Days Since Last Access': days_since(details.get('LastAccessedDate')),
                        'KMS Key ID': details.get('KmsKeyId', 'aws/secretsmanager'),
                        'Policy Attached?': "Yes" if policy_attached else "No",
                        'Description': details.get('Description', ''),
                        'Tags': get_tag_value(details.get('Tags', [])),
                        'Full Detail File': file_ref
                    })
                    
                except ClientError as e:
                    print(f"[{region}] Error describing secret {secret_name}: {e}")

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_secrets, res_policies

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Secrets Manager Ultimate Audit (Rotation, Access, Policy) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_secrets, all_policies = [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_secrets, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                secrets, policies = future.result()
                all_secrets.extend(secrets)
                all_policies.extend(policies)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_secrets = pd.DataFrame(all_secrets)
    df_policies = pd.DataFrame(all_policies)
    
    # Sort
    if not df_secrets.empty:
        # Sort by last accessed, then last rotated. Oldest/unused at the top.
        df_secrets = df_secrets.sort_values(by=['Days Since Last Access', 'Days Since Last Rotation'], ascending=[False, False])
    if not df_policies.empty:
        df_policies = df_policies.sort_values(by=['Region', 'Secret Name', 'SID'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_secrets.to_excel(writer, sheet_name='Secrets (Master List)', index=False)
            df_policies.to_excel(writer, sheet_name='Secret Policies (Exploded)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
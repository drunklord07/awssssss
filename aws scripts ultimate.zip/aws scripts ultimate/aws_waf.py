import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "wafv2_ultimate_audit.xlsx"
MAX_WORKERS = 10  # WAF has low API limits, keep this reasonable

# Folders for 100% raw JSON details
DIR_ACL = "details_wafv2_webacls"
DIR_RG = "details_wafv2_rulegroups"
DIR_IP = "details_wafv2_ipsets"
DIR_REGEX = "details_wafv2_regexsets"

for d in [DIR_ACL, DIR_RG, DIR_IP, DIR_REGEX]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

def parse_rule(rule, base_info):
    """Helper to explode a single WAF rule for Excel."""
    rule_name = rule.get('Name')
    priority = rule.get('Priority')
    action = rule.get('Action', None)
    override = rule.get('OverrideAction', None)
    
    # Determine Action
    rule_action = "N/A"
    if action:
        if 'Block' in action: rule_action = 'Block'
        elif 'Allow' in action: rule_action = 'Allow'
        elif 'Count' in action: rule_action = 'Count'
        elif 'Captcha' in action: rule_action = 'Captcha'
    
    # Determine Override Action (for rule groups)
    if override and 'Count' in override:
        rule_action = "Override to Count"
    elif override and 'None' in override:
         rule_action = "Override to None" # No action
         
    # Determine Rule Type
    stmt = rule.get('Statement', {})
    if 'ManagedRuleGroupStatement' in stmt:
        rule_type = 'Managed Rule Group'
        details = stmt['ManagedRuleGroupStatement']['Name']
    elif 'RuleGroupReferenceStatement' in stmt:
        rule_type = 'Custom Rule Group'
        details = stmt['RuleGroupReferenceStatement']['ARN']
    elif 'IPSetReferenceStatement' in stmt:
        rule_type = 'IP Set'
        details = stmt['IPSetReferenceStatement']['ARN']
    elif 'RegexPatternSetReferenceStatement' in stmt:
        rule_type = 'Regex Set'
        details = stmt['RegexPatternSetReferenceStatement']['ARN']
    else:
        rule_type = "Custom (e.g., Size, SQLi)"
        details = list(stmt.keys())[0] if stmt else "N/A"

    return {
        **base_info,
        'Rule Name': rule_name,
        'Priority': priority,
        'Action': rule_action,
        'Rule Type': rule_type,
        'Rule Details': details
    }

# --- WORKER ---
def audit_waf_scope(region, scope):
    """
    Audits all WAFv2 components in a single region/scope combination.
    """
    waf = boto3.client('wafv2', region_name=region)
    
    res_acls = []
    res_acl_rules = []
    res_rule_groups = []
    res_ip_sets = []
    res_regex_sets = []

    try:
        # --- 1. Web ACLs ---
        paginator = waf.get_paginator('list_web_acls')
        for page in paginator.paginate(Scope=scope):
            for acl_summary in page['WebACLs']:
                acl_name = acl_summary['Name']
                acl_id = acl_summary['Id']
                
                try:
                    # Get full ACL details
                    acl = waf.get_web_acl(Name=acl_name, Scope=scope, Id=acl_id)
                    acl_data = acl['WebACL']
                    acl_data['LockToken'] = acl['LockToken'] # Add for completeness
                    
                    file_ref = save_raw_json(DIR_ACL, f"{region}_{scope}_{acl_name}.json", acl_data)
                    
                    # Get associations
                    resources = waf.list_resources_for_web_acl(WebACLArn=acl_data['ARN']).get('ResourceArns', [])
                    
                    # Base info for exploded rules
                    base_rule_info = {
                        'Web ACL Name': acl_name,
                        'Web ACL ID': acl_id,
                        'Scope': scope,
                        'Region': region if scope == 'REGIONAL' else 'global'
                    }

                    # Add to ACL Summary list
                    res_acls.append({
                        **base_rule_info,
                        'Description': acl_data.get('Description', ''),
                        'Default Action': 'Block' if 'Block' in acl_data['DefaultAction'] else 'Allow',
                        'Associated Resources': "\n".join(resources),
                        'Full Detail File': file_ref
                    })
                    
                    # Explode rules
                    for rule in acl_data.get('Rules', []):
                        res_acl_rules.append(parse_rule(rule, base_rule_info))
                        
                except ClientError as e:
                    print(f"[{region}/{scope}] Error describing ACL {acl_name}: {e}")

        # --- 2. Custom Rule Groups ---
        paginator = waf.get_paginator('list_rule_groups')
        for page in paginator.paginate(Scope=scope):
            for rg in page['RuleGroups']:
                if rg['ARN'].startswith(f"arn:aws:wafv2:{region}"): # Filter for custom only
                    rg_details = waf.get_rule_group(Name=rg['Name'], Scope=scope, Id=rg['Id'])['RuleGroup']
                    file_ref = save_raw_json(DIR_RG, f"{region}_{scope}_{rg['Name']}.json", rg_details)
                    res_rule_groups.append({
                        'Name': rg['Name'],
                        'Scope': scope,
                        'Region': region if scope == 'REGIONAL' else 'global',
                        'Rule Count': len(rg_details.get('Rules', [])),
                        'Capacity': rg_details['Capacity'],
                        'ARN': rg['ARN'],
                        'Full Detail File': file_ref
                    })

        # --- 3. IP Sets ---
        paginator = waf.get_paginator('list_ip_sets')
        for page in paginator.paginate(Scope=scope):
            for ip_set in page['IPSets']:
                ip_details = waf.get_ip_set(Name=ip_set['Name'], Scope=scope, Id=ip_set['Id'])
                file_ref = save_raw_json(DIR_IP, f"{region}_{scope}_{ip_set['Name']}.json", ip_details)
                addresses = ip_details['IPSet'].get('Addresses', [])
                res_ip_sets.append({
                    'Name': ip_set['Name'],
                    'Scope': scope,
                    'Region': region if scope == 'REGIONAL' else 'global',
                    'IP Count': len(addresses),
                    'IP Sample': ", ".join(addresses[:5]) + ('...' if len(addresses) > 5 else ''),
                    'ARN': ip_set['ARN'],
                    'Full Detail File': file_ref
                })
        
        # --- 4. Regex Pattern Sets ---
        paginator = waf.get_paginator('list_regex_pattern_sets')
        for page in paginator.paginate(Scope=scope):
            for regex_set in page['RegexPatternSets']:
                regex_details = waf.get_regex_pattern_set(Name=regex_set['Name'], Scope=scope, Id=regex_set['Id'])
                file_ref = save_raw_json(DIR_REGEX, f"{region}_{scope}_{regex_set['Name']}.json", regex_details)
                patterns = [p['RegexString'] for p in regex_details['RegexPatternSet'].get('RegularExpressionList', [])]
                res_regex_sets.append({
                    'Name': regex_set['Name'],
                    'Scope': scope,
                    'Region': region if scope == 'REGIONAL' else 'global',
                    'Pattern Count': len(patterns),
                    'Pattern Sample': patterns[0] if patterns else '',
                    'ARN': regex_set['ARN'],
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}/{scope}] Error: {e}")

    return res_acls, res_acl_rules, res_rule_groups, res_ip_sets, res_regex_sets

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS WAFv2 Ultimate Audit (All Regions & Scopes) ---")
    
    regions = get_regions()
    all_acls, all_acl_rules, all_rgs, all_ips, all_regex = [], [], [], [], []

    # --- Run REGIONAL scope in all regions ---
    print(f"Scanning {len(regions)} regions for REGIONAL assets...")
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_waf_scope, r, 'REGIONAL'): r for r in regions}
        done = 0
        for future in as_completed(future_map):
            done += 1
            print(f"\rProgress (Regional): {done}/{len(regions)}", end="")
            try:
                a, ar, rg, i, r = future.result()
                all_acls.extend(a); all_acl_rules.extend(ar); all_rgs.extend(rg); all_ips.extend(i); all_regex.extend(r)
            except Exception as e: print(f"\nError processing regional: {e}")

    # --- Run CLOUDFRONT scope in us-east-1 ---
    print("\nScanning us-east-1 for CLOUDFRONT assets...")
    try:
        a, ar, rg, i, r = audit_waf_scope('us-east-1', 'CLOUDFRONT')
        all_acls.extend(a); all_acl_rules.extend(ar); all_rgs.extend(rg); all_ips.extend(i); all_regex.extend(r)
    except Exception as e: print(f"\nError processing CloudFront: {e}")

    print("\nCompiling Excel Report...")
    df_acls = pd.DataFrame(all_acls)
    df_acl_rules = pd.DataFrame(all_acl_rules)
    df_rgs = pd.DataFrame(all_rgs)
    df_ips = pd.DataFrame(all_ips)
    df_regex = pd.DataFrame(all_regex)
    
    # Sort
    if not df_acls.empty: df_acls = df_acls.sort_values(by=['Region', 'Scope', 'Web ACL Name'])
    if not df_acl_rules.empty: df_acl_rules = df_acl_rules.sort_values(by=['Region', 'Scope', 'Web ACL Name', 'Priority'])
    if not df_rgs.empty: df_rgs = df_rgs.sort_values(by=['Region', 'Scope', 'Name'])
    if not df_ips.empty: df_ips = df_ips.sort_values(by=['Region', 'Scope', 'Name'])
    if not df_regex.empty: df_regex = df_regex.sort_values(by=['Region', 'Scope', 'Name'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_acls.to_excel(writer, sheet_name='Web ACLs (Summary)', index=False)
            df_acl_rules.to_excel(writer, sheet_name='Web ACL Rules (Exploded)', index=False)
            df_rgs.to_excel(writer, sheet_name='Custom Rule Groups', index=False)
            df_ips.to_excel(writer, sheet_name='IP Sets', index=False)
            df_regex.to_excel(writer, sheet_name='Regex Pattern Sets', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "backup_ultimate_audit.xlsx"
MAX_WORKERS = 15 # Backup has lower API limits, keep this reasonable
JOB_HISTORY_DAYS = 7 # How many days of job history to pull

# Folders for 100% raw JSON details
DIR_VAULT = "details_backup_vaults"
DIR_PLAN = "details_backup_plans"
DIR_JOB = "details_backup_jobs"
DIR_RP = "details_backup_recoverypoints"
DIR_REPORT = "details_backup_reports"

for d in [DIR_VAULT, DIR_PLAN, DIR_JOB, DIR_RP, DIR_REPORT]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def format_principal(principal):
    if principal == '*': return "Public (*)"
    if 'AWS' in principal: return str(principal['AWS'])
    return str(principal)

# --- WORKER ---
def audit_region_backup(region):
    """
    Audits all AWS Backup components in a single region.
    """
    backup = boto3.client('backup', region_name=region)
    
    res_vaults, res_plans, res_jobs, res_rps, res_reports = [], [], [], [], []
    
    try:
        # --- 1. Audit Backup Vaults ---
        paginator = backup.get_paginator('list_backup_vaults')
        for page in paginator.paginate():
            for vault in page['BackupVaultList']:
                vault_name = vault['BackupVaultName']
                
                # Get full details
                try:
                    details = backup.describe_backup_vault(BackupVaultName=vault_name)
                    full_data = {'Description': details}
                    
                    # Get Vault Policy
                    policy_attached = "No"
                    try:
                        policy = backup.get_backup_vault_access_policy(BackupVaultName=vault_name)
                        full_data['AccessPolicy'] = json.loads(policy['Policy'])
                        policy_attached = "Yes"
                    except ClientError as e:
                        if 'ResourceNotFoundException' in str(e): policy_attached = "No"
                        else: policy_attached = f"Error: {e}"
                    
                    file_ref = save_raw_json(DIR_VAULT, f"{region}_{vault_name}.json", full_data)

                    res_vaults.append({
                        'Region': region,
                        'Vault Name': vault_name,
                        'Encryption Key': details.get('EncryptionKeyArn', 'Default'),
                        'Vault Lock Status': details.get('LockDate', 'UNLOCKED'),
                        'Min Retention (Days)': details.get('MinRetentionDays', 'N/A'),
                        'Max Retention (Days)': details.get('MaxRetentionDays', 'N/A'),
                        'Policy Attached?': policy_attached,
                        'Recovery Points': details.get('NumberOfRecoveryPoints', 0),
                        'Full Detail File': file_ref
                    })
                    
                    # --- 2. List Recovery Points (Backups) BY VAULT ---
                    rp_paginator = backup.get_paginator('list_recovery_points_by_backup_vault')
                    for rp_page in rp_paginator.paginate(BackupVaultName=vault_name):
                        for rp in rp_page['RecoveryPoints']:
                            res_rps.append({
                                'Region': region,
                                'Vault Name': vault_name,
                                'Status': rp['Status'],
                                'Resource Type': rp['ResourceType'],
                                'Resource ARN': rp['ResourceArn'],
                                'Creation Date': rp['CreationDate'].replace(tzinfo=None),
                                'Completion Date': rp.get('CompletionDate', 'N/A'),
                                'Backup Size (Bytes)': rp['BackupSizeInBytes'],
                                'Encryption Key': rp.get('EncryptionKeyArn', 'Default'),
                                'Recovery Point ARN': rp['RecoveryPointArn']
                            })

                except ClientError as e:
                    print(f"\n[{region}] Error describing vault {vault_name}: {e}")

        # --- 3. Audit Backup Plans (Exploded) ---
        paginator = backup.get_paginator('list_backup_plans')
        for page in paginator.paginate():
            for plan_summary in page['BackupPlansList']:
                plan_id = plan_summary['BackupPlanId']
                plan_name = plan_summary['BackupPlanName']
                
                plan = backup.get_backup_plan(BackupPlanId=plan_id)
                full_data = {'Plan': plan}
                
                # Get Selections (what is being backed up)
                selections = backup.list_backup_selections(BackupPlanId=plan_id).get('BackupSelectionsList', [])
                full_data['Selections'] = selections
                selection_names = ", ".join([s['SelectionName'] for s in selections])

                file_ref = save_raw_json(DIR_PLAN, f"{region}_{plan_name}.json", full_data)

                # Explode the rules
                for rule in plan['BackupPlan']['Rules']:
                    copy_actions = [c['DestinationBackupVaultArn'].split(':')[-1] for c in rule.get('CopyActions', [])]
                    
                    res_plans.append({
                        'Region': region,
                        'Plan Name': plan_name,
                        'Rule Name': rule['RuleName'],
                        'Schedule': rule['ScheduleExpression'],
                        'Target Vault': rule['TargetBackupVaultName'],
                        'Start Window (Min)': rule['StartWindowMinutes'],
                        'Completion Window (Min)': rule.get('CompletionWindowMinutes'),
                        'Lifecycle (Cold After Days)': rule.get('Lifecycle', {}).get('MoveToColdStorageAfterDays'),
                        'Lifecycle (Delete After Days)': rule.get('Lifecycle', {}).get('DeleteAfterDays'),
                        'Copy to Region(s)?': ", ".join(copy_actions) or "No",
                        'Selections': selection_names,
                        'Full Detail File': file_ref
                    })

        # --- 4. Audit Backup Jobs (History) ---
        start_date = datetime.datetime.now() - datetime.timedelta(days=JOB_HISTORY_DAYS)
        paginator = backup.get_paginator('list_backup_jobs')
        for page in paginator.paginate(ByCreatedAfter=start_date):
            for job in page['BackupJobs']:
                job_id = job['BackupJobId']
                file_ref = save_raw_json(DIR_JOB, f"{region}_{job_id}.json", job)
                
                res_jobs.append({
                    'Region': region,
                    'State': job['State'],
                    'Job ID': job_id,
                    'Resource Type': job['ResourceType'],
                    'Resource ARN': job['ResourceArn'],
                    'Vault Name': job['BackupVaultName'],
                    'Creation Date': job['CreationDate'].replace(tzinfo=None),
                    'Completion Date': job.get('CompletionDate'),
                    'Status Message': job.get('StatusMessage', ''),
                    'Full Detail File': file_ref
                })

        # --- 5. Audit Report Plans (Compliance) ---
        for plan in backup.list_report_plans().get('ReportPlans', []):
            plan_name = plan['ReportPlanName']
            full_data = backup.describe_report_plan(ReportPlanName=plan_name)
            file_ref = save_raw_json(DIR_REPORT, f"{region}_{plan_name}.json", full_data)
            
            res_reports.append({
                'Region': region,
                'Report Plan Name': plan_name,
                'Description': plan.get('ReportPlanDescription', ''),
                'Last Attempt': full_data['ReportPlan'].get('LastAttemptedExecutionTime'),
                'Last Successful': full_data['ReportPlan'].get('LastSuccessfulExecutionTime'),
                'Full Detail File': file_ref
            })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_vaults, res_plans, res_jobs, res_rps, res_reports

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Backup Ultimate Audit (Vaults, Plans, Jobs, RPs, Reports) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_vaults, all_plans, all_jobs, all_rps, all_reports = [], [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_backup, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                v, p, j, rp, r = future.result()
                all_vaults.extend(v); all_plans.extend(p); all_jobs.extend(j);
                all_rps.extend(rp); all_reports.extend(r)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_vaults = pd.DataFrame(all_vaults)
    df_plans = pd.DataFrame(all_plans)
    df_jobs = pd.DataFrame(all_jobs)
    df_rps = pd.DataFrame(all_rps)
    df_reports = pd.DataFrame(all_reports)
    
    # Sort for auditing
    if not df_vaults.empty: df_vaults = df_vaults.sort_values(by=['Region', 'Vault Name'])
    if not df_plans.empty: df_plans = df_plans.sort_values(by=['Region', 'Plan Name', 'Rule Name'])
    if not df_jobs.empty:
        # Put FAILED/ABORTED at the top
        state_priority = {'FAILED': 0, 'ABORTED': 1, 'EXPIRED': 2, 'CREATED': 3, 'PENDING': 4, 'RUNNING': 5, 'COMPLETED': 6}
        df_jobs['StateSort'] = df_jobs['State'].map(state_priority)
        df_jobs = df_jobs.sort_values(by=['StateSort', 'Creation Date'], ascending=[True, False])
        df_jobs = df_jobs.drop(columns=['StateSort'])
    if not df_rps.empty:
        df_rps = df_rps.sort_values(by=['Creation Date'], ascending=False) # Newest first
    if not df_reports.empty: df_reports = df_reports.sort_values(by=['Region', 'Report Plan Name'])
        
    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_vaults.to_excel(writer, sheet_name='Backup Vaults', index=False)
            df_plans.to_excel(writer, sheet_name='Backup Plans & Rules (Exploded)', index=False)
            df_rps.to_excel(writer, sheet_name='Recovery Points (Backups)', index=False)
            df_jobs.to_excel(writer, sheet_name='Backup Jobs (Last 7 Days)', index=False)
            df_reports.to_excel(writer, sheet_name='Report Plans (Compliance)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
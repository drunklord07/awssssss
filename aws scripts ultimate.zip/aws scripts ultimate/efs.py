import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "efs_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_FS = "details_efs_filesystems"
DIR_MT = "details_efs_mounttargets"
DIR_AP = "details_efs_accesspoints"
DIR_POL = "details_efs_policies"

for d in [DIR_FS, DIR_MT, DIR_AP, DIR_POL]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

def format_principal(principal):
    if principal == '*': return "Public (*)"
    if 'AWS' in principal: return str(principal['AWS'])
    if 'Service' in principal: return str(principal['Service'])
    return str(principal)

# --- WORKER ---
def audit_region_efs(region):
    """
    Audits all EFS components in a single region.
    """
    efs = boto3.client('efs', region_name=region)
    ec2 = boto3.client('ec2', region_name=region) # Needed for SG names
    
    res_fs, res_mounts, res_aps, res_policies = [], [], [], []
    
    sg_name_map = {} # Cache for SG names

    try:
        # --- 1. Audit File Systems ---
        paginator = efs.get_paginator('describe_file_systems')
        for page in paginator.paginate():
            for fs in page['FileSystems']:
                fs_id = fs['FileSystemId']
                full_data = {'FileSystem': fs}
                
                # --- 2. Get Mount Targets ---
                try:
                    mount_targets = efs.describe_mount_targets(FileSystemId=fs_id).get('MountTargets', [])
                    full_data['MountTargets'] = mount_targets
                    
                    for mt in mount_targets:
                        # Get Security Group names
                        sg_ids = efs.describe_mount_target_security_groups(MountTargetId=mt['MountTargetId']).get('SecurityGroups', [])
                        sg_names = []
                        for sg_id in sg_ids:
                            if sg_id not in sg_name_map:
                                try:
                                    sg_desc = ec2.describe_security_groups(GroupIds=[sg_id])['SecurityGroups'][0]
                                    sg_name_map[sg_id] = sg_desc.get('GroupName', 'N/A')
                                except ClientError:
                                    sg_name_map[sg_id] = "Error/Deleted"
                            sg_names.append(f"{sg_name_map[sg_id]} ({sg_id})")

                        res_mounts.append({
                            'Region': region,
                            'File System ID': fs_id,
                            'Mount Target ID': mt['MountTargetId'],
                            'Subnet ID': mt['SubnetId'],
                            'IP Address': mt.get('IpAddress', 'N/A'),
                            'VPC ID': mt.get('VpcId', 'N/A'),
                            'State': mt['LifeCycleState'],
                            'Security Groups': "\n".join(sg_names)
                        })
                except ClientError as e: print(f"\n[{region}] Error getting mount targets for {fs_id}: {e}")
                
                # --- 3. Get Access Points ---
                try:
                    aps = efs.describe_access_points(FileSystemId=fs_id).get('AccessPoints', [])
                    full_data['AccessPoints'] = aps
                    
                    for ap in aps:
                        res_aps.append({
                            'Region': region,
                            'File System ID': fs_id,
                            'Access Point ID': ap['AccessPointId'],
                            'Name': ap.get('Name', 'N/A'),
                            'Root Directory': ap.get('RootDirectory', {}).get('Path', '/'),
                            'POSIX User': f"UID:{ap['PosixUser']['Uid']} GID:{ap['PosixUser']['Gid']}" if 'PosixUser' in ap else 'N/A',
                            'State': ap['LifeCycleState'],
                            'ARN': ap['AccessPointArn']
                        })
                except ClientError as e: print(f"\n[{region}] Error getting access points for {fs_id}: {e}")

                # --- 4. Get Backup Policy ---
                try:
                    backup_pol = efs.describe_backup_policy(FileSystemId=fs_id)['BackupPolicy']
                    full_data['BackupPolicy'] = backup_pol
                    backup_status = backup_pol.get('Status', 'DISABLED')
                except ClientError: backup_status = "Error"
                
                # --- 5. Get Replication ---
                try:
                    repl = efs.describe_replication_configurations(FileSystemId=fs_id).get('Replications', [])
                    full_data['Replication'] = repl
                    repl_status = f"{len(repl)} destinations" if repl else "DISABLED"
                except ClientError: repl_status = "Error"
                
                # --- 6. Get File System Policy & Explode ---
                policy_attached = "No"
                try:
                    policy_str = efs.describe_file_system_policy(FileSystemId=fs_id).get('Policy', '{}')
                    policy_json = json.loads(policy_str)
                    full_data['Policy'] = policy_json
                    policy_attached = "Yes"
                    
                    for stmt in policy_json.get('Statement', []):
                        res_policies.append({
                            'Region': region,
                            'File System ID': fs_id,
                            'SID': stmt.get('Sid', 'No_SID'),
                            'Effect': stmt.get('Effect'),
                            'Principal': format_principal(stmt.get('Principal', {})),
                            'Action': str(stmt.get('Action')),
                            'Condition': str(stmt.get('Condition', {}))
                        })
                except ClientError as e:
                    if 'PolicyNotFound' in str(e): policy_attached = "No"
                    else: policy_attached = "Error"

                # --- 7. Save JSON & Build Excel Row ---
                file_ref = save_raw_json(DIR_FS, f"{region}_{fs_id}.json", full_data)
                
                res_fs.append({
                    'Region': region,
                    'File System ID': fs_id,
                    'Name': fs.get('Name', get_tag_value(fs.get('Tags'))),
                    'State': fs['LifeCycleState'],
                    'Encrypted': fs['Encrypted'],
                    'KMS Key ID': fs.get('KmsKeyId', 'Default'),
                    'Performance Mode': fs['PerformanceMode'],
                    'Throughput Mode': fs['ThroughputMode'],
                    'Size (Bytes)': fs['SizeInBytes']['Value'],
                    'Mount Target Count': fs['NumberOfMountTargets'],
                    'Backup Policy': backup_status,
                    'Replication': repl_status,
                    'Policy Attached?': policy_attached,
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_fs, res_mounts, res_aps, res_policies

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS EFS Ultimate Audit (FS, Mounts, Access Points, Policy) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_fs, all_mounts, all_aps, all_policies = [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_efs, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                fs, mt, ap, pol = future.result()
                all_fs.extend(fs); all_mounts.extend(mt); all_aps.extend(ap); all_policies.extend(pol)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_fs = pd.DataFrame(all_fs)
    df_mounts = pd.DataFrame(all_mounts)
    df_aps = pd.DataFrame(all_aps)
    df_policies = pd.DataFrame(all_policies)
    
    # Sort
    if not df_fs.empty: df_fs = df_fs.sort_values(by=['Region', 'Name'])
    if not df_mounts.empty: df_mounts = df_mounts.sort_values(by=['Region', 'File System ID', 'Mount Target ID'])
    if not df_aps.empty: df_aps = df_aps.sort_values(by=['Region', 'File System ID', 'Name'])
    if not df_policies.empty: df_policies = df_policies.sort_values(by=['Region', 'File System ID', 'SID'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_fs.to_excel(writer, sheet_name='EFS File Systems', index=False)
            df_mounts.to_excel(writer, sheet_name='EFS Mount Targets (Exploded)', index=False)
            df_aps.to_excel(writer, sheet_name='EFS Access Points (Exploded)', index=False)
            df_policies.to_excel(writer, sheet_name='EFS Policies (Exploded)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from urllib.parse import unquote

# --- CONFIGURATION ---
OUTPUT_FILE = "iam_ultimate_audit.xlsx"
MAX_WORKERS = 20  # IAM is global, high parallelism can cause throttling. Adjust if needed.

# Folders for 100% raw JSON details
DIR_USER = "details_iam_users"
DIR_GROUP = "details_iam_groups"
DIR_ROLE = "details_iam_roles"
DIR_POLICY = "details_iam_policies"

for d in [DIR_USER, DIR_GROUP, DIR_ROLE, DIR_POLICY]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def days_old(dt):
    if dt is None: return None
    return (datetime.datetime.now(datetime.timezone.utc) - dt).days

# --- PARALLEL WORKER FUNCTIONS ---

def audit_user(user_name):
    """Audits one user completely."""
    iam = boto3.client('iam')
    user_row = {}
    group_links = []
    policy_links = []
    
    try:
        user = iam.get_user(UserName=user_name)['User']
        save_raw_json(DIR_USER, f"{user_name}.json", user)
        
        # 1. Base Info
        user_row = {
            'User Name': user_name,
            'ARN': user['Arn'],
            'Created': user['CreateDate'].replace(tzinfo=None),
            'Last Activity': user.get('PasswordLastUsed')
        }
        
        # 2. MFA
        try:
            mfa = iam.list_mfa_devices(UserName=user_name)
            user_row['MFA Enabled'] = "Yes" if mfa.get('MFADevices') else "No"
        except ClientError: user_row['MFA Enabled'] = "Error"
        
        # 3. Console Password
        try:
            iam.get_login_profile(UserName=user_name)
            user_row['Has Console Password'] = "Yes"
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchEntity':
                user_row['Has Console Password'] = "No"
            else: user_row['Has Console Password'] = "Error"
        
        # 4. Access Keys & Last Used
        key_1_age, key_2_age = None, None
        key_1_last_used, key_2_last_used = None, None
        try:
            keys = iam.list_access_keys(UserName=user_name)['AccessKeyMetadata']
            if len(keys) > 0:
                key_1_age = days_old(keys[0]['CreateDate'])
                key_1_last_used = days_old(iam.get_access_key_last_used(AccessKeyId=keys[0]['AccessKeyId'])['AccessKeyLastUsed'].get('LastUsedDate'))
            if len(keys) > 1:
                key_2_age = days_old(keys[1]['CreateDate'])
                key_2_last_used = days_old(iam.get_access_key_last_used(AccessKeyId=keys[1]['AccessKeyId'])['AccessKeyLastUsed'].get('LastUsedDate'))
        except ClientError: pass
        user_row['Key 1 Age (Days)'] = key_1_age
        user_row['Key 1 Last Used (Days)'] = key_1_last_used
        user_row['Key 2 Age (Days)'] = key_2_age
        user_row['Key 2 Last Used (Days)'] = key_2_last_used
        
        # 5. Group Links
        paginator = iam.get_paginator('list_groups_for_user')
        for page in paginator.paginate(UserName=user_name):
            for group in page['Groups']:
                group_links.append({'User Name': user_name, 'Group Name': group['GroupName']})
        
        # 6. Policy Links
        paginator = iam.get_paginator('list_attached_user_policies')
        for page in paginator.paginate(UserName=user_name):
            for pol in page['AttachedPolicies']:
                policy_links.append({'User Name': user_name, 'Policy ARN': pol['PolicyArn'], 'Type': 'Managed'})
        
        paginator = iam.get_paginator('list_user_policies')
        for page in paginator.paginate(UserName=user_name):
            for pol_name in page['PolicyNames']:
                policy_links.append({'User Name': user_name, 'Policy ARN': f"inline:{pol_name}", 'Type': 'Inline'})

    except Exception as e:
        print(f"\n[Error] User {user_name}: {e}")
        user_row = {'User Name': user_name, 'ARN': f"Error: {e}"}

    return user_row, group_links, policy_links

def audit_role(role_name):
    """Audits one role completely."""
    iam = boto3.client('iam')
    role_row = {}
    policy_links = []
    
    try:
        role = iam.get_role(RoleName=role_name)['Role']
        save_raw_json(DIR_ROLE, f"{role_name}.json", role)
        
        # 1. Base Info
        trust_policy = role['AssumeRolePolicyDocument']
        principals = [str(s.get('AWS', s.get('Service', 'Federated'))) for s in trust_policy.get('Statement', [])]
        
        role_row = {
            'Role Name': role_name,
            'ARN': role['Arn'],
            'Trusts': ", ".join(sorted(list(set(principals)))),
            'Created': role['CreateDate'].replace(tzinfo=None)
        }
        
        # 2. Policy Links
        paginator = iam.get_paginator('list_attached_role_policies')
        for page in paginator.paginate(RoleName=role_name):
            for pol in page['AttachedPolicies']:
                policy_links.append({'Role Name': role_name, 'Policy ARN': pol['PolicyArn'], 'Type': 'Managed'})
        
        paginator = iam.get_paginator('list_role_policies')
        for page in paginator.paginate(RoleName=role_name):
            for pol_name in page['PolicyNames']:
                policy_links.append({'Role Name': role_name, 'Policy ARN': f"inline:{pol_name}", 'Type': 'Inline'})
                
    except Exception as e:
        print(f"\n[Error] Role {role_name}: {e}")
        role_row = {'Role Name': role_name, 'ARN': f"Error: {e}"}

    return role_row, policy_links

def audit_group(group_name):
    """Audits one group completely."""
    iam = boto3.client('iam')
    group_row = {}
    policy_links = []
    
    try:
        group = iam.get_group(GroupName=group_name)['Group']
        save_raw_json(DIR_GROUP, f"{group_name}.json", group)
        
        group_row = {'Group Name': group_name, 'ARN': group['Arn'], 'Created': group['CreateDate'].replace(tzinfo=None)}
        
        # Policy Links
        paginator = iam.get_paginator('list_attached_group_policies')
        for page in paginator.paginate(GroupName=group_name):
            for pol in page['AttachedPolicies']:
                policy_links.append({'Group Name': group_name, 'Policy ARN': pol['PolicyArn'], 'Type': 'Managed'})
        
        paginator = iam.get_paginator('list_group_policies')
        for page in paginator.paginate(GroupName=group_name):
            for pol_name in page['PolicyNames']:
                policy_links.append({'Group Name': group_name, 'Policy ARN': f"inline:{pol_name}", 'Type': 'Inline'})
                
    except Exception as e:
        print(f"\n[Error] Group {group_name}: {e}")
        group_row = {'Group Name': group_name, 'ARN': f"Error: {e}"}
        
    return group_row, policy_links

def audit_policy(policy_arn):
    """Audits one customer-managed policy."""
    iam = boto3.client('iam')
    policy_row = {}
    
    try:
        policy = iam.get_policy(PolicyArn=policy_arn)['Policy']
        
        # Get the actual JSON permission document
        ver = iam.get_policy_version(PolicyArn=policy_arn, VersionId=policy['DefaultVersionId'])
        doc = ver['PolicyVersion']['Document']
        
        policy['PolicyDocument'] = doc
        save_raw_json(DIR_POLICY, f"{policy['PolicyName']}.json", policy)

        policy_row = {
            'Policy Name': policy['PolicyName'],
            'ARN': policy['Arn'],
            'Is Attachable': policy['IsAttachable'],
            'Created': policy['CreateDate'].replace(tzinfo=None),
            'Permissions': json.dumps(doc) # Put summary in Excel
        }
    except Exception as e:
        print(f"\n[Error] Policy {policy_arn}: {e}")
        policy_row = {'Policy Name': policy_arn, 'ARN': f"Error: {e}"}
    
    return policy_row

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS IAM Ultimate Audit (All Properties) ---")
    print("WARNING: This is API-intensive and may take several minutes.")
    
    iam = boto3.client('iam')
    
    # --- PHASE 1: List all entities ---
    print("Phase 1: Listing all IAM entities...")
    try:
        users = [u['UserName'] for u in iam.get_paginator('list_users').paginate().build_full_result()['Users']]
        groups = [g['GroupName'] for g in iam.get_paginator('list_groups').paginate().build_full_result()['Groups']]
        roles = [r['RoleName'] for r in iam.get_paginator('list_roles').paginate().build_full_result()['Roles']]
        policies = [p['Arn'] for p in iam.get_paginator('list_policies').paginate(Scope='Local').build_full_result()['Policies']]
        print(f"Found: {len(users)} Users, {len(groups)} Groups, {len(roles)} Roles, {len(policies)} Policies.")
    except Exception as e:
        print(f"CRITICAL: Could not list entities. {e}"); return

    # --- PHASE 2: Audit all entities in parallel ---
    print("Phase 2: Auditing all entities in parallel...")
    
    # Final data lists
    user_rows, group_rows, role_rows, policy_rows = [], [], [], []
    link_user_group, link_user_policy, link_group_policy, link_role_policy = [], [], [], []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # Submit all jobs
        f_users = {executor.submit(audit_user, u): u for u in users}
        f_groups = {executor.submit(audit_group, g): g for g in groups}
        f_roles = {executor.submit(audit_role, r): r for r in roles}
        f_policies = {executor.submit(audit_policy, p): p for p in policies}

        # Process results
        print("Processing Users...")
        for f in as_completed(f_users):
            row, g_links, p_links = f.result()
            user_rows.append(row)
            link_user_group.extend(g_links)
            link_user_policy.extend(p_links)
            
        print("Processing Groups...")
        for f in as_completed(f_groups):
            row, p_links = f.result()
            group_rows.append(row)
            link_group_policy.extend(p_links)
            
        print("Processing Roles...")
        for f in as_completed(f_roles):
            row, p_links = f.result()
            role_rows.append(row)
            link_role_policy.extend(p_links)
            
        print("Processing Policies...")
        for f in as_completed(f_policies):
            policy_rows.append(f.result())

    # --- PHASE 3: Compile Excel Report ---
    print("\nPhase 3: Compiling 8-sheet Excel Report...")
    
    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            pd.DataFrame(user_rows).sort_values(by=['User Name']).to_excel(writer, sheet_name='Users', index=False)
            pd.DataFrame(group_rows).sort_values(by=['Group Name']).to_excel(writer, sheet_name='Groups', index=False)
            pd.DataFrame(role_rows).sort_values(by=['Role Name']).to_excel(writer, sheet_name='Roles', index=False)
            pd.DataFrame(policy_rows).sort_values(by=['Policy Name']).to_excel(writer, sheet_name='Policies (Customer)', index=False)
            pd.DataFrame(link_user_group).sort_values(by=['User Name', 'Group Name']).to_excel(writer, sheet_name='User-Group Links', index=False)
            pd.DataFrame(link_user_policy).sort_values(by=['User Name', 'Policy ARN']).to_excel(writer, sheet_name='User-Policy Links', index=False)
            pd.DataFrame(link_group_policy).sort_values(by=['Group Name', 'Policy ARN']).to_excel(writer, sheet_name='Group-Policy Links', index=False)
            pd.DataFrame(link_role_policy).sort_values(by=['Role Name', 'Policy ARN']).to_excel(writer, sheet_name='Role-Policy Links', index=False)

        print(f"✅ SUCCESS. Report: {OUTPUT_FILE}")
        print(f"   Time Taken: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
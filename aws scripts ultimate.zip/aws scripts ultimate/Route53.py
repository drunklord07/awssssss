import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "route53_ultimate_audit.xlsx"
MAX_WORKERS = 20  # For processing zones in parallel

# Folders for 100% raw JSON details
DIR_ZONE = "details_route53_zones"
DIR_RECORDS = "details_route53_records"
DIR_HEALTH = "details_route53_healthchecks"
DIR_DOMAIN = "details_route53_domains"
DIR_LOGS = "details_route53_querylogs"

for d in [DIR_ZONE, DIR_RECORDS, DIR_HEALTH, DIR_DOMAIN, DIR_LOGS]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

# --- WORKER FUNCTIONS ---
def audit_zone_details(zone_info, route53_client):
    """
    Worker function: Gets all details for a single hosted zone.
    (Records, DNSSEC, Query Logging)
    """
    zone_id = zone_info['Id'].split('/')[-1]
    zone_name = zone_info['Name']
    
    res_zone_row = {}
    res_records = []
    
    # --- 1. Get Full Zone Details ---
    try:
        full_zone = route53_client.get_hosted_zone(Id=zone_id)
        save_raw_json(DIR_ZONE, f"{zone_id}_{zone_name}", full_zone)
        
        tags = route53_client.list_tags_for_resource(ResourceType='hostedzone', ResourceId=zone_id).get('ResourceTagSet', {}).get('Tags', [])
        
        res_zone_row = {
            'Zone Name': zone_name,
            'Zone ID': zone_id,
            'Type': 'Private' if full_zone['HostedZone']['Config']['PrivateZone'] else 'Public',
            'Record Count': full_zone['HostedZone']['ResourceRecordSetCount'],
            'Tags': get_tag_value(tags)
        }
    except ClientError as e:
        print(f"\nError getting zone details for {zone_id}: {e}")
        return None, []

    # --- 2. Get DNSSEC Status ---
    try:
        dnssec = route53_client.get_dnssec(HostedZoneId=zone_id)
        save_raw_json(DIR_ZONE, f"{zone_id}_dnssec.json", dnssec)
        res_zone_row['DNSSEC Status'] = dnssec['Status']['ServeSignature']
    except ClientError:
        res_zone_row['DNSSEC Status'] = "Error"
        
    # --- 3. Get Query Logging ---
    try:
        logs = route53_client.list_query_logging_configs(HostedZoneId=zone_id).get('QueryLoggingConfigs', [])
        save_raw_json(DIR_LOGS, f"{zone_id}_querylogs.json", logs)
        if not logs:
            res_zone_row['Query Log Status'] = "DISABLED"
            res_zone_row['Query Log Group ARN'] = "N/A"
        else:
            res_zone_row['Query Log Status'] = "ENABLED"
            res_zone_row['Query Log Group ARN'] = logs[0]['CloudWatchLogsLogGroupArn'] # A zone can only have one
    except ClientError:
        res_zone_row['Query Log Status'] = "Error"
        res_zone_row['Query Log Group ARN'] = "Error"

    # --- 4. Explode DNS Records ---
    try:
        paginator = route53_client.get_paginator('list_resource_record_sets')
        for page in paginator.paginate(HostedZoneId=zone_id):
            save_raw_json(DIR_RECORDS, f"{zone_id}_{zone_name}_records_page.json", page['ResourceRecordSets'])
            
            for record in page['ResourceRecordSets']:
                # Determine value: either an Alias or a list of Records
                value = "N/A"
                if 'AliasTarget' in record:
                    value = f"[ALIAS] {record['AliasTarget']['DNSName']}"
                elif 'ResourceRecords' in record:
                    value = "\n".join([r['Value'] for r in record['ResourceRecords']])
                
                res_records.append({
                    'Zone Name': zone_name,
                    'Record Name': record['Name'],
                    'Type': record['Type'],
                    'TTL': record.get('TTL', 'N/A (Alias)'),
                    'Value / Alias Target': value,
                    'Health Check ID': record.get('HealthCheckId', 'N/A')
                })
    except ClientError as e:
        print(f"\nError getting records for {zone_id}: {e}")

    return res_zone_row, res_records

def audit_health_checks(route53_client):
    """Gets all Route 53 Health Checks."""
    res_health_checks = []
    try:
        paginator = route53_client.get_paginator('list_health_checks')
        for page in paginator.paginate():
            for hc in page['HealthChecks']:
                hc_id = hc['Id']
                full_hc = route53_client.get_health_check(HealthCheckId=hc_id) # Get full details
                config = full_hc['HealthCheck']['HealthCheckConfig']
                
                file_ref = save_raw_json(DIR_HEALTH, f"{hc_id}.json", full_hc)
                
                res_health_checks.append({
                    'Health Check ID': hc_id,
                    'Type': config['Type'],
                    'Target IP/Domain': config.get('IPAddress', config.get('FullyQualifiedDomainName', 'N/A')),
                    'Port': config.get('Port', 'N/A'),
                    'Path': config.get('ResourcePath', 'N/A'),
                    'Failure Threshold': config.get('FailureThreshold', 'N/A'),
                    'Request Interval': config.get('RequestInterval', 'N/A'),
                    'Full Detail File': file_ref
                })
    except ClientError as e:
        print(f"\nError auditing health checks: {e}")
    return res_health_checks

def audit_domain_registrations():
    """Gets all registered domains (registrar)."""
    res_domains = []
    try:
        # This is a different client and is only in us-east-1
        client = boto3.client('route53domains', region_name='us-east-1')
        paginator = client.get_paginator('list_domains')
        for page in paginator.paginate():
            for domain in page['Domains']:
                domain_name = domain['DomainName']
                details = client.get_domain_detail(DomainName=domain_name)
                file_ref = save_raw_json(DIR_DOMAIN, f"{domain_name}.json", details)
                
                res_domains.append({
                    'Domain Name': domain_name,
                    'Expiry Date': details.get('ExpirationDate'),
                    'Auto-Renew': domain['AutoRenew'],
                    'Admin Contact': details.get('AdminContact', {}).get('Email', 'N/A'),
                    'Registrar': 'Route 53',
                    'Full Detail File': file_ref
                })
    except ClientError as e:
        print(f"\nCould not audit domain registrations (is this the root account?): {e}")
    return res_domains

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Route 53 Ultimate Audit (Zones, Records, Health Checks, Domains) ---")
    
    route53 = boto3.client('route53')
    all_zones, all_records = [], []
    
    print("Phase 1: Listing Hosted Zones...")
    zones_to_process = []
    try:
        paginator = route53.get_paginator('list_hosted_zones')
        for page in paginator.paginate():
            zones_to_process.extend(page['HostedZones'])
    except Exception as e:
        print(f"CRITICAL: Could not list hosted zones. {e}"); return
        
    print(f"Phase 2: Auditing {len(zones_to_process)} zones in parallel...")
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_zone_details, z, route53): z['Id'] for z in zones_to_process}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            print(f"\rProgress (Zones): {done}/{len(zones_to_process)}", end="")
            try:
                zone_row, record_list = future.result()
                if zone_row:
                    all_zones.append(zone_row)
                all_records.extend(record_list)
            except Exception as e:
                print(f"\nError in zone thread: {e}")

    print("\nPhase 3: Auditing Health Checks...")
    all_health_checks = audit_health_checks(route53)
    
    print("Phase 4: Auditing Domain Registrations (us-east-1)...")
    all_domains = audit_domain_registrations()

    print("\nCompiling Excel Report...")

    # Create DataFrames
    df_zones = pd.DataFrame(all_zones)
    df_records = pd.DataFrame(all_records)
    df_health = pd.DataFrame(all_health_checks)
    df_domains = pd.DataFrame(all_domains)
    
    # Sort
    if not df_zones.empty: df_zones = df_zones.sort_values(by=['Type', 'Zone Name'])
    if not df_records.empty: df_records = df_records.sort_values(by=['Zone Name', 'Type', 'Record Name'])
    if not df_health.empty: df_health = df_health.sort_values(by=['Type', 'Target IP/Domain'])
    if not df_domains.empty: df_domains = df_domains.sort_values(by=['Expiry Date'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_zones.to_excel(writer, sheet_name='Hosted Zones (Master List)', index=False)
            df_records.to_excel(writer, sheet_name='DNS Records (Exploded)', index=False)
            df_health.to_excel(writer, sheet_name='Health Checks', index=False)
            df_domains.to_excel(writer, sheet_name='Domain Registrations', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
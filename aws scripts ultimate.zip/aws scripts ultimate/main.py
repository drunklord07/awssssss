import os
import glob
import subprocess
import sys
import time
from tqdm import tqdm

def run_all_audits():
    """
    Finds and executes all other Python scripts in the current folder,
    showing a master progress bar.
    
    This version will not stop if a script fails.
    """
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    current_script_name = os.path.basename(__file__)
    
    all_scripts_in_folder = glob.glob(os.path.join(script_dir, "*.py"))
    
    scripts_to_run = [
        s for s in all_scripts_in_folder 
        if os.path.basename(s) != current_script_name
    ]
    
    if not scripts_to_run:
        print("No other audit scripts (.py files) found in this folder.")
        return

    print(f"Found {len(scripts_to_run)} audit scripts to run.")
    print("Starting the master audit...")
    time.sleep(2) # Give user time to read
    
    python_executable = sys.executable

    # --- NEW: List to track failures ---
    failed_scripts = []

    # --- Setup the Progress Bar ---
    progress_bar = tqdm(
        total=len(scripts_to_run), 
        desc="Master Audit Progress", 
        unit="script"
    )

    # --- Run each script one by one ---
    for script_path in scripts_to_run:
        script_name = os.path.basename(script_path)
        
        progress_bar.set_description(f"Running: {script_name}")
        
        print(f"\n\n{'='*20} 🚀 STARTING: {script_name} {'='*20}")
        
        start_time = time.time()
        
        try:
            # We still use check=True to catch the error
            subprocess.run(
                [python_executable, script_path], 
                check=True,
                text=True
            )
            
            duration = time.time() - start_time
            print(f"--- ✅ FINISHED: {script_name} (Took {duration:.2f}s) ---")

        except subprocess.CalledProcessError as e:
            # --- MODIFIED: Don't stop ---
            duration = time.time() - start_time
            print(f"\n{'='*20} ❌ ERROR IN: {script_name} (After {duration:.2f}s) {'='*20}")
            print(f"The script {script_name} failed with a non-zero exit code.")
            print("See error output above. Continuing to the next script...")
            # Add the failed script to our list
            failed_scripts.append(script_name)
            
        except KeyboardInterrupt:
            print(f"\n\n{'='*20} 🛑 AUDIT MANUALLY STOPPED {'='*20}")
            progress_bar.close()
            sys.exit(1)

        # Update the progress bar by 1 (this runs on success or failure)
        progress_bar.update(1)

    # --- MODIFIED FINAL SUMMARY ---
    progress_bar.set_description("All audits complete!")
    progress_bar.close()
    
    total_run = len(scripts_to_run)
    total_failed = len(failed_scripts)
    total_success = total_run - total_failed

    print(f"\n\n{'='*20} 🎉 MASTER AUDIT COMPLETE {'='*20}")
    print(f"All {total_run} scripts have finished processing.")
    
    if total_success > 0:
        print(f"\n  ✅ {total_success} script(s) ran successfully.")
        
    if total_failed > 0:
        print(f"\n  ❌ {total_failed} script(s) failed:")
        for script in failed_scripts:
            print(f"    - {script}")
    
    print("\nAll generated .xlsx and .json files are available.")

if __name__ == "__main__":
    run_all_audits()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "redshift_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_CLUSTER = "details_redshift_clusters"
DIR_SNAP = "details_redshift_snapshots"
DIR_SUBNET = "details_redshift_subnet_groups"
DIR_PARAM = "details_redshift_param_groups"

for d in [DIR_CLUSTER, DIR_SNAP, DIR_SUBNET, DIR_PARAM]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

# --- WORKER ---
def audit_region_redshift(region):
    """
    Audits all Redshift components in a single region.
    """
    redshift = boto3.client('redshift', region_name=region)
    
    res_clusters, res_snaps, res_subnets, res_params, res_iam_roles = [], [], [], [], []
    
    try:
        # --- 1. Audit Clusters ---
        paginator = redshift.get_paginator('describe_clusters')
        for page in paginator.paginate():
            for cluster in page['Clusters']:
                cluster_id = cluster['ClusterIdentifier']
                
                # Save raw JSON
                file_ref = save_raw_json(DIR_CLUSTER, f"{region}_{cluster_id}", cluster)
                
                # Get VPC Security Groups
                sgs = [sg['VpcSecurityGroupId'] for sg in cluster.get('VpcSecurityGroups', [])]
                
                # Build Excel Row
                res_clusters.append({
                    'Region': region,
                    'Cluster Identifier': cluster_id,
                    'Status': cluster['ClusterStatus'],
                    'Publicly Accessible': cluster['PubliclyAccessible'],
                    'Encrypted': cluster['Encrypted'],
                    'KMS Key ID': cluster.get('KmsKeyId', 'Default'),
                    'Node Type': cluster['NodeType'],
                    'Number of Nodes': cluster['NumberOfNodes'],
                    'VPC ID': cluster.get('VpcId', 'N/A (Classic)'),
                    'Subnet Group': cluster.get('ClusterSubnetGroupName', 'N/A'),
                    'Security Groups': ", ".join(sgs),
                    'Endpoint Address': cluster.get('Endpoint', {}).get('Address', 'N/A'),
                    'Backup Retention (Days)': cluster.get('AutomatedSnapshotRetentionPeriod', 0),
                    'Tags': get_tag_value(cluster.get('Tags')),
                    'Full Detail File': file_ref
                })
                
                # Explode IAM Roles
                for role in cluster.get('IamRoles', []):
                    res_iam_roles.append({
                        'Region': region,
                        'Cluster Identifier': cluster_id,
                        'IAM Role ARN': role['IamRoleArn'],
                        'Status': role['ApplyStatus']
                    })

        # --- 2. Audit Snapshots ---
        paginator = redshift.get_paginator('describe_cluster_snapshots')
        for page in paginator.paginate(SortBy='CREATE_TIME', SortOrder='ASCENDING'): # Get oldest first
            for snap in page['Snapshots']:
                snap_id = snap['SnapshotIdentifier']
                file_ref = save_raw_json(DIR_SNAP, f"{region}_{snap_id}", snap)
                
                res_snaps.append({
                    'Region': region,
                    'Snapshot ID': snap_id,
                    'Source Cluster': snap['ClusterIdentifier'],
                    'Status': snap['Status'],
                    'Creation Time': snap['ClusterCreateTime'].replace(tzinfo=None),
                    'Snapshot Type': snap['SnapshotType'],
                    'Encrypted': snap['Encrypted'],
                    'KMS Key ID': snap.get('KmsKeyId', 'Default'),
                    'Tags': get_tag_value(snap.get('Tags')),
                    'Full Detail File': file_ref
                })

        # --- 3. Audit Subnet Groups ---
        paginator = redshift.get_paginator('describe_cluster_subnet_groups')
        for page in paginator.paginate():
            for sg in page['ClusterSubnetGroups']:
                sg_name = sg['ClusterSubnetGroupName']
                file_ref = save_raw_json(DIR_SUBNET, f"{region}_{sg_name}", sg)
                
                res_subnets.append({
                    'Region': region,
                    'Group Name': sg_name,
                    'VPC ID': sg['VpcId'],
                    'Subnets': "\n".join([s['SubnetIdentifier'] for s in sg.get('Subnets', [])]),
                    'Full Detail File': file_ref
                })

        # --- 4. Audit Parameter Groups ---
        paginator = redshift.get_paginator('describe_cluster_parameter_groups')
        for page in paginator.paginate():
            for pg in page['ClusterParameterGroups']:
                pg_name = pg['ParameterGroupName']
                file_ref = save_raw_json(DIR_PARAM, f"{region}_{pg_name}", pg)
                
                res_params.append({
                    'Region': region,
                    'Group Name': pg_name,
                    'Family': pg['ParameterGroupFamily'],
                    'Description': pg['Description'],
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_clusters, res_snaps, res_subnets, res_params, res_iam_roles

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Redshift Ultimate Audit (Clusters, Snaps, Security, Roles) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_c, all_s, all_sg, all_p, all_r = [], [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_redshift, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                c, s, sg, p, r = future.result()
                all_c.extend(c); all_s.extend(s); all_sg.extend(sg); all_p.extend(p); all_r.extend(r)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_clusters = pd.DataFrame(all_c)
    df_snaps = pd.DataFrame(all_s)
    df_subnets = pd.DataFrame(all_sg)
    df_params = pd.DataFrame(all_p)
    df_roles = pd.DataFrame(all_r)
    
    # Sort
    if not df_clusters.empty:
        # Pre-sort to bring Public (True) to the top
        df_clusters = df_clusters.sort_values(by=['Publicly Accessible', 'Region', 'Cluster Identifier'], ascending=[False, True, True])
    if not df_snaps.empty:
        # Pre-sort to bring Oldest first
        df_snaps = df_snaps.sort_values(by=['Creation Time'], ascending=True)

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_clusters.to_excel(writer, sheet_name='Redshift Clusters', index=False)
            df_snaps.to_excel(writer, sheet_name='Cluster Snapshots (Exploded)', index=False)
            df_subnets.to_excel(writer, sheet_name='Cluster Subnet Groups', index=False)
            df_params.to_excel(writer, sheet_name='Cluster Parameter Groups', index=False)
            df_roles.to_excel(writer, sheet_name='Cluster IAM Roles (Exploded)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
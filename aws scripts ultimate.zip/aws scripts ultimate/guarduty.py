import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "guardduty_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_DETECTOR = "details_guardduty_detectors"
DIR_LISTS = "details_guardduty_lists"
DIR_ADMIN = "details_guardduty_admin"

for d in [DIR_DETECTOR, DIR_LISTS, DIR_ADMIN]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

# --- WORKER ---
def audit_region_guardduty(region):
    """
    Audits all GuardDuty components in a single region.
    """
    gd = boto3.client('guardduty', region_name=region)
    
    res_detectors = []
    res_threat_lists = []
    
    try:
        # 1. List Detectors
        # A region will have 0 or 1 detector.
        detectors = gd.list_detectors().get('DetectorIds', [])
        
        if not detectors:
            res_detectors.append({'Region': region, 'Status': 'DISABLED', 'Detector ID': 'N/A'})
            return res_detectors, res_threat_lists
            
        detector_id = detectors[0]

        # 2. Get Full Detector Details
        detector_details = gd.get_detector(DetectorId=detector_id)
        detector_details.pop('ResponseMetadata', None)
        
        # 3. Get S3 Export Destination
        try:
            dest = gd.list_publishing_destinations(DetectorId=detector_id)
            dest_id = dest['Destinations'][0]['DestinationId'] if dest.get('Destinations') else 'N/A'
            s3_export_status = dest['Destinations'][0]['Status'] if dest.get('Destinations') else 'DISABLED'
            full_data = {'Detector': detector_details, 'PublishingDestinations': dest}
        except ClientError:
            s3_export_status = "Error"
            dest_id = "Error"
            full_data = {'Detector': detector_details}

        # 4. Save JSON
        file_ref = save_raw_json(DIR_DETECTOR, f"{region}_{detector_id}.json", full_data)

        # 5. Build Excel Row (Flattening Protection Plans)
        row = {
            'Region': region,
            'Status': detector_details.get('Status', 'ERROR'),
            'Detector ID': detector_id,
            'Finding Publishing Frequency': detector_details.get('FindingPublishingFrequency'),
            'S3 Export Status': s3_export_status,
            'S3 Export Destination ID': dest_id,
            'Full Detail File': file_ref
        }
        
        # Flatten all Data Sources (Protection Plans)
        data_sources = detector_details.get('DataSources', {})
        row['DS_CloudTrail'] = data_sources.get('CloudTrail', {}).get('Status', 'DISABLED')
        row['DS_DNSLogs'] = data_sources.get('DNSLogs', {}).get('Status', 'DISABLED')
        row['DS_FlowLogs'] = data_sources.get('FlowLogs', {}).get('Status', 'DISABLED')
        row['DS_S3Logs'] = data_sources.get('S3Logs', {}).get('Status', 'DISABLED')
        
        k8s = data_sources.get('Kubernetes', {})
        row['DS_K8s_AuditLogs'] = k8s.get('AuditLogs', {}).get('Status', 'DISABLED')
        
        malware = data_sources.get('MalwareProtection', {})
        row['DS_Malware_ScanEC2'] = malware.get('ScanEc2InstanceWithFindings', {}).get('EbsVolumes', {}).get('Status', 'DISABLED')
        row['DS_Malware_S3'] = malware.get('S3Logs', {}).get('Status', 'DISABLED')
        
        # Flatten all Features (Additional Protection Plans)
        features = detector_details.get('Features', [])
        for f in features:
            name = f.get('Name')
            status = f.get('Status')
            if name == 'EKS_RUNTIME_MONITORING':
                row['Feature_EKS_Runtime'] = status
            elif name == 'RUNTIME_MONITORING':
                row['Feature_EC2_Runtime'] = status
            elif name == 'RDS_LOGIN_EVENTS':
                row['Feature_RDS_Protection'] = status
            elif name == 'LAMBDA_NETWORK_LOGS':
                row['Feature_Lambda_Protection'] = status
        
        res_detectors.append(row)

        # 6. List ThreatIntelSets
        paginator = gd.get_paginator('list_threat_intel_sets')
        for page in paginator.paginate(DetectorId=detector_id):
            for set_id in page['ThreatIntelSetIds']:
                s = gd.get_threat_intel_set(DetectorId=detector_id, ThreatIntelSetId=set_id)
                s_file = save_raw_json(DIR_LISTS, f"{region}_threatintel_{set_id}.json", s)
                res_threat_lists.append({
                    'List Type': 'ThreatIntelSet',
                    'Name': s.get('Name'),
                    'Region': region,
                    'Detector ID': detector_id,
                    'Format': s.get('Format'),
                    'Status': s.get('Status'),
                    'Full Detail File': s_file
                })
        
        # 7. List IPSets
        paginator = gd.get_paginator('list_ip_sets')
        for page in paginator.paginate(DetectorId=detector_id):
            for set_id in page['IpSetIds']:
                s = gd.get_ip_set(DetectorId=detector_id, IpSetId=set_id)
                s_file = save_raw_json(DIR_LISTS, f"{region}_ipset_{set_id}.json", s)
                res_threat_lists.append({
                    'List Type': 'IPSet (Trusted)',
                    'Name': s.get('Name'),
                    'Region': region,
                    'Detector ID': detector_id,
                    'Format': s.get('Format'),
                    'Status': s.get('Status'),
                    'Full Detail File': s_file
                })
        
    except Exception as e:
        if "AuthFailure" not in str(e) and "OptInRequired" not in str(e): 
            print(f"[{region}] Error: {e}")
        if "AccessDenied" in str(e):
             res_detectors.append({'Region': region, 'Status': 'AccessDenied', 'Detector ID': 'N/A'})

    return res_detectors, res_threat_lists

def audit_organization_admin():
    """
    Checks for a GuardDuty Delegated Administrator.
    This must be run from the Org Management account.
    """
    res_admins = []
    # This API only works in us-east-1, but it's global
    try:
        gd = boto3.client('guardduty', region_name='us-east-1')
        paginator = gd.get_paginator('list_organization_admin_accounts')
        for page in paginator.paginate():
            for admin in page['AdminAccounts']:
                res_admins.append(admin)
        
        save_raw_json(DIR_ADMIN, "delegated_admins.json", res_admins)
                
    except ClientError as e:
        if "AccessDenied" in str(e):
            print("Note: Could not check for Delegated Admin. Run this from the Org Management account.")
            return [{'AdminAccountId': 'AccessDenied', 'AdminStatus': 'N/A'}]
    except Exception:
        # Fails if not an org
        return [{'AdminAccountId': 'Not an Org or Error', 'AdminStatus': 'N/A'}]
        
    if not res_admins:
        return [{'AdminAccountId': 'None', 'AdminStatus': 'None'}]
    
    return res_admins

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS GuardDuty Ultimate Audit (All Regions & Features) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_detectors, all_lists = [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_guardduty, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                det, lists = future.result()
                all_detectors.extend(det)
                all_lists.extend(lists)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\nChecking for Delegated Administrator...")
    all_admins = audit_organization_admin()

    print("Compiling Excel Report...")

    # Create DataFrames
    df_detectors = pd.DataFrame(all_detectors)
    df_admins = pd.DataFrame(all_admins)
    df_lists = pd.DataFrame(all_lists)
    
    # Sort
    if not df_detectors.empty: df_detectors = df_detectors.sort_values(by=['Region'])
    if not df_lists.empty: df_lists = df_lists.sort_values(by=['Region', 'List Type', 'Name'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_detectors.to_excel(writer, sheet_name='GuardDuty Detectors (by Region)', index=False)
            df_admins.to_excel(writer, sheet_name='Delegated Admins (Org)', index=False)
            df_lists.to_excel(writer, sheet_name='Custom Threat Lists', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "xray_ultimate_audit.xlsx"
MAX_WORKERS = 20
TRACE_HISTORY_HOURS = 6  # How many hours of trace history to pull

# Folders for 100% raw JSON details
DIR_CONFIG = "details_xray_config"
DIR_SAMPLING = "details_xray_sampling"
DIR_GROUPS = "details_xray_groups"
DIR_TRACES = "details_xray_traces"

for d in [DIR_CONFIG, DIR_SAMPLING, DIR_GROUPS, DIR_TRACES]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

# --- WORKER ---
def audit_region_xray(region):
    """
    Audits all X-Ray components in a single region.
    """
    xray = boto3.client('xray', region_name=region)
    
    res_config, res_rules, res_groups, res_traces = [], [], [], []
    
    try:
        # --- 1. Audit Encryption Config ---
        try:
            config = xray.get_encryption_config()['EncryptionConfig']
            file_ref = save_raw_json(DIR_CONFIG, f"{region}_encryption_config", config)
            res_config.append({
                'Region': region,
                'Status': config['Status'],
                'Encryption Type': config['Type'],
                'KMS Key ID': config.get('KeyId', 'Default (aws/xray)'),
                'Full Detail File': file_ref
            })
        except ClientError as e:
            # If no config is set, it's default. But if we get AccessDenied, it's an error.
            if "AccessDenied" in str(e):
                res_config.append({'Region': region, 'Status': 'AccessDenied', 'Encryption Type': 'N/A'})
            else:
                res_config.append({'Region': region, 'Status': 'ACTIVE', 'Encryption Type': 'Default'})

        # --- 2. Audit Sampling Rules (Exploded) ---
        paginator = xray.get_paginator('get_sampling_rules')
        for page in paginator.paginate():
            for rule in page['SamplingRuleRecords']:
                r = rule['SamplingRule']
                file_ref = save_raw_json(DIR_SAMPLING, f"{region}_{r['RuleName']}", rule)
                res_rules.append({
                    'Region': region,
                    'Rule Name': r['RuleName'],
                    'Priority': r['Priority'],
                    'Fixed Rate': r['FixedRate'],
                    'Reservoir Size': r['ReservoirSize'],
                    'Service Name': r['ServiceName'],
                    'HTTP Method': r['HTTPMethod'],
                    'URL Path': r['URLPath'],
                    'Host': r.get('Host', '*'),
                    'ARN': r['RuleARN'],
                    'Full Detail File': file_ref
                })
                
        # --- 3. Audit Groups ---
        paginator = xray.get_paginator('get_groups')
        for page in paginator.paginate():
            for group in page['Groups']:
                group_name = group['GroupName']
                file_ref = save_raw_json(DIR_GROUPS, f"{region}_{group_name}", group)
                res_groups.append({
                    'Region': region,
                    'Group Name': group_name,
                    'Group ARN': group['GroupARN'],
                    'Filter Expression': group.get('FilterExpression', 'N/A'),
                    'Full Detail File': file_ref
                })
        
        # --- 4. Audit Recent Traces (Last X Hours) ---
        end_time = datetime.datetime.now(datetime.timezone.utc)
        start_time = end_time - datetime.timedelta(hours=TRACE_HISTORY_HOURS)
        
        paginator = xray.get_paginator('get_trace_summaries')
        for page in paginator.paginate(StartTime=start_time, EndTime=end_time, Sampling=False):
            for trace in page['TraceSummaries']:
                file_ref = save_raw_json(DIR_TRACES, f"{region}_{trace['Id']}", trace)
                
                # Check for errors/faults
                http_status = None
                if trace.get('Http', {}).get('HttpStatus'):
                    http_status = trace['Http']['HttpStatus']
                
                res_traces.append({
                    'Region': region,
                    'Trace ID': trace['Id'],
                    'Start Time': trace['StartTime'],
                    'Duration (sec)': trace.get('Duration', 0),
                    'HTTP Status': http_status,
                    'Error?': trace.get('HasError', False),
                    'Fault?': trace.get('HasFault', False),
                    'Is Partial': trace.get('IsPartial', False),
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e) and "UnrecognizedClientException" not in str(e): 
            print(f"[{region}] Error: {e}")

    return res_config, res_rules, res_groups, res_traces

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS X-Ray Ultimate Audit (Config, Sampling, Traces) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_c, all_r, all_g, all_t = [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_xray, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                c, r, g, t = future.result()
                all_c.extend(c); all_r.extend(r); all_g.extend(g); all_t.extend(t)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_config = pd.DataFrame(all_c)
    df_rules = pd.DataFrame(all_r)
    df_groups = pd.DataFrame(all_g)
    df_traces = pd.DataFrame(all_t)
    
    # Sort
    if not df_config.empty: df_config = df_config.sort_values(by=['Region'])
    if not df_rules.empty: df_rules = df_rules.sort_values(by=['Region', 'Priority'])
    if not df_groups.empty: df_groups = df_groups.sort_values(by=['Region', 'Group Name'])
    if not df_traces.empty: df_traces = df_traces.sort_values(by=['Start Time'], ascending=False)
        
    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_config.to_excel(writer, sheet_name='X-Ray Config (by Region)', index=False)
            df_rules.to_excel(writer, sheet_name='Sampling Rules (Exploded)', index=False)
            df_groups.to_excel(writer, sheet_name='Groups (Exploded)', index=False)
            df_traces.to_excel(writer, sheet_name='Recent Traces (Last 6 Hrs)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
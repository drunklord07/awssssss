import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "cloudformation_ultimate_audit.xlsx"
MAX_WORKERS = 15 # CloudFormation has strict API limits

# Folders for 100% raw JSON details
DIR_STACK = "details_cfn_stacks"
DIR_TEMPLATE = "details_cfn_templates"
DIR_POLICY = "details_cfn_policies"
DIR_DRIFT = "details_cfn_drift"
DIR_SET = "details_cfn_stacksets"

for d in [DIR_STACK, DIR_TEMPLATE, DIR_POLICY, DIR_DRIFT, DIR_SET]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def get_tag_value(tags_list):
    if not tags_list: return ""
    return "; ".join([f"{t['Key']}={t['Value']}" for t in tags_list])

# --- WORKER ---
def audit_region_cfn(region):
    """
    Audits all CloudFormation components in a single region.
    """
    cfn = boto3.client('cloudformation', region_name=region)
    
    res_stacks, res_drifts, res_changes, res_exports = [], [], [], []
    
    try:
        # --- 1. Audit Stacks ---
        paginator = cfn.get_paginator('describe_stacks')
        for page in paginator.paginate():
            for stack in page['Stacks']:
                stack_name = stack['StackName']
                stack_id = stack['StackId']
                
                # Save raw JSON
                file_ref = save_raw_json(DIR_STACK, f"{region}_{stack_name}", stack)
                
                # Get Template
                try:
                    template = cfn.get_template(StackName=stack_name)
                    save_raw_json(DIR_TEMPLATE, f"{region}_{stack_name}_template.json", template)
                except ClientError: pass

                # Get Stack Policy
                policy_attached = "No"
                try:
                    policy = cfn.get_stack_policy(StackName=stack_name)
                    save_raw_json(DIR_POLICY, f"{region}_{stack_name}_policy.json", json.loads(policy['StackPolicyBody']))
                    policy_attached = "Yes"
                except ClientError: pass # No policy is normal
                
                drift_status = stack.get('DriftInformation', {}).get('StackDriftStatus', 'NOT_CHECKED')
                
                # Build Excel Row
                res_stacks.append({
                    'Region': region,
                    'Stack Name': stack_name,
                    'Status': stack['StackStatus'],
                    'Stack Drift Status': drift_status,
                    'Termination Protection': stack.get('EnableTerminationProtection', False),
                    'IAM Role ARN': stack.get('RoleARN', 'N/A'),
                    'Stack Policy?': policy_attached,
                    'Capabilities': ", ".join(stack.get('Capabilities', [])),
                    'Last Updated Time': stack.get('LastUpdatedTime', stack['CreationTime']).replace(tzinfo=None),
                    'Tags': get_tag_value(stack.get('Tags')),
                    'Full Detail File': file_ref
                })

                # --- 2. Explode Drifted Resources ---
                if drift_status == 'DRIFTED':
                    try:
                        drift_paginator = cfn.get_paginator('describe_stack_resource_drifts')
                        for drift_page in drift_paginator.paginate(StackName=stack_name, StackResourceDriftStatusFilters=['MODIFIED', 'DELETED']):
                            for drift in drift_page['StackResourceDrifts']:
                                file_drift_ref = save_raw_json(DIR_DRIFT, f"{region}_{stack_name}_{drift['LogicalResourceId']}.json", drift)
                                res_drifts.append({
                                    'Region': region,
                                    'Stack Name': stack_name,
                                    'Logical ID': drift['LogicalResourceId'],
                                    'Physical ID': drift.get('PhysicalResourceId', 'N/A'),
                                    'Resource Type': drift['ResourceType'],
                                    'Drift Status': drift['StackResourceDriftStatus'],
                                    'Property Differences': len(drift.get('PropertyDifferences', [])),
                                    'Full Detail File': file_drift_ref
                                })
                    except ClientError as e:
                        print(f"\n[{region}] Error describing drift for {stack_name}: {e}")
                        
                # --- 3. Get Change Sets ---
                try:
                    cs_paginator = cfn.get_paginator('list_change_sets')
                    for cs_page in cs_paginator.paginate(StackName=stack_name):
                        for cs in cs_page['Summaries']:
                            if cs['ExecutionStatus'] == 'AVAILABLE': # Only care about pending
                                res_changes.append({
                                    'Region': region,
                                    'Stack Name': stack_name,
                                    'Change Set Name': cs['ChangeSetName'],
                                    'Status': cs['Status'],
                                    'Execution Status': cs['ExecutionStatus'],
                                    'Creation Time': cs['CreationTime'].replace(tzinfo=None)
                                })
                except ClientError: pass

        # --- 4. List Exports ---
        paginator = cfn.get_paginator('list_exports')
        for page in paginator.paginate():
            for export in page['Exports']:
                res_exports.append({
                    'Region': region,
                    'Export Name': export['Name'],
                    'Value': export['Value'],
                    'Exporting Stack': export['ExportingStackId'].split('/')[1],
                })
                
    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_stacks, res_drifts, res_changes, res_exports

def audit_global_stacksets(region='us-east-1'):
    """Audits StackSets, which are a global resource."""
    print("\nAuditing StackSets (Global Service)...")
    cfn = boto3.client('cloudformation', region_name=region)
    res_sets = []
    
    try:
        paginator = cfn.get_paginator('list_stack_sets')
        for page in paginator.paginate(Status='ACTIVE'):
            for ss in page['Summaries']:
                ss_name = ss['StackSetName']
                full_ss = cfn.describe_stack_set(StackSetName=ss_name)
                
                file_ref = save_raw_json(DIR_SET, f"{ss_name}", full_ss)
                
                res_sets.append({
                    'Name': ss_name,
                    'Status': ss['Status'],
                    'Drift Status': ss.get('DriftStatus', 'N/A'),
                    'Administration Role': full_ss['StackSet'].get('AdministrationRoleARN', 'N/A'),
                    'Execution Role': full_ss['StackSet'].get('ExecutionRoleName', 'N/A'),
                    'Permission Model': full_ss['StackSet'].get('PermissionModel', 'N/A'),
                    'Regions': ", ".join(full_ss['StackSet'].get('Regions', [])),
                    'Full Detail File': file_ref
                })
    except ClientError as e:
        print(f"Could not audit StackSets (is this an Org?): {e}")
    return res_sets

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS CloudFormation Ultimate Audit (Stacks, Drift, Sets) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_stacks, all_drifts, all_changes, all_exports = [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_cfn, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                s, d, c, e = future.result()
                all_stacks.extend(s); all_drifts.extend(d); all_changes.extend(c); all_exports.extend(e)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    # Run the global audit once
    all_stacksets = audit_global_stacksets()

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_stacks = pd.DataFrame(all_stacks)
    df_drifts = pd.DataFrame(all_drifts)
    df_sets = pd.DataFrame(all_stacksets)
    df_changes = pd.DataFrame(all_changes)
    df_exports = pd.DataFrame(all_exports)
    
    # Sort
    if not df_stacks.empty: 
        drift_priority = {'DRIFTED': 0, 'IN_SYNC': 1, 'NOT_CHECKED': 2, 'UNKNOWN': 3}
        df_stacks['DriftSort'] = df_stacks['Stack Drift Status'].map(drift_priority)
        df_stacks = df_stacks.sort_values(by=['DriftSort', 'Region', 'Stack Name'])
        df_stacks = df_stacks.drop(columns=['DriftSort'])
    if not df_drifts.empty: df_drifts = df_drifts.sort_values(by=['Region', 'Stack Name', 'Logical ID'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_stacks.to_excel(writer, sheet_name='Stacks (Master List)', index=False)
            df_drifts.to_excel(writer, sheet_name='Stack Drift (Exploded)', index=False)
            df_sets.to_excel(writer, sheet_name='StackSets (Master List)', index=False)
            df_changes.to_excel(writer, sheet_name='Change Sets (Pending)', index=False)
            df_exports.to_excel(writer, sheet_name='Exports (Cross-Stack Refs)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
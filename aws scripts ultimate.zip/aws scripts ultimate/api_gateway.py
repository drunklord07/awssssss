import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "apigw_ultimate_audit.xlsx"
MAX_WORKERS = 10  # API Gateway has low API limits

# Folders for 100% raw JSON definitions
DIR_V1 = "details_apigw_v1_swagger"
DIR_V2 = "details_apigw_v2_openapi"
DIR_V1_OTHER = "details_apigw_v1_other"

for d in [DIR_V1, DIR_V2, DIR_V1_OTHER]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, f"{filename}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{filename}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        regions = [r['RegionName'] for r in resp['Regions']]
        if 'us-east-1' not in regions: regions.append('us-east-1')
        return regions
    except Exception:
        return ['us-east-1']

def get_tag_value(tags_dict):
    if not tags_dict: return ""
    return "; ".join([f"{k}={v}" for k, v in tags_dict.items()])

# --- WORKER ---
def audit_region_apigw(region):
    """
    Audits API Gateway v1 (REST) and v2 (HTTP/WS) in a single region.
    """
    # We need two different clients
    apigw_v1 = boto3.client('apigateway', region_name=region)
    apigw_v2 = boto3.client('apigatewayv2', region_name=region)
    
    res_v1_apis, res_v1_methods, res_v2_apis, res_v2_routes, res_v1_keys, res_v1_plans = [], [], [], [], [], []

    # --- 1. Audit API Gateway v1 (REST) ---
    try:
        paginator = apigw_v1.get_paginator('get_rest_apis')
        for page in paginator.paginate():
            for api in page['items']:
                api_id = api['id']
                api_name = api['name']
                
                # Get Policy
                policy_attached = "No"
                try:
                    policy = apigw_v1.get_policy(restApiId=api_id).get('policy')
                    policy_attached = "Yes"
                    save_raw_json(DIR_V1_OTHER, f"{region}_{api_name}_policy", json.loads(policy))
                except ClientError: pass # No policy is normal
                
                # Get Stages
                stages = apigw_v1.get_stages(restApiId=api_id).get('item', [])
                stage_names = [s['stageName'] for s in stages]
                
                # Get Full Export
                try:
                    export = apigw_v1.get_export(restApiId=api_id, stageName=stage_names[0] if stage_names else 'prod', exportType='swagger')
                    file_ref = save_raw_json(DIR_V1, f"{region}_{api_name}", json.loads(export['body'].read()))
                except ClientError:
                    file_ref = "Error (No Stages?)"

                res_v1_apis.append({
                    'Region': region,
                    'API Name': api_name,
                    'API ID': api_id,
                    'Endpoint Type': ", ".join(api.get('endpointConfiguration', {}).get('types', ['N/A'])),
                    'Stages': ", ".join(stage_names),
                    'Policy Attached?': policy_attached,
                    'Created': api['createdDate'].replace(tzinfo=None),
                    'Tags': get_tag_value(api.get('tags')),
                    'Full Swagger File': file_ref
                })
                
                # Explode Methods
                resources = apigw_v1.get_resources(restApiId=api_id, limit=500).get('items', [])
                for res in resources:
                    path = res['path']
                    for method_name, method_details in res.get('resourceMethods', {}).items():
                        res_v1_methods.append({
                            'Region': region,
                            'API Name': api_name,
                            'Resource Path': path,
                            'HTTP Method': method_name,
                            'Authorization': method_details.get('authorizationType', 'NONE'),
                            'API Key Required?': method_details.get('apiKeyRequired', False),
                            'Integration Type': method_details.get('methodIntegration', {}).get('type', 'N/A')
                        })

        # --- 2. Audit API Gateway v1 (Keys & Plans) ---
        keys = apigw_v1.get_api_keys(includeValues=False, limit=500).get('items', [])
        for key in keys:
            res_v1_keys.append({
                'Region': region,
                'Key Name': key['name'],
                'Key ID': key['id'],
                'Enabled': key['enabled'],
                'Created': key['createdDate'].replace(tzinfo=None),
                'Tags': get_tag_value(key.get('tags'))
            })
            
        paginator = apigw_v1.get_paginator('get_usage_plans')
        for page in paginator.paginate():
            for plan in page['items']:
                stages = [f"{s['apiId']}:{s['stage']}" for s in plan.get('apiStages', [])]
                res_v1_plans.append({
                    'Region': region,
                    'Plan Name': plan['name'],
                    'Plan ID': plan['id'],
                    'Throttle Rate': plan.get('throttle', {}).get('rateLimit', 'N/A'),
                    'Quota Limit': plan.get('quota', {}).get('limit', 'N/A'),
                    'Linked Stages': "\n".join(stages),
                    'Tags': get_tag_value(plan.get('tags'))
                })

        # --- 3. Audit API Gateway v2 (HTTP / WebSocket) ---
        paginator = apigw_v2.get_paginator('get_apis')
        for page in paginator.paginate():
            for api in page['Items']:
                api_id = api['ApiId']
                api_name = api['Name']
                
                # Get Full Export
                try:
                    export = apigw_v2.get_export(ApiId=api_id, Specification='OAS30', OutputType='JSON')
                    file_ref = save_raw_json(DIR_V2, f"{region}_{api_name}", json.loads(export['body'].read()))
                except ClientError:
                    file_ref = "Error"
                
                res_v2_apis.append({
                    'Region': region,
                    'API Name': api_name,
                    'API ID': api_id,
                    'Protocol': api['ProtocolType'],
                    'Endpoint': api['ApiEndpoint'],
                    'Default Stage': api.get('DefaultStage', '$default'),
                    'CORS': str(api.get('CorsConfiguration', 'N/A')),
                    'Created': api['CreatedDate'].replace(tzinfo=None),
                    'Tags': get_tag_value(api.get('Tags')),
                    'Full OpenAPI File': file_ref
                })
                
                # Explode Routes
                routes = apigw_v2.get_routes(ApiId=api_id).get('Items', [])
                for route in routes:
                    res_v2_routes.append({
                        'Region': region,
                        'API Name': api_name,
                        'Route Key': route['RouteKey'],
                        'Authorization': route.get('AuthorizationType', 'NONE'),
                        'Target': route.get('Target', 'N/A'),
                        'API Key Required?': route.get('ApiKeyRequired', False)
                    })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_v1_apis, res_v1_methods, res_v2_apis, res_v2_routes, res_v1_keys, res_v1_plans

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS API Gateway v1/v2 Ultimate Audit ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_v1_apis, all_v1_methods, all_v2_apis, all_v2_routes, all_v1_keys, all_v1_plans = [], [], [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_apigw, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                v1a, v1m, v2a, v2r, v1k, v1p = future.result()
                all_v1_apis.extend(v1a); all_v1_methods.extend(v1m); all_v2_apis.extend(v2a)
                all_v2_routes.extend(v2r); all_v1_keys.extend(v1k); all_v1_plans.extend(v1p)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")
    df_v1_apis = pd.DataFrame(all_v1_apis)
    df_v1_methods = pd.DataFrame(all_v1_methods)
    df_v2_apis = pd.DataFrame(all_v2_apis)
    df_v2_routes = pd.DataFrame(all_v2_routes)
    df_v1_keys = pd.DataFrame(all_v1_keys)
    df_v1_plans = pd.DataFrame(all_v1_plans)
    
    # Sort
    if not df_v1_methods.empty: df_v1_methods = df_v1_methods.sort_values(by=['Region', 'API Name', 'Resource Path', 'HTTP Method'])
    if not df_v2_routes.empty: df_v2_routes = df_v2_routes.sort_values(by=['Region', 'API Name', 'Route Key'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_v1_apis.to_excel(writer, sheet_name='REST APIs (v1)', index=False)
            df_v1_methods.to_excel(writer, sheet_name='REST Methods (Exploded)', index=False)
            df_v2_apis.to_excel(writer, sheet_name='HTTP-WS APIs (v2)', index=False)
            df_v2_routes.to_excel(writer, sheet_name='HTTP-WS Routes (Exploded)', index=False)
            df_v1_keys.to_excel(writer, sheet_name='API Keys (v1)', index=False)
            df_v1_plans.to_excel(writer, sheet_name='Usage Plans (v1)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
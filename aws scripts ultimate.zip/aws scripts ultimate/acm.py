import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "acm_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folder for 100% raw JSON details
DIR_ACM = "details_acm_certificates"

if not os.path.exists(DIR_ACM):
    os.makedirs(DIR_ACM)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    """Saves full attribute dump to JSON"""
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    """Get all EC2 regions, ensuring us-east-1 is present for CloudFront certs."""
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        regions = [r['RegionName'] for r in ec2.describe_regions(AllRegions=False)['Regions']]
        if 'us-east-1' not in regions:
            regions.append('us-east-1') # us-east-1 is global for ACM
        return regions
    except Exception:
        return ['us-east-1']

def calculate_days_to_expiry(expiry_date):
    """Calculates the days from now until the expiry date."""
    if not expiry_date:
        return None
    # Ensure expiry_date is timezone-aware (it should be from boto)
    if expiry_date.tzinfo is None:
        expiry_date = expiry_date.replace(tzinfo=datetime.timezone.utc)
        
    now = datetime.datetime.now(datetime.timezone.utc)
    delta = expiry_date - now
    return delta.days

# --- WORKER ---
def audit_region_acm(region):
    """
    Audits all ACM certificates in a single region.
    """
    acm = boto3.client('acm', region_name=region)
    res_certs = []
    
    try:
        paginator = acm.get_paginator('list_certificates')
        for page in paginator.paginate():
            for cert_summary in page['CertificateSummaryList']:
                cert_arn = cert_summary['CertificateArn']
                
                try:
                    # 1. Get Full Certificate Details
                    cert_details = acm.describe_certificate(CertificateArn=cert_arn)['Certificate']
                    
                    # 2. Save 100% Raw JSON
                    # Use the last part of the ARN as a unique file ID
                    cert_uuid = cert_arn.split('/')[-1]
                    file_ref = save_raw_json(DIR_ACM, f"{region}_{cert_uuid}.json", cert_details)
                    
                    # 3. Calculate Expiry
                    expiry_date = cert_details.get('NotAfter')
                    days_to_expiry = calculate_days_to_expiry(expiry_date)
                    
                    # 4. Check Usage
                    in_use_by = cert_details.get('InUseBy', [])
                    
                    # 5. Build Excel Row
                    res_certs.append({
                        'Main Domain': cert_details.get('DomainName', 'N/A'),
                        'Days to Expiry': days_to_expiry,
                        'Status': cert_details.get('Status', 'N/A'),
                        'Expiration Date': expiry_date.replace(tzinfo=None) if expiry_date else None,
                        'In Use?': "Yes" if in_use_by else "No",
                        'Type': cert_details.get('Type', 'N/A'),
                        'Region': region,
                        'ARN': cert_arn,
                        'All Domains (SANs)': ", ".join(cert_details.get('SubjectAlternativeNames', [])),
                        'Used By (Summary)': ", ".join(in_use_by),
                        'Full Detail File': file_ref
                    })
                    
                except ClientError as e:
                    print(f"[{region}] Error describing cert {cert_arn}: {e}")

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_certs

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS ACM (Certificate) Ultimate Audit ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel (including us-east-1 for CloudFront)...")

    all_certs = []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_acm, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                all_certs.extend(future.result())
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    if not all_certs:
        print("No certificates found.")
        return

    df_certs = pd.DataFrame(all_certs)
    
    # --- The Dashboard ---
    # Sort by 'Days to Expiry' ascending. This puts the most urgent certs at the top!
    df_certs = df_certs.sort_values(by=['Days to Expiry'])

    # Re-order columns for readability
    cols = [
        'Main Domain', 'Days to Expiry', 'Status', 'Expiration Date', 'In Use?', 
        'Type', 'Region', 'ARN', 'All Domains (SANs)', 'Used By (Summary)', 'Full Detail File'
    ]
    remaining = [c for c in df_certs.columns if c not in cols]
    df_certs = df_certs[cols + remaining]
    
    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_certs.to_excel(writer, sheet_name='ACM Certificates', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
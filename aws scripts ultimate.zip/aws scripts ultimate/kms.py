import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "kms_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_KEYS = "details_kms_keys"
DIR_ALIASES = "details_kms_aliases"

for d in [DIR_KEYS, DIR_ALIASES]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_account_id():
    return boto3.client('sts').get_caller_identity()['Account']

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def format_principal(principal):
    """Simplifies the complex Principal object into a string."""
    if 'AWS' in principal:
        return str(principal['AWS'])
    if 'Service' in principal:
        return str(principal['Service'])
    if 'Federated' in principal:
        return str(principal['Federated'])
    if 'CanonicalUser' in principal:
        return str(principal['CanonicalUser'])
    return str(principal)

# --- WORKER ---
def audit_region_kms(region):
    """
    Audits all KMS components in a single region.
    """
    kms = boto3.client('kms', region_name=region)
    
    res_keys = []
    res_aliases = []
    res_policy_stmts = []
    res_grants = []
    
    # --- 1. Get Aliases FIRST ---
    # We need this map to enrich the Key list
    key_id_to_aliases = {}
    try:
        paginator = kms.get_paginator('list_aliases')
        for page in paginator.paginate():
            for alias in page['Aliases']:
                alias_name = alias['AliasName']
                target_key = alias.get('TargetKeyId', None)
                
                # Save alias data
                res_aliases.append({
                    'Alias Name': alias_name,
                    'Region': region,
                    'Target Key ID': target_key
                })
                
                if target_key:
                    if target_key not in key_id_to_aliases:
                        key_id_to_aliases[target_key] = []
                    key_id_to_aliases[target_key].append(alias_name)
    except Exception as e:
        print(f"[{region}] Could not list aliases: {e}")

    # Save alias JSONs
    save_raw_json(DIR_ALIASES, f"{region}_aliases.json", res_aliases)

    # --- 2. Audit Keys ---
    try:
        paginator = kms.get_paginator('list_keys')
        for page in paginator.paginate():
            for key in page['Keys']:
                key_id = key['KeyId']
                
                try:
                    # --- 2a. Get Key Metadata (and filter) ---
                    desc = kms.describe_key(KeyId=key_id)['KeyMetadata']
                    
                    # CRITICAL: Skip AWS-managed keys (like 'aws/s3')
                    if desc['KeyManager'] == 'AWS':
                        continue
                    
                    full_key_data = {'Description': desc}
                    
                    # --- 2b. Get Rotation Status ---
                    try:
                        rot = kms.get_key_rotation_status(KeyId=key_id)
                        rotation_enabled = rot['KeyRotationEnabled']
                        full_key_data['RotationStatus'] = rot
                    except ClientError:
                        rotation_enabled = False # e.g., for imported keys
                    
                    # --- 2c. Get Key Policy & Explode ---
                    try:
                        policy_str = kms.get_key_policy(KeyId=key_id, PolicyName='default')['Policy']
                        policy_json = json.loads(policy_str)
                        full_key_data['Policy'] = policy_json
                        
                        for stmt in policy_json.get('Statement', []):
                            res_policy_stmts.append({
                                'Key ID': key_id,
                                'Region': region,
                                'SID': stmt.get('Sid', 'No_SID'),
                                'Effect': stmt.get('Effect'),
                                'Principal': format_principal(stmt.get('Principal', {})),
                                'Action': str(stmt.get('Action')),
                                'Condition': str(stmt.get('Condition', {}))
                            })
                    except ClientError as e:
                        res_policy_stmts.append({'Key ID': key_id, 'SID': 'ERROR', 'Effect': str(e)})

                    # --- 2d. List Grants & Explode ---
                    try:
                        grants_paginator = kms.get_paginator('list_grants')
                        key_grants = []
                        for grant_page in grants_paginator.paginate(KeyId=key_id):
                            key_grants.extend(grant_page['Grants'])
                        
                        full_key_data['Grants'] = key_grants
                        
                        for grant in key_grants:
                            res_grants.append({
                                'Key ID': key_id,
                                'Region': region,
                                'Grant ID': grant['GrantId'],
                                'Grantee': grant.get('GranteePrincipal'),
                                'Issuing Account': grant.get('IssuingAccount'),
                                'Operations': ", ".join(grant.get('Operations', []))
                            })
                    except ClientError as e:
                        res_grants.append({'Key ID': key_id, 'Grant ID': 'ERROR', 'Grantee': str(e)})

                    # --- 2e. Save Full JSON Detail ---
                    file_ref = save_raw_json(DIR_KEYS, f"{region}_{key_id}.json", full_key_data)

                    # --- 2f. Build Excel Row for Key Summary ---
                    res_keys.append({
                        'Key ID': key_id,
                        'ARN': desc['Arn'],
                        'Region': region,
                        'Alias(es)': ", ".join(key_id_to_aliases.get(key_id, ['No Alias'])),
                        'State': desc['KeyState'],
                        'Origin': desc['Origin'],
                        'Rotation Enabled': rotation_enabled,
                        'Description': desc.get('Description', ''),
                        'Full Detail File': file_ref
                    })

                except ClientError as e:
                    print(f"[{region}] Error describing key {key_id}: {e}")

    except Exception as e:
        print(f"[{region}] Error listing keys: {e}")

    return res_keys, res_aliases, res_policy_stmts, res_grants

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS KMS Ultimate Audit (Keys, Aliases, Policies, Grants) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_keys, all_aliases, all_policies, all_grants = [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_kms, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            k, a, p, g = future.result()
            all_keys.extend(k)
            all_aliases.extend(a)
            all_policies.extend(p)
            all_grants.extend(g)

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_keys = pd.DataFrame(all_keys)
    df_aliases = pd.DataFrame(all_aliases)
    df_policies = pd.DataFrame(all_policies)
    df_grants = pd.DataFrame(all_grants)
    
    # Sort
    if not df_keys.empty: df_keys = df_keys.sort_values(by=['Region', 'Alias(es)'])
    if not df_aliases.empty: df_aliases = df_aliases.sort_values(by=['Region', 'Alias Name'])
    if not df_policies.empty: df_policies = df_policies.sort_values(by=['Region', 'Key ID', 'SID'])
    if not df_grants.empty: df_grants = df_grants.sort_values(by=['Region', 'Key ID'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_keys.to_excel(writer, sheet_name='KMS Keys (Customer)', index=False)
            df_policies.to_excel(writer, sheet_name='Key Policies (Exploded)', index=False)
            df_grants.to_excel(writer, sheet_name='Key Grants (Exploded)', index=False)
            df_aliases.to_excel(writer, sheet_name='Key Aliases', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "lambda_ultimate_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_FUNC = "details_lambda_functions"
DIR_POL = "details_lambda_policies"

for d in [DIR_FUNC, DIR_POL]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    # Sanitize filename
    safe_name = filename.replace('/', '_').replace(':', '_')
    path = os.path.join(folder, f"{safe_name}.json")
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return f"{safe_name}.json"

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def format_principal(principal):
    if principal == '*': return "Public (*)"
    if 'AWS' in principal: return str(principal['AWS'])
    if 'Service' in principal: return str(principal['Service'])
    return str(principal)

# --- WORKER ---
def audit_region_lambda(region):
    """
    Audits all Lambda components in a single region.
    """
    lambda_client = boto3.client('lambda', region_name=region)
    
    res_funcs, res_policies, res_mappings, res_env_vars, res_layers = [], [], [], [], []
    
    # --- 1. Get ALL Event Source Mappings first ---
    # This is more efficient than calling it per-function
    mapping_map = {}
    try:
        paginator = lambda_client.get_paginator('list_event_source_mappings')
        for page in paginator.paginate():
            for mapping in page['EventSourceMappings']:
                func_arn = mapping['FunctionArn']
                if func_arn not in mapping_map:
                    mapping_map[func_arn] = []
                mapping_map[func_arn].append(mapping)
    except ClientError as e:
        print(f"[{region}] Error listing event source mappings: {e}")

    # --- 2. Audit Functions ---
    try:
        paginator = lambda_client.get_paginator('list_functions')
        for page in paginator.paginate():
            for func in page['Functions']:
                func_name = func['FunctionName']
                func_arn = func['FunctionArn']
                full_data = {'Configuration': func} # Start building JSON
                
                # --- 3. Get Resource Policy & Explode ---
                policy_attached = "No"
                try:
                    policy_str = lambda_client.get_policy(FunctionName=func_name).get('Policy', '{}')
                    policy_json = json.loads(policy_str)
                    full_data['Policy'] = policy_json
                    save_raw_json(DIR_POL, f"{region}_{func_name}_policy", policy_json)
                    policy_attached = "Yes"
                    
                    for stmt in policy_json.get('Statement', []):
                        res_policies.append({
                            'Region': region,
                            'Function Name': func_name,
                            'SID': stmt.get('Sid', 'No_SID'),
                            'Effect': stmt.get('Effect'),
                            'Principal': format_principal(stmt.get('Principal', {})),
                            'Action': str(stmt.get('Action')),
                            'Condition': str(stmt.get('Condition', {}))
                        })
                except ClientError as e:
                    if 'ResourceNotFoundException' in str(e): policy_attached = "No"
                    else: policy_attached = "Error"
                
                # --- 4. Get Mappings (from our map) & Explode ---
                mappings = mapping_map.get(func_arn, [])
                full_data['EventSourceMappings'] = mappings
                for m in mappings:
                    res_mappings.append({
                        'Region': region,
                        'Function Name': func_name,
                        'Source ARN': m['EventSourceArn'],
                        'State': m['State'],
                        'Batch Size': m.get('BatchSize', 'N/A'),
                        'UUID': m['UUID']
                    })

                # --- 5. Get Environment Variables (KEYS ONLY) ---
                env_vars = func.get('Environment', {}).get('Variables', {})
                for key, value in env_vars.items():
                    # SECURITY: We only list the KEY in Excel. The value is in the JSON.
                    res_env_vars.append({
                        'Region': region,
                        'Function Name': func_name,
                        'Env Var Key': key,
                        'KMS Encrypted': "Yes" if func.get('KMSKeyArn') else "No (Default)"
                    })

                # --- 6. Get Layers & Explode ---
                layers = func.get('Layers', [])
                for layer in layers:
                    res_layers.append({
                        'Region': region,
                        'Function Name': func_name,
                        'Layer ARN': layer['Arn'],
                        'Size': layer.get('CodeSize', 0)
                    })

                # --- 7. Save JSON & Build Excel Row ---
                file_ref = save_raw_json(DIR_FUNC, f"{region}_{func_name}", full_data)
                
                res_funcs.append({
                    'Region': region,
                    'Function Name': func_name,
                    'ARN': func_arn,
                    'Runtime': func.get('Runtime', 'N/A'),
                    'IAM Role ARN': func.get('Role', 'N/A'),
                    'State': func.get('State', 'N/A'),
                    'Last Modified': func.get('LastModified'),
                    'Memory (MB)': func.get('MemorySize', 0),
                    'Timeout (sec)': func.get('Timeout', 0),
                    'VPC ID': func.get('VpcConfig', {}).get('VpcId', 'Not in VPC'),
                    'Security Groups': ", ".join(func.get('VpcConfig', {}).get('SecurityGroupIds', [])),
                    'DLQ': func.get('DeadLetterConfig', {}).get('TargetArn', 'None'),
                    'Env Var Count': len(env_vars),
                    'Layer Count': len(layers),
                    'Mapping Count': len(mappings),
                    'Policy Attached?': policy_attached,
                    'Full Detail File': file_ref
                })

    except Exception as e:
        if "AuthFailure" not in str(e): print(f"[{region}] Error: {e}")

    return res_funcs, res_policies, res_mappings, res_env_vars, res_layers

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Lambda Ultimate Audit (Config, Policy, Triggers, EnvVars) ---")
    
    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel...")

    all_funcs, all_pols, all_maps, all_envs, all_layers = [], [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_lambda, r): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                f, p, m, e, l = future.result()
                all_funcs.extend(f); all_pols.extend(p); all_maps.extend(m); all_envs.extend(e); all_layers.extend(l)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_funcs = pd.DataFrame(all_funcs)
    df_pols = pd.DataFrame(all_pols)
    df_maps = pd.DataFrame(all_maps)
    df_envs = pd.DataFrame(all_envs)
    df_layers = pd.DataFrame(all_layers)
    
    # Sort
    if not df_funcs.empty: 
        # Sort by Runtime to find old versions
        df_funcs = df_funcs.sort_values(by=['Region', 'Runtime', 'Function Name'])
    if not df_envs.empty:
        # Sort by Key to group all 'PASSWORD' keys together
        df_envs = df_envs.sort_values(by=['Region', 'Env Var Key', 'Function Name'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_funcs.to_excel(writer, sheet_name='Lambda Functions (Master List)', index=False)
            df_pols.to_excel(writer, sheet_name='Function Policies (Exploded)', index=False)
            df_maps.to_excel(writer, sheet_name='Event Source Mappings', index=False)
            df_envs.to_excel(writer, sheet_name='Environment Variables (Exploded)', index=False)
            df_layers.to_excel(writer, sheet_name='Function Layers (Exploded)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()
import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "vpc_connectivity_audit.xlsx"
MAX_WORKERS = 20

# Folders for 100% raw JSON details
DIR_SUBNET = "details_subnet"
DIR_RT = "details_routetable"
DIR_IGW = "details_internetgateway"
DIR_NAT = "details_natgateway"
DIR_VPCE = "details_vpcendpoint"

for d in [DIR_SUBNET, DIR_RT, DIR_IGW, DIR_NAT, DIR_VPCE]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    """Saves full attribute dump to JSON"""
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_tag_value(tags, key):
    if not tags: return ""
    for t in tags:
        if t['Key'] == key:
            return t['Value']
    return ""

def get_account_id():
    return boto3.client('sts').get_caller_identity()['Account']

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

# --- WORKER ---

def audit_region_connectivity(region, account_id):
    """
    Audits Subnets, Route Tables, IGWs, NAT-GWs, and VPC Endpoints
    """
    ec2 = boto3.client('ec2', region_name=region)
    
    res_subnets = []
    res_rt_routes = []
    res_igws = []
    res_nats = []
    res_vpces = []
    
    # --- Route Table Mapping ---
    # We must get route tables FIRST to map them to subnets
    main_rt_map = {}
    explicit_rt_map = {}
    
    try:
        rts = ec2.describe_route_tables()['RouteTables']
        for rt in rts:
            rt_id = rt['RouteTableId']
            # Save raw JSON for the route table
            rt_file_ref = save_raw_json(DIR_RT, f"{region}_{rt_id}.json", rt)
            
            rt_name = get_tag_value(rt.get('Tags'), 'Name')
            is_main = False
            
            for a in rt['Associations']:
                if a['Main']:
                    is_main = True
                    main_rt_map[rt['VpcId']] = rt_id
                if a.get('SubnetId'):
                    explicit_rt_map[a['SubnetId']] = rt_id
            
            # Explode the routes
            for route in rt['Routes']:
                dest = route.get('DestinationCidrBlock', route.get('DestinationIpv6CidrBlock', 'N/A'))
                
                # Determine Target
                target_id = "N/A"
                target_type = "N/A"
                if route.get('GatewayId'):
                    target_id = route.get('GatewayId')
                    target_type = "Internet Gateway" if "igw-" in target_id else "Gateway"
                elif route.get('NatGatewayId'):
                    target_id = route.get('NatGatewayId')
                    target_type = "NAT Gateway"
                elif route.get('VpcEndpointId'):
                    target_id = route.get('VpcEndpointId')
                    target_type = "VPC Endpoint"
                elif route.get('InstanceId'):
                    target_id = route.get('InstanceId')
                    target_type = "Instance"
                elif route.get('NetworkInterfaceId'):
                    target_id = route.get('NetworkInterfaceId')
                    target_type = "Network Interface"
                
                res_rt_routes.append({
                    'Route Table Name': rt_name,
                    'Route Table ID': rt_id,
                    'Region': region,
                    'VPC ID': rt['VpcId'],
                    'Is Main': "Yes" if is_main else "No",
                    'Destination': dest,
                    'Target ID': target_id,
                    'Target Type': target_type,
                    'State': route['State'],
                    'Origin': route['Origin'],
                    'Full Detail File': rt_file_ref
                })

        # --- 1. Subnets ---
        paginator = ec2.get_paginator('describe_subnets')
        for page in paginator.paginate():
            for s in page['Subnets']:
                subnet_id = s['SubnetId']
                # Determine this subnet's route table
                rt_id = explicit_rt_map.get(subnet_id, main_rt_map.get(s['VpcId'], "Not Found"))
                
                file_ref = save_raw_json(DIR_SUBNET, f"{region}_{subnet_id}.json", s)
                
                res_subnets.append({
                    'Name': get_tag_value(s.get('Tags'), 'Name'),
                    'Subnet ID': subnet_id,
                    'ARN': f"arn:aws:ec2:{region}:{account_id}:subnet/{subnet_id}",
                    'Region': region,
                    'VPC ID': s['VpcId'],
                    'Associated Route Table': rt_id,
                    'CIDR': s['CidrBlock'],
                    'State': s['State'],
                    'Availability Zone': s['AvailabilityZone'],
                    'Available IPs': s['AvailableIpAddressCount'],
                    'Map Public IP on Launch': s['MapPublicIpOnLaunch'],
                    'Full Detail File': file_ref
                })
                
        # --- 2. Internet Gateways ---
        for igw in ec2.describe_internet_gateways()['InternetGateways']:
            igw_id = igw['InternetGatewayId']
            file_ref = save_raw_json(DIR_IGW, f"{region}_{igw_id}.json", igw)
            
            res_igws.append({
                'Name': get_tag_value(igw.get('Tags'), 'Name'),
                'IGW ID': igw_id,
                'Region': region,
                'Attached VPC': igw.get('Attachments', [{}])[0].get('VpcId', 'Detached'),
                'Full Detail File': file_ref
            })

        # --- 3. NAT Gateways ---
        paginator = ec2.get_paginator('describe_nat_gateways')
        for page in paginator.paginate():
            for nat in page['NatGateways']:
                nat_id = nat['NatGatewayId']
                file_ref = save_raw_json(DIR_NAT, f"{region}_{nat_id}.json", nat)
                
                res_nats.append({
                    'Name': get_tag_value(nat.get('Tags'), 'Name'),
                    'NAT Gateway ID': nat_id,
                    'Region': region,
                    'VPC ID': nat['VpcId'],
                    'Subnet ID': nat['SubnetId'],
                    'State': nat['State'],
                    'Public IP': nat['NatGatewayAddresses'][0].get('PublicIp', 'N/A'),
                    'Private IP': nat['NatGatewayAddresses'][0].get('PrivateIp', 'N/A'),
                    'Full Detail File': file_ref
                })

        # --- 4. VPC Endpoints ---
        for vpce in ec2.describe_vpc_endpoints()['VpcEndpoints']:
            vpce_id = vpce['VpcEndpointId']
            file_ref = save_raw_json(DIR_VPCE, f"{region}_{vpce_id}.json", vpce)
            
            res_vpces.append({
                'Name': get_tag_value(vpce.get('Tags'), 'Name'),
                'Endpoint ID': vpce_id,
                'Region': region,
                'VPC ID': vpce['VpcId'],
                'Type': vpce['VpcEndpointType'],
                'Service Name': vpce['ServiceName'],
                'State': vpce['State'],
                'Subnet IDs': ", ".join(vpce.get('SubnetIds', [])),
                'Route Table IDs': ", ".join(vpce.get('RouteTableIds', [])),
                'Full Detail File': file_ref
            })

    except Exception as e:
        if "AuthFailure" not in str(e) and "OptInRequired" not in str(e): 
            print(f"[{region}] Error: {e}")

    return res_subnets, res_rt_routes, res_igws, res_nats, res_vpces

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Connectivity & Routing Audit ---")
    
    try: account_id = get_account_id()
    except Exception: print("Credentials error"); return

    regions = get_regions()
    print(f"Scanning {len(regions)} regions for {account_id}...")

    all_sub, all_rt, all_igw, all_nat, all_vpce = [], [], [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_connectivity, r, account_id): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            s, rt, i, n, e = future.result()
            all_sub.extend(s)
            all_rt.extend(rt)
            all_igw.extend(i)
            all_nat.extend(n)
            all_vpce.extend(e)

    print("\n\nCompiling Excel Report...")

    # Create DataFrames
    df_sub = pd.DataFrame(all_sub)
    df_rt = pd.DataFrame(all_rt)
    df_igw = pd.DataFrame(all_igw)
    df_nat = pd.DataFrame(all_nat)
    df_vpce = pd.DataFrame(all_vpce)
    
    # Sort
    if not df_sub.empty: df_sub = df_sub.sort_values(by=['Region', 'VPC ID', 'Subnet ID'])
    if not df_rt.empty: df_rt = df_rt.sort_values(by=['Region', 'VPC ID', 'Route Table ID', 'Destination'])
    if not df_igw.empty: df_igw = df_igw.sort_values(by=['Region', 'VPC ID'])
    if not df_nat.empty: df_nat = df_nat.sort_values(by=['Region', 'VPC ID'])
    if not df_vpce.empty: df_vpce = df_vpce.sort_values(by=['Region', 'VPC ID'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_sub.to_excel(writer, sheet_name='Subnets', index=False)
            df_rt.to_excel(writer, sheet_name='Route Table Routes', index=False)
            df_igw.to_excel(writer, sheet_name='Internet Gateways', index=False)
            df_nat.to_excel(writer, sheet_name='NAT Gateways', index=False)
            df_vpce.to_excel(writer, sheet_name='VPC Endpoints', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error writing Excel: {e}")

if __name__ == "__main__":
    main()
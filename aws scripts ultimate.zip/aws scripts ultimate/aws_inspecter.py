import boto3
import pandas as pd
import json
import os
import datetime
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# --- CONFIGURATION ---
OUTPUT_FILE = "inspector_ultimate_audit.xlsx"
MAX_WORKERS = 10  # Inspector has strict API limits, do not set this too high

# Folders for 100% raw JSON details (CONFIGURATIONS ONLY)
DIR_ADMIN = "details_inspector_admin"
DIR_STATUS = "details_inspector_status"
DIR_COVERAGE = "details_inspector_coverage" # Will save coverage summary

for d in [DIR_ADMIN, DIR_STATUS, DIR_COVERAGE]:
    if not os.path.exists(d):
        os.makedirs(d)

# --- HELPERS ---
class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime.date, datetime.datetime)):
            return o.isoformat()
        return super(DateTimeEncoder, self).default(o)

def save_raw_json(folder, filename, data):
    path = os.path.join(folder, filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=4, cls=DateTimeEncoder)
    return filename

def get_regions():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    try:
        resp = ec2.describe_regions(AllRegions=False)
        return [r['RegionName'] for r in resp['Regions']]
    except Exception:
        return ['us-east-1']

def flatten_finding(finding, region):
    """Flattens the complex finding JSON into a single dict for Excel."""
    resource = finding.get('resources', [{}])[0]
    package = finding.get('packageVulnerabilityDetails', {})
    
    return {
        'Region': region,
        'Severity': finding.get('severity', 'N/A'),
        'Title': finding.get('title', 'N/A'),
        'Type': finding.get('type', 'N/A'),
        'Resource Type': resource.get('type', 'N/A'),
        'Resource ID': resource.get('id', 'N/A'),
        'Package Name': package.get('packageName', 'N/A'),
        'Vulnerability ID': package.get('vulnerabilityId', 'N/A'),
        'CVSS': package.get('cvss', [{}])[0].get('baseScore', 'N/A'),
        'First Observed': finding.get('firstObservedAt'),
        'Last Observed': finding.get('lastObservedAt'),
    }

def flatten_coverage(cover, region):
    """Flattens the coverage data into a single dict."""
    return {
        'Region': region,
        'Resource ID': cover.get('resourceId'),
        'Resource Type': cover.get('resourceType'),
        'Scan Status': cover.get('scanStatus', {}).get('status', 'N/A'),
        'Scan Status Reason': cover.get('scanStatus', {}).get('reason', 'N/A'),
        'Account ID': cover.get('accountId'),
    }

# --- WORKER ---
def audit_region_inspector(region, account_id):
    """
    Audits all Inspector v2 components in a single region.
    """
    inspector = boto3.client('inspector2', region_name=region)
    
    res_status = []
    res_findings = []
    res_coverage = []
    
    try:
        # --- 1. Audit Account Status (Is it on?) ---
        status = inspector.batch_get_account_status(accountIds=[account_id])['accounts'][0]
        state = status.get('state', {})
        
        if state.get('status', 'ERROR') != 'ENABLED':
            res_status.append({'Region': region, 'Status': 'DISABLED', 'EC2': 'N/A', 'ECR': 'N/A', 'Lambda': 'N/A'})
            # If Inspector is off, there's nothing else to check in this region
            return res_status, res_findings, res_coverage
        
        # Save raw JSON for status
        save_raw_json(DIR_STATUS, f"{region}_status.json", status)
        
        # Build Excel row for status
        ec2_status = state['resourceState'].get('ec2', {}).get('status', 'N/A')
        ecr_status = state['resourceState'].get('ecr', {}).get('status', 'N/A')
        lambda_status = state['resourceState'].get('lambda', {}).get('status', 'N/A')
        
        res_status.append({
            'Region': region,
            'Status': 'ENABLED',
            'EC2': ec2_status,
            'ECR': ecr_status,
            'Lambda': lambda_status
        })

        # --- 2. Audit Active Findings (The "To-Do List") ---
        paginator = inspector.get_paginator('list_findings')
        filter_criteria = {'findingStatus': [{'comparison': 'EQUALS', 'value': 'ACTIVE'}]}
        
        for page in paginator.paginate(filterCriteria=filter_criteria):
            for finding in page['findings']:
                res_findings.append(flatten_finding(finding, region))
        
        # --- 3. Audit Coverage (The "Blind Spots") ---
        paginator = inspector.get_paginator('list_coverage')
        for page in paginator.paginate():
            for cover in page['coveredResources']:
                res_coverage.append(flatten_coverage(cover, region))
        
        save_raw_json(DIR_COVERAGE, f"{region}_coverage.json", res_coverage) # Save summary

    except ClientError as e:
        if "AccessDeniedException" in str(e):
             res_status.append({'Region': region, 'Status': 'AccessDenied (Not Enabled?)', 'EC2': 'N/A', 'ECR': 'N/A', 'Lambda': 'N/A'})
        else:
            print(f"[{region}] Error: {e}")

    return res_status, res_findings, res_coverage

def audit_delegated_admin():
    """Checks for an Inspector Delegated Administrator."""
    res_admins = []
    try:
        client = boto3.client('inspector2', region_name='us-east-1') # Use us-east-1 for global
        paginator = client.get_paginator('list_delegated_admin_accounts')
        for page in paginator.paginate():
            for admin in page['delegatedAdminAccounts']:
                res_admins.append(admin)
        
        save_raw_json(DIR_ADMIN, "delegated_admins.json", res_admins)
                
    except ClientError as e:
        if "AccessDenied" in str(e):
            return [{'accountId': 'AccessDenied', 'status': 'N/A'}]
    except Exception as e:
        # Fails if not an org
        print(f"Note: Could not check for Delegated Admin (Not an Org?): {e}")
        return [{'accountId': 'Not an Org or Error', 'status': 'N/Failure'}]
        
    if not res_admins:
        return [{'accountId': 'None', 'status': 'None'}]
    
    return res_admins

# --- MAIN ---
def main():
    start_time = time.time()
    print("--- AWS Inspector v2 Ultimate Audit (Status, Findings, Coverage) ---")
    
    try:
        account_id = boto3.client('sts').get_caller_identity()['Account']
    except Exception as e:
        print(f"CRITICAL: Could not get Account ID. {e}")
        return

    regions = get_regions()
    print(f"Scanning {len(regions)} regions in parallel for Account {account_id}...")

    all_status, all_findings, all_coverage = [], [], []
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_map = {executor.submit(audit_region_inspector, r, account_id): r for r in regions}
        
        done = 0
        for future in as_completed(future_map):
            done += 1
            r_name = future_map[future]
            print(f"\rProgress: {done}/{len(regions)} ({r_name})", end="")
            
            try:
                stat, find, cov = future.result()
                all_status.extend(stat)
                all_findings.extend(find)
                all_coverage.extend(cov)
            except Exception as e:
                print(f"\nError processing {r_name}: {e}")

    print("\nChecking for Delegated Administrator...")
    all_admins = audit_delegated_admin()

    print("Compiling Excel Report...")

    # Create DataFrames
    df_admins = pd.DataFrame(all_admins)
    df_status = pd.DataFrame(all_status)
    df_findings = pd.DataFrame(all_findings)
    df_coverage = pd.DataFrame(all_coverage)
    
    # Sort
    if not df_status.empty: df_status = df_status.sort_values(by=['Region'])
    if not df_findings.empty:
        # Sort by Severity, then Last Observed. This is your "to-do list"
        severity_map = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3, 'INFORMATIONAL': 4, 'N/A': 5}
        df_findings['SeveritySort'] = df_findings['Severity'].map(severity_map)
        df_findings = df_findings.sort_values(by=['SeveritySort', 'Last Observed'], ascending=[True, False])
        df_findings = df_findings.drop(columns=['SeveritySort'])
    if not df_coverage.empty:
        # Sort by status to bring "NOT_SCANNING" to the top
        df_coverage = df_coverage.sort_values(by=['Region', 'Scan Status', 'Resource Type'])

    try:
        with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
            df_admins.to_excel(writer, sheet_name='Delegated Admin (Org)', index=False)
            df_status.to_excel(writer, sheet_name='Inspector Status (by Region)', index=False)
            df_findings.to_excel(writer, sheet_name='Active Findings (Exploded)', index=False)
            df_coverage.to_excel(writer, sheet_name='Coverage (Blind Spots)', index=False)
            
        print(f"✅ DONE. Report: {OUTPUT_FILE}")
        print(f"   Time: {round(time.time() - start_time, 2)}s")
    except Exception as e:
        print(f"❌ Error saving Excel: {e}")

if __name__ == "__main__":
    main()